import test,{after} from 'node:test'
import assert from 'node:assert/strict'
import {createReadStream,readFileSync,writeFileSync} from 'node:fs'
import {createInterface} from 'node:readline'
import {join} from 'node:path'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {upsertLeadProfile,leadOpsStats} from '../src/lead-ops.mjs'
import {appendTrackedEvent,trackedEventStats,listTrackedEvents} from '../src/tracked-events.mjs'
import {calculateMetricSet} from '../src/metric-catalog.mjs'
import {pool} from '../src/database.mjs'
import {runConnectorSync} from '../src/connector-ingestion.mjs'
import {withWorkspace,mutateState,closeStore} from '../src/store.mjs'
import {encryptSecret} from '../src/vault.mjs'
const isolated=process.env.QA_ISOLATED==='1'&&Boolean(process.env.QA_NATIVE_ADMIN_URL)
const report={scope:'Actual application data-layer integration on isolated real PostgreSQL; NOT full API/browser/load qualification',leadsImported:0,eventsImported:0,checks:[],providerCampaignRowsImported:0}
let root,leads,oracle
async function parallel(items,operation,concurrency=8){let next=0;await Promise.all(Array.from({length:Math.min(concurrency,items.length)},async()=>{while(next<items.length){const i=next++;await operation(items[i],i)}}))}
const leadInput=l=>({externalLeadId:l.lead_id,name:l.display_name,email:l.email,source:'synthetic_fixture',campaign:l.campaign_id,crmStage:l.stage,lastActivity:l.updated_at,attributes:{sourceRecordId:l.source_record_id,fixtureVersion:l.fixture_version}})
const eventInput=e=>({id:e.event_id,event:e.event_type,eventType:e.event_type,occurredAt:e.occurred_at,receivedAt:e.received_at,consentCategory:'analytics',source:e.source_kind,customerId:e.lead_id,visitorId:e.anonymous_id,campaign:e.campaign_id,currency:e.currency,amount:e.amount_minor/100,amountMinor:e.amount_minor,parentEventId:e.parent_event_id,fixtureVersion:e.fixture_version})
after(async()=>{if(isolated&&process.env.QA_REPORTS)writeFileSync(join(process.env.QA_REPORTS,'functional-volume.json'),JSON.stringify(report,null,2)+'\n');await closeStore();await pool?.end()})
test('D2 volume: supplied functional source regenerates without byte drift',{skip:!isolated},()=>{
 root=join(process.env.QA_PRIVATE_ROOT,'full-functional-volume');execFileSync('python3',['qa/materialize-functional.py',root],{stdio:'pipe'})
 leads=JSON.parse(readFileSync(join(root,'leads.json')));oracle=JSON.parse(readFileSync(join(root,'D2_marketing/expected_reconciliation.json')))
 assert.equal(leads.length,10000);report.source=JSON.parse(readFileSync(join(root,'source-validation.json')));report.checks.push('five source hashes match')
})
test('D2 volume: actual lead repository imports 10000 supplied leads and replay remains idempotent',{skip:!isolated,timeout:300000},async()=>{
 assert.ok(leads,'fixture prerequisite');const started=performance.now()
 await parallel(leads,async l=>{const r=await upsertLeadProfile(l.workspace_id,leadInput(l));assert.equal(r.external_lead_id,l.lead_id);report.leadsImported++})
 await parallel(leads.slice(0,1000),l=>upsertLeadProfile(l.workspace_id,leadInput(l)))
 const {rows}=await pool.query('SELECT external_lead_id,workspace_id,name,email_sha256,crm_stage,campaign FROM ace_lead_profiles')
 assert.equal(rows.length,10000);const records=new Map(rows.map(r=>[r.external_lead_id,r]))
 for(const l of leads){const r=records.get(l.lead_id);assert.ok(r);assert.equal(r.workspace_id,l.workspace_id);assert.equal(r.name,l.display_name);assert.equal(r.crm_stage,l.stage);assert.equal(r.campaign,l.campaign_id);assert.equal(r.email_sha256,createHash('sha256').update(l.email.toLowerCase()).digest('hex'))}
 for(const workspace of new Set(leads.map(l=>l.workspace_id)))assert.equal((await leadOpsStats(workspace)).total,2500)
 report.leadReplay=1000;report.leadSeconds=(performance.now()-started)/1000;report.checks.push('all lead IDs, tenants, campaigns, stages, names and email hashes reconcile')
})
test('D2 volume: actual event repository persists 100000 original events and deduplicates replay',{skip:!isolated,timeout:300000},async()=>{
 assert.ok(root,'fixture prerequisite');const started=performance.now();let batch=[];const replay=[]
 for await(const line of createInterface({input:createReadStream(join(root,'D2_marketing/events.ndjson')),crlfDelay:Infinity})){
  const e=JSON.parse(line);batch.push(e);if(replay.length<1000)replay.push(e)
  if(batch.length===512){await parallel(batch,async x=>{const r=await appendTrackedEvent(x.workspace_id,eventInput(x));assert.equal(r.id,x.event_id);report.eventsImported++});batch=[]}
 }
 if(batch.length)await parallel(batch,async x=>{await appendTrackedEvent(x.workspace_id,eventInput(x));report.eventsImported++})
 await parallel(replay,x=>appendTrackedEvent(x.workspace_id,eventInput(x)))
 assert.equal(report.eventsImported,100000);assert.equal(Number((await pool.query('SELECT count(*) n FROM ace_events')).rows[0].n),100000)
 report.eventReplay=1000;report.eventSeconds=(performance.now()-started)/1000;report.checks.push('100000 event IDs persisted once after 1000 replays')
})
test('D2 volume: persisted event types and monetary minor units match independent oracle',{skip:!isolated},async()=>{
 assert.equal(report.eventsImported,100000,'complete event ingest prerequisite')
 const {rows}=await pool.query("SELECT event_type,count(*)::int n,sum((payload->>'amountMinor')::bigint)::text amount FROM ace_events GROUP BY event_type")
 assert.deepEqual(Object.fromEntries(rows.map(r=>[r.event_type,r.n])),oracle.event_type_counts)
 const sums=Object.fromEntries(rows.map(r=>[r.event_type,Number(r.amount)]))
 assert.equal(sums['payment.succeeded'],oracle.first_party.revenue_minor);assert.equal(sums['payment.refunded'],oracle.first_party.refunds_minor)
 assert.equal(sums['payment.succeeded']-sums['payment.refunded'],oracle.first_party.net_revenue_minor)
 const persisted=await pool.query('SELECT payload FROM ace_events')
 const result=calculateMetricSet({events:persisted.rows.map(r=>r.payload),startAt:oracle.window_start_inclusive,endAt:oracle.window_end_exclusive,currency:'INR'})
 assert.equal(result.metrics.leads,10000);assert.equal(result.metrics.qualified_leads,2000);assert.equal(result.metrics.customers,1000)
 assert.equal(result.metrics.revenue,oracle.first_party.revenue_minor/100);assert.equal(result.metrics.refunds,oracle.first_party.refunds_minor/100);assert.equal(result.metrics.net_revenue,oracle.first_party.net_revenue_minor/100)
 assert.equal(result.metrics.impressions,10000);assert.equal(result.metrics.clicks,10000);assert.equal(result.metrics.roas,null,'no provider spend was injected into first-party events')
 report.firstPartyMetrics=result.metrics;report.checks.push('event classes, net revenue and independent first-party metric oracle reconcile')
})
test('D2 volume: application readers enforce explicit workspace filters and documented caps',{skip:!isolated},async()=>{
 assert.equal(report.eventsImported,100000,'complete event ingest prerequisite')
 for(const workspace of new Set(leads.map(l=>l.workspace_id))){assert.equal((await trackedEventStats(workspace)).total,25000);const rows=await listTrackedEvents(workspace,{limit:99999});assert.equal(rows.length,5000);for(const r of rows){assert.equal(r.email,undefined);assert.equal(r.phone,undefined)}}
 assert.equal((await trackedEventStats('qa_ace_v1_workspace_000005')).total,0)
 assert.deepEqual(await listTrackedEvents('qa_ace_v1_workspace_000005'),[])
 report.checks.push('four 25000-event workspace counts, 5000-read cap, empty workspace and no raw contact fields');report.dataLayerChecksComplete=true
})

test('D2 provider volume: 100 campaigns and 9000 daily rows pass actual connector adapters and replay',{skip:!isolated,timeout:300000},async t=>{
 assert.ok(root,'fixture prerequisite')
 const campaigns=JSON.parse(readFileSync(join(root,'campaigns.json')))
 const daily=JSON.parse(readFileSync(join(root,'campaign_daily_stats.json')))
 assert.equal(campaigns.length,100);assert.equal(daily.length,9000)
 const catalog=new Map(campaigns.map(c=>[c.campaign_id,c]))
 const connectors={META:'Meta Ads',GOOG:'Google Ads',XADS:'X',TIK:'TikTok Ads',LINK:'LinkedIn Ads',PIN:'Pinterest',MS:'Microsoft Ads'}
 const groups=new Map()
 for(const row of daily){const c=catalog.get(row.campaign_id);assert.ok(c);assert.equal(row.workspace_id,c.workspace_id);const key=[c.workspace_id,c.provider_code,c.provider_account_id].join('|');if(!groups.has(key))groups.set(key,[]);groups.get(key).push({...row,c})}
 const previous={google:process.env.GOOGLE_ADS_DEVELOPER_TOKEN,microsoft:process.env.MICROSOFT_ADS_DEVELOPER_TOKEN}
 process.env.GOOGLE_ADS_DEVELOPER_TOKEN='SIM_DEVELOPER';process.env.MICROSOFT_ADS_DEVELOPER_TOKEN='SIM_DEVELOPER'
 const response=value=>new Response(JSON.stringify(value),{headers:{'content-type':'application/json'}})
 let active,zip
 t.mock.method(globalThis,'fetch',async(raw)=>{
  const url=new URL(raw);const rows=active.rows
  const wire=rows.map(r=>({id:r.c.provider_campaign_id,name:r.c.name,day:r.date,spend:Number(r.spend_minor)/100,impressions:Number(r.impressions),clicks:Number(r.clicks)}))
  switch(active.code){
   case 'META':assert.equal(url.origin,'https://graph.facebook.com');return response({data:wire.map(r=>({campaign_id:r.id,campaign_name:r.name,date_start:r.day,spend:String(r.spend),impressions:String(r.impressions),clicks:String(r.clicks),actions:[],action_values:[]}))})
   case 'GOOG':assert.equal(url.origin,'https://googleads.googleapis.com');return response([{results:wire.map(r=>({campaign:{id:r.id,name:r.name},segments:{date:r.day},customer:{currencyCode:'INR'},metrics:{costMicros:Math.round(r.spend*1e6),impressions:r.impressions,clicks:r.clicks}}))}])
   case 'XADS':assert.equal(url.origin,'https://93.184.216.34');return response({data:wire.map(r=>({campaign_id:r.id,campaign_name:r.name,date:r.day,currency:'INR',spend:r.spend,impressions:r.impressions,clicks:r.clicks}))})
   case 'TIK':assert.equal(url.origin,'https://business-api.tiktok.com');return response({code:0,data:{list:wire.map(r=>({dimensions:{campaign_id:r.id,stat_time_day:r.day},metrics:{campaign_name:r.name,spend:r.spend,impressions:r.impressions,clicks:r.clicks}})),page_info:{total_page:1}}})
   case 'LINK':assert.equal(url.origin,'https://api.linkedin.com');return response({elements:wire.map(r=>{const [year,month,day]=r.day.split('-').map(Number);return {pivotValues:['urn:li:sponsoredCampaign:'+r.id],dateRange:{start:{year,month,day}},costInLocalCurrency:r.spend,impressions:r.impressions,clicks:r.clicks}})})
   case 'PIN':assert.equal(url.origin,'https://api.pinterest.com');return response(wire.map(r=>({CAMPAIGN_ID:r.id,CAMPAIGN_NAME:r.name,DATE:r.day,SPEND_IN_MICRO_DOLLAR:Math.round(r.spend*1e6),IMPRESSION_1:r.impressions,CLICKTHROUGH_1:r.clicks})))
   case 'MS':
    if(url.origin==='https://93.184.216.34'){assert.equal(url.pathname,'/sim-report.zip');return new Response(zip)}
    assert.equal(url.origin,'https://reporting.api.bingads.microsoft.com')
    if(url.pathname.endsWith('/Submit'))return response({ReportRequestId:'SIM_REPORT'})
    assert.ok(url.pathname.endsWith('/Poll'));return response({ReportRequestStatus:{Status:'Success',ReportDownloadUrl:'https://93.184.216.34/sim-report.zip'}})
   default:throw new Error('unexpected fixture provider')
  }
 })
 try{
  for(const [key,rows] of groups){
   const [workspaceId,code,sourceAccount]=key.split('|'),connector=connectors[code]
   active={code,rows}
   // Microsoft requires numeric account IDs; this run-owned alias is not a live account.
   const accountId=code==='MS'?'123456':sourceAccount
   await withWorkspace(workspaceId,()=>mutateState(s=>{s.connectorCredentials=[{id:'SIM_CREDENTIAL',connector,encrypted:encryptSecret({access_token:'SIM_ACCESS_TOKEN'}),expiresAt:null}]}))
   if(code==='MS'){
    const csv=['TimePeriod,AccountId,CampaignId,CampaignName,CurrencyCode,Impressions,Clicks,Spend,ConversionsQualified,Revenue',...rows.map(r=>[r.date,accountId,r.c.provider_campaign_id,r.c.name,'INR',r.impressions,r.clicks,Number(r.spend_minor)/100,0,0].join(','))].join('\n')
    // Standard ZIP creation, not a replacement for the application's ZIP parser.
    zip=execFileSync('python3',['-c','import io,sys,zipfile; b=io.BytesIO(); z=zipfile.ZipFile(b,"w",zipfile.ZIP_DEFLATED); z.writestr("report.csv",sys.stdin.buffer.read()); z.close(); sys.stdout.buffer.write(b.getvalue())'],{input:csv})
   }
   const ctx={workspaceId,connector,mode:'backfill',start:oracle.window_start_inclusive,end:oracle.window_end_exclusive,options:{accountId,customerId:accountId,advertiserId:accountId,url:'https://93.184.216.34/sim-report'}}
   const first=await runConnectorSync(ctx);assert.equal(first.normalized,rows.length);assert.equal(first.rawInserted,rows.length)
   const replay=await runConnectorSync(ctx);assert.equal(replay.normalized,rows.length);assert.equal(replay.rawInserted,0)
   const persisted=(await pool.query('SELECT campaign_id,day,spend,impressions,clicks FROM ace_campaign_daily WHERE workspace_id=$1 AND connector=$2',[workspaceId,connector])).rows
   assert.equal(persisted.length,rows.length)
   const expected=new Map(rows.map(r=>[r.c.provider_campaign_id+'|'+r.date,r]))
   for(const r of persisted){const date=r.day instanceof Date?r.day.toISOString().slice(0,10):String(r.day).slice(0,10);const source=expected.get(r.campaign_id+'|'+date);assert.ok(source);assert.equal(Math.round(Number(r.spend)*100),Number(source.spend_minor));assert.equal(Number(r.impressions),Number(source.impressions));assert.equal(Number(r.clicks),Number(source.clicks))}
  }
  const {rows}=await pool.query('SELECT count(*)::int n,count(DISTINCT campaign_id)::int campaigns,sum(spend) spend,sum(impressions) impressions,sum(clicks) clicks FROM ace_campaign_daily')
  assert.equal(rows[0].n,9000);assert.equal(rows[0].campaigns,100)
  assert.equal(Math.round(Number(rows[0].spend)*100),oracle.provider_daily.spend_minor)
  assert.equal(Number(rows[0].impressions),oracle.provider_daily.impressions);assert.equal(Number(rows[0].clicks),oracle.provider_daily.clicks)
  report.providerCampaignRowsImported=9000;report.providerCampaignsObserved=100;report.providerDaily=rows[0]
  report.providerScope='Actual adapter/database integration; external fetch simulated. X uses supported reporting bridge. Campaign lifecycle snapshots and native live contracts remain unqualified.'
  report.checks.push('all 9000 provider daily rows and 100 campaign IDs match original scope, spend, impressions and clicks after replay')
 }finally{
  for(const [name,value] of [['GOOGLE_ADS_DEVELOPER_TOKEN',previous.google],['MICROSOFT_ADS_DEVELOPER_TOKEN',previous.microsoft]]){if(value===undefined)delete process.env[name];else process.env[name]=value}
 }
})
