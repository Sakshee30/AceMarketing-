import {createHash,randomUUID} from 'node:crypto'
import {pool,embeddedDatabase} from './database.mjs'
import {handleRecordUsage} from '../modules/usage/src/application/commands/record-usage/record-usage.handler.mjs'
const evalIntervalMs=Number(process.env.MONITORING_EVAL_INTERVAL_MS||60000)
const retentionDays=Number(process.env.API_METRIC_RETENTION_DAYS||30)

const lastEval=new Map()
const monitoringRuleId=(workspaceId,metric)=>'mr_'+createHash('sha256').update(String(workspaceId)+'\n'+String(metric)).digest('hex').slice(0,40)

const usageColumn=(method,path)=>{
  if(method==='POST'&&path==='/api/track') return 'tracked_events'
  if(method==='POST'&&path==='/api/assisted-events') return 'assisted_events'
  if(method==='POST'&&path==='/api/signal-deliveries/dispatch') return 'signal_dispatches'
  if(method==='POST'&&(path.startsWith('/api/qualification-calls')||path.startsWith('/api/meetings/remind')||path.startsWith('/api/feedback/request'))) return 'agent_actions'
  if(method==='POST'&&path==='/api/audiences/sync') return 'audience_syncs'
  if(method==='POST'&&path==='/api/custom-integrations/test') return 'custom_integration_tests'
  return null
}

const ensureRules=async workspaceId=>{
  if(!pool)return
  const defaults=[
    ['api_error_rate','gt',2,'critical',10],
    ['api_p95_latency_ms','gt',2000,'warning',10],
    ['dead_letter_jobs','gt',0,'critical',5],
    ['audience_sync_errors','gt',0,'warning',15],
    ['tracking_inactivity_minutes','gt',30,'warning',30],
    ['signal_delivery_backlog_minutes','gt',15,'critical',15]
  ]
  for(const [metric,operator,threshold,severity,windowMinutes] of defaults){
    await pool.query(
      `INSERT INTO ace_monitoring_rules (id,workspace_id,metric,operator,threshold,severity,window_minutes)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (workspace_id,metric) DO NOTHING`,
      [monitoringRuleId(workspaceId,metric),workspaceId,metric,operator,threshold,severity,windowMinutes]
    )
  }
}

const compare=(value,operator,threshold)=>{
  if(operator==='gt')return value>threshold
  if(operator==='gte')return value>=threshold
  if(operator==='lt')return value<threshold
  if(operator==='lte')return value<=threshold
  return false
}

const metricSnapshot=async(workspaceId,windowMinutes=10)=>{
  if(embeddedDatabase){
    const [api,jobs,audiences]=await Promise.all([
      pool.query(`SELECT COUNT(*)::int requests,COUNT(*) FILTER (WHERE status_code>=500)::int errors FROM ace_api_metrics WHERE workspace_id=$1`,[workspaceId]),
      pool.query(`SELECT COUNT(*)::int count FROM ace_jobs WHERE workspace_id=$1 AND status='dead_letter'`,[workspaceId]),
      pool.query(`SELECT COUNT(*)::int count FROM ace_audiences WHERE workspace_id=$1 AND status='error'`,[workspaceId])
    ])
    const value=api.rows[0]
    return {api_error_rate:value.requests?Number(((value.errors/value.requests)*100).toFixed(3)):0,api_p95_latency_ms:0,dead_letter_jobs:Number(jobs.rows[0]?.count||0),audience_sync_errors:Number(audiences.rows[0]?.count||0),tracking_inactivity_minutes:0,signal_delivery_backlog_minutes:0}
  }
  const [api,jobs,audiences,tracking,signalBacklog]=await Promise.all([
    pool.query(
      `SELECT COUNT(*)::int requests,
         COUNT(*) FILTER (WHERE status_code>=500)::int errors,
         COALESCE(percentile_disc(0.95) WITHIN GROUP (ORDER BY latency_ms),0)::int p95
       FROM ace_api_metrics
       WHERE workspace_id=$1 AND created_at>=now()-($2*interval '1 minute')`,
      [workspaceId,windowMinutes]
    ),
    pool.query(`SELECT COUNT(*)::int count FROM ace_jobs WHERE workspace_id=$1 AND status='dead_letter'`,[workspaceId]).catch(()=>({rows:[{count:0}]})),
    pool.query(`SELECT COUNT(*)::int count FROM ace_audiences WHERE workspace_id=$1 AND status='error'`,[workspaceId]).catch(()=>({rows:[{count:0}]})),
    pool.query(`SELECT EXTRACT(EPOCH FROM (now()-MAX(created_at)))/60 AS minutes
                FROM ace_api_metrics WHERE workspace_id=$1 AND method='POST' AND path='/api/track'`,[workspaceId]).catch(()=>({rows:[{minutes:0}]})),
    pool.query(`SELECT COALESCE(MAX(EXTRACT(EPOCH FROM (now()-created_at))/60),0)::numeric AS minutes
                FROM ace_jobs
                WHERE workspace_id=$1 AND kind='signal_delivery' AND status IN ('pending','retry','leased')`,[workspaceId]).catch(()=>({rows:[{minutes:0}]}))
  ])
  const a=api.rows[0]
  return {
    api_error_rate:a.requests?Number(((a.errors/a.requests)*100).toFixed(3)):0,
    api_p95_latency_ms:Number(a.p95||0),
    dead_letter_jobs:Number(jobs.rows[0]?.count||0),
    audience_sync_errors:Number(audiences.rows[0]?.count||0),
    tracking_inactivity_minutes:Number(tracking.rows[0]?.minutes||0),
    signal_delivery_backlog_minutes:Number(signalBacklog.rows[0]?.minutes||0)
  }
}

const titleFor=metric=>({
  api_error_rate:'API error rate above threshold',
  api_p95_latency_ms:'API p95 latency elevated',
  dead_letter_jobs:'Dead-letter jobs require review',
  audience_sync_errors:'Audience provider sync errors detected',
  tracking_inactivity_minutes:'Tracking activity has gone quiet',
  signal_delivery_backlog_minutes:'Signal delivery queue is falling behind'
}[metric]||metric)

const detailFor=(metric,value,threshold)=>({
  api_error_rate:`5xx error rate is ${value}% against a ${threshold}% threshold.`,
  api_p95_latency_ms:`API p95 latency is ${value}ms against a ${threshold}ms threshold.`,
  dead_letter_jobs:`${value} job(s) are in dead-letter state.`,
  audience_sync_errors:`${value} audience(s) are currently in provider error state.`,
  tracking_inactivity_minutes:`No tracked event has been observed for approximately ${Number(value).toFixed(1)} minutes; threshold is ${threshold} minutes.`,
  signal_delivery_backlog_minutes:`The oldest pending/retrying signal delivery is approximately ${Number(value).toFixed(1)} minutes old; threshold is ${threshold} minutes.`
}[metric]||`${metric} is ${value}; threshold is ${threshold}.`)

const ownerFor=metric=>({
  api_error_rate:'Platform engineering',
  api_p95_latency_ms:'Platform engineering',
  dead_letter_jobs:'Marketing operations',
  audience_sync_errors:'Marketing operations',
  tracking_inactivity_minutes:'Tracking / analytics owner',
  signal_delivery_backlog_minutes:'Activation operations'
}[metric]||'Workspace operations')

const recommendationFor=metric=>({
  api_error_rate:'Inspect recent 5xx routes, deployment changes and dependency failures; correlate request IDs before retrying affected operations.',
  api_p95_latency_ms:'Inspect slow API routes, database saturation and provider latency; compare p95 with the previous healthy window.',
  dead_letter_jobs:'Open Delivery, inspect the last error and provider response, fix credentials/payload issues, then replay the dead-letter queue.',
  audience_sync_errors:'Open Audiences and connector health, review provider errors and identity coverage, then rematerialize or resync after correction.',
  tracking_inactivity_minutes:'Check site/app installation, recent release changes, consent configuration and ingestion requests; send a controlled test event after verification.',
  signal_delivery_backlog_minutes:'Open Delivery and worker health, inspect queue age and connector credentials, then retry/replay only after the underlying destination issue is resolved.'
}[metric]||'Inspect the source evidence and recent changes before resolving the incident.')

const enrichAlert=row=>({
  ...row,
  owner:ownerFor(row.metric),
  affectedPeriod:(Number(row.window_minutes||0)||10)+' minute monitoring window',
  recommendation:recommendationFor(row.metric)
})

export const evaluateMonitoring=async workspaceId=>{
  if(!pool)return []
  await ensureRules(workspaceId)
  const {rows:rules}=await pool.query(`SELECT * FROM ace_monitoring_rules WHERE workspace_id=$1 AND enabled=true`,[workspaceId])
  const maxWindow=Math.max(1,...rules.map(x=>Number(x.window_minutes||10)))
  const values=await metricSnapshot(workspaceId,maxWindow)
  const opened=[]
  for(const rule of rules){
    const value=Number(values[rule.metric]??0)
    const threshold=Number(rule.threshold)
    const breached=compare(value,rule.operator,threshold)
    const existing=await pool.query(
      `SELECT * FROM ace_alert_incidents WHERE workspace_id=$1 AND rule_id=$2 AND status='open' ORDER BY detected_at DESC LIMIT 1`,
      [workspaceId,rule.id]
    )
    if(breached&&!existing.rowCount){
      const id='al_'+randomUUID()
      const {rows}=await pool.query(
        `INSERT INTO ace_alert_incidents
         (id,workspace_id,rule_id,metric,severity,title,source,detail,metric_value,threshold,status)
         VALUES ($1,$2,$3,$4,$5,$6,'Platform monitoring',$7,$8,$9,'open') RETURNING *`,
        [id,workspaceId,rule.id,rule.metric,rule.severity,titleFor(rule.metric),detailFor(rule.metric,value,threshold),value,threshold]
      )
      opened.push(rows[0])
    }
    if(!breached&&existing.rowCount){
      await pool.query(
        `UPDATE ace_alert_incidents SET status='resolved',resolved_at=now(),updated_at=now() WHERE id=$1`,
        [existing.rows[0].id]
      )
    }
  }
  return opened
}

export const recordApiTelemetry=async(workspaceId,{requestId,method,path,statusCode,latencyMs,usageReservationId=null})=>{
  if(!pool||!workspaceId||!path.startsWith('/api/'))return
  await pool.query(
    `INSERT INTO ace_api_metrics (workspace_id,request_id,method,path,status_code,latency_ms)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [workspaceId,String(requestId),String(method),String(path),Number(statusCode),Math.max(0,Math.round(Number(latencyMs)||0))]
  )
  const usage=usageColumn(String(method),String(path))
  const columns=['api_requests',...(statusCode<400&&usage?[usage]:[])].filter(Boolean)
  const updates=columns.map(x=>`${x}=ace_usage_daily.${x}+1`).join(',')
  await pool.query(
    `INSERT INTO ace_usage_daily (workspace_id,usage_date,${columns.join(',')})
     VALUES ($1,CURRENT_DATE,${columns.map(()=>1).join(',')})
     ON CONFLICT (workspace_id,usage_date) DO UPDATE SET ${updates}`,
    [workspaceId]
  )
  if(statusCode<400&&usage){
    await handleRecordUsage({
      workspaceId,
      eventId:'api:'+String(requestId)+':'+usage,
      metric:usage,
      quantity:1,
      requestId:String(requestId),
      reservationId:usageReservationId,
      source:'api',
      metadata:{method:String(method),path:String(path)}
    }).catch(()=>{})
  }
  const previous=lastEval.get(workspaceId)||0
  if(Date.now()-previous>=evalIntervalMs){
    lastEval.set(workspaceId,Date.now())
    await evaluateMonitoring(workspaceId).catch(()=>{})
  }
}

export const monitoringSnapshot=async workspaceId=>{
  if(!pool)return {available:false}
  await ensureRules(workspaceId)
  await evaluateMonitoring(workspaceId)
  const recentQuery=embeddedDatabase
    ?`SELECT COUNT(*)::int requests,COUNT(*) FILTER (WHERE status_code>=500)::int errors,0::int p95 FROM ace_api_metrics WHERE workspace_id=$1`
    :`SELECT COUNT(*)::int requests,COUNT(*) FILTER (WHERE status_code>=500)::int errors,COALESCE(percentile_disc(0.95) WITHIN GROUP (ORDER BY latency_ms),0)::int p95 FROM ace_api_metrics WHERE workspace_id=$1 AND created_at>=now()-interval '15 minutes'`
  const dayQuery=embeddedDatabase
    ?recentQuery
    :`SELECT COUNT(*)::int requests,COUNT(*) FILTER (WHERE status_code>=500)::int errors,COALESCE(percentile_disc(0.95) WITHIN GROUP (ORDER BY latency_ms),0)::int p95 FROM ace_api_metrics WHERE workspace_id=$1 AND created_at>=now()-interval '24 hours'`
  const boardMoveQuery=embeddedDatabase
    ?`SELECT COUNT(*)::int requests,COUNT(*) FILTER (WHERE status_code>=400)::int failures FROM ace_api_metrics WHERE workspace_id=$1 AND path LIKE '/api/boards/%/moves'`
    :`SELECT COUNT(*)::int requests,COUNT(*) FILTER (WHERE status_code>=400)::int failures FROM ace_api_metrics WHERE workspace_id=$1 AND path LIKE '/api/boards/%/moves' AND created_at>=now()-interval '15 minutes'`
  const [recent,day,usage,rules,alerts,boardMoves]=await Promise.all([
    pool.query(
      recentQuery,
      [workspaceId]
    ),
    pool.query(
      dayQuery,
      [workspaceId]
    ),
    pool.query(
      `SELECT
       COALESCE(SUM(api_requests),0)::bigint api_requests,
       COALESCE(SUM(tracked_events),0)::bigint tracked_events,
       COALESCE(SUM(assisted_events),0)::bigint assisted_events,
       COALESCE(SUM(signal_dispatches),0)::bigint signal_dispatches,
       COALESCE(SUM(agent_actions),0)::bigint agent_actions,
       COALESCE(SUM(audience_syncs),0)::bigint audience_syncs,
       COALESCE(SUM(custom_integration_tests),0)::bigint custom_integration_tests
       FROM ace_usage_daily
       WHERE workspace_id=$1 AND usage_date>=date_trunc('month',CURRENT_DATE)::date`,
      [workspaceId]
    ),
    pool.query(`SELECT * FROM ace_monitoring_rules WHERE workspace_id=$1 ORDER BY severity,metric`,[workspaceId]),
    pool.query(`SELECT i.*,r.window_minutes
                FROM ace_alert_incidents i
                LEFT JOIN ace_monitoring_rules r ON r.id=i.rule_id AND r.workspace_id=i.workspace_id
                WHERE i.workspace_id=$1 ORDER BY i.detected_at DESC LIMIT 50`,[workspaceId]),
    pool.query(boardMoveQuery,[workspaceId])
  ])
  const r=recent.rows[0],d=day.rows[0],u=usage.rows[0],b=boardMoves.rows[0]||{}
  return {
    available:true,
    status:Number(r.errors||0)===0?'healthy':'degraded',
    requests15m:Number(r.requests||0),
    eventsPerMinute:Number((Number(r.requests||0)/15).toFixed(1)),
    failedEventRate:Number(r.requests?((r.errors/r.requests)*100).toFixed(3):0),
    p95LatencyMs:Number(r.p95||0),
    boardMoves15m:Number(b.requests||0),
    boardMoveFailureRate:Number(b.requests?((b.failures/b.requests)*100).toFixed(3):0),
    last24h:{
      requests:Number(d.requests||0),
      errorRate:Number(d.requests?((d.errors/d.requests)*100).toFixed(3):0),
      p95LatencyMs:Number(d.p95||0)
    },
    usage:Object.fromEntries(Object.entries(u).map(([k,v])=>[k,Number(v||0)])),
    rules:rules.rows,
    recentAlerts:alerts.rows.map(enrichAlert)
  }
}

export const listAlerts=async workspaceId=>{
  if(!pool)return []
  await evaluateMonitoring(workspaceId)
  const {rows}=await pool.query(`SELECT i.*,r.window_minutes
                                FROM ace_alert_incidents i
                                LEFT JOIN ace_monitoring_rules r ON r.id=i.rule_id AND r.workspace_id=i.workspace_id
                                WHERE i.workspace_id=$1
                                ORDER BY CASE WHEN i.status='open' THEN 0 ELSE 1 END,i.detected_at DESC LIMIT 200`,[workspaceId])
  return rows.map(enrichAlert)
}

export const resolveAlert=async(workspaceId,id)=>{
  if(!pool)return null
  const {rows}=await pool.query(
    `UPDATE ace_alert_incidents SET status='resolved',resolved_at=now(),updated_at=now()
     WHERE workspace_id=$1 AND id=$2 RETURNING *`,
    [workspaceId,id]
  )
  return rows[0]||null
}

export const listMonitoringRules=async workspaceId=>{
  if(!pool)return []
  await ensureRules(workspaceId)
  const {rows}=await pool.query(`SELECT * FROM ace_monitoring_rules WHERE workspace_id=$1 ORDER BY severity,metric`,[workspaceId])
  return rows
}

export const saveMonitoringRule=async(workspaceId,input={})=>{
  if(!pool)return null
  const allowedMetrics=['api_error_rate','api_p95_latency_ms','dead_letter_jobs','audience_sync_errors','tracking_inactivity_minutes','signal_delivery_backlog_minutes']
  const metric=String(input.metric||'')
  const operator=String(input.operator||'gt')
  const threshold=Number(input.threshold)
  const severity=String(input.severity||'warning')
  if(!allowedMetrics.includes(metric))throw new Error('unsupported monitoring metric')
  if(!['gt','gte','lt','lte'].includes(operator))throw new Error('invalid monitoring operator')
  if(!Number.isFinite(threshold))throw new Error('valid threshold required')
  if(!['info','warning','critical'].includes(severity))throw new Error('invalid severity')
  const id=monitoringRuleId(workspaceId,metric)
  const {rows}=await pool.query(
    `INSERT INTO ace_monitoring_rules (id,workspace_id,metric,operator,threshold,severity,window_minutes,enabled)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     ON CONFLICT (workspace_id,metric) DO UPDATE SET
       operator=EXCLUDED.operator,threshold=EXCLUDED.threshold,severity=EXCLUDED.severity,window_minutes=EXCLUDED.window_minutes,enabled=EXCLUDED.enabled,updated_at=now()
     RETURNING *`,
    [id,workspaceId,metric,operator,threshold,severity,Math.max(1,Math.min(1440,Number(input.windowMinutes||10))),input.enabled!==false]
  )
  return rows[0]
}

export const purgeOldMetrics=async()=>{
  if(!pool)return 0
  const result=await pool.query(`DELETE FROM ace_api_metrics WHERE created_at<now()-($1*interval '1 day')`,[retentionDays])
  return result.rowCount||0
}

export const closeObservability=async()=>{if(pool)await pool.end()}
