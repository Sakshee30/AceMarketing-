import http from 'node:http'
import { createHash, createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto'
import { URL } from 'node:url'
import { createToken, verifyToken, hashPassword, hasPermission, createRateLimiter, securityHeaders, resolveCorsOrigin } from './security.mjs'
import { closeStore, getState, mutateState, storageHealth, withWorkspace } from './store.mjs'
import { connectorVaultReady, decryptSecret, encryptSecret } from './vault.mjs'
import { getJob, queueAvailable, queueStats, requestJobCancellation } from './queue.mjs'
import { attributionStats, captureClickSession, closeAttributionStore, recordAssistedEvent, reconcileAttribution } from './attribution-store.mjs'
import { audienceOpsStats, closeLeadOps, createActivationRun, createAudience as createLeadAudience, getAudienceBundle, getLeadProfile, leadOpsStats, listActivationRuns, listAudiences as listLeadAudiences, listLeadProfiles, materializeAudience, overrideLeadGrade as persistLeadGrade, previewAudience as previewLeadAudience, scoreLead, upsertLeadProfile, updateAudienceSyncState } from './lead-ops.mjs'
import { closeAgentOrchestrator, completeFollowUp as persistCompleteFollowUp, createAgentRun, createFollowUp, createMeeting, getMeeting, listAgentRuns, listFeedback as listPersistedFeedback, listFollowUps as listPersistedFollowUps, listMeetings as listPersistedMeetings, listRoutingDecisions, recordFeedback, rescheduleMeeting, routeLead, updateAgentRun } from './agent-orchestrator.mjs'
import { closeCustomIntegrations, createCustomIntegration as persistCustomIntegration, listCustomIntegrations, testCustomIntegration as runCustomIntegrationTest } from './custom-integrations.mjs'
import { closeObservability, listAlerts as listLiveAlerts, listMonitoringRules as listLiveMonitoringRules, monitoringSnapshot, recordApiTelemetry, resolveAlert as resolveLiveAlert, saveMonitoringRule } from './observability.mjs'
import { closeEntitlements, finalizeReservation, resourceCountAllowed, subscriptionSummary } from './entitlements.mjs'
import { billingConfigured, billingEventHistory, billingReconciliationHistory, closeBillingProvider, createCheckoutSession, createPortalSession, verifyStripeWebhook } from './billing-provider.mjs'
import { closeConsentStore, consentAllows, consentStats, getConsent, listConsentAudit, saveConsent } from './consent.mjs'
import { closePrivacyOps, deleteSubject, exportSubject, listPrivacyRequests, purgeRetention, retentionPolicy } from './privacy-ops.mjs'
import { closeAudienceScheduler, listAudienceRefreshRuns, listAudienceSchedules, saveAudienceSchedule } from './audience-scheduler.mjs'
import { closeCohortAnalytics, cohortAnalytics } from './cohort-analytics.mjs'
import {connectorReadCatalog,listConnectorSyncRuns,connectorDataSummary,listConnectorSyncSchedules,saveConnectorSyncSchedule} from './connector-ingestion.mjs'
import {appendTrackedEvent,listTrackedEvents,trackedEventStats} from './tracked-events.mjs'
import {trackingInputError} from './tracking-input.mjs'
import { closeReportScheduler, listReportDeliveries, listReportSchedules, queueReportNow, reportMailConfigured, saveReportSchedule } from './report-scheduler.mjs'
import { closeEventRules, createEventRule, evaluateEventRules, eventRuleStats, listEventRuleRuns, listEventRules, markEventRuleActivation, setEventRuleEnabled } from './event-rules.mjs'
import { publicNavigation, publicIndustries, publicAgents, publicIntegrations, publicChallenges, publicCaseStudies, publicResources, publicResourceCenter } from './public-content.mjs'
import { parseWhatsAppWebhook, resolveWhatsAppWorkspace, sendWhatsAppMessage, verifyWhatsAppWebhookChallenge, verifyWhatsAppWebhookSignature } from './whatsapp-cloud.mjs'
import { normalizeCallEvent, resolveCallWorkspace, verifyCallWebhook } from './call-events.mjs'
import { createCalendarEvent, updateCalendarEvent } from './calendar-provider.mjs'
import { modelCatalogItems, modelRegistryItem, registrySummary } from './ai-registry.mjs'
import { verifyProviderAccess } from './ai-providers.mjs'
import { closeAiRuntime, listAiResults } from './ai-runtime.mjs'
import { getMlCapabilities, mlServiceConfigured } from './ml-client.mjs'
import { closeKnowledge, ingestKnowledgeText, listKnowledgeSources, revokeKnowledgeSource } from './knowledge.mjs'
import { deployModel, getEvaluationPolicy, getTenantRegistry, listEvaluations, promoteModel, qualifyEvaluation, recordProviderAccessVerification, rollbackModel, syncTenantRegistry, undeployModel, upsertEvaluationPolicy } from './ai-registry-store.mjs'
import { closeAiDatasets, createAiDataset, getAiDataset, listAiDatasets, retireAiDataset, trainingRequestFromDataset, trainingRequestFromDatasetWithHorizon } from './ai-datasets.mjs'
import { metricCatalog } from './metric-catalog.mjs'
import { closeLiveVoice, createLiveVoiceSession, getLiveVoiceSession, installLiveVoiceWebSocket, terminateLiveVoiceSession } from './live-voice.mjs'
import { validateHostedTaskInput } from './ai-input-validation.mjs'
import { evaluateAiTaskAdmission, getAiTaskPolicy, listAiTaskPolicies, listCreativeAssets, listTranscripts, reviewCreativeAsset, saveAiTaskPolicy } from './ai-governance-store.mjs'
import { getSegmentMemberships, listAnomalyItems, listCausalRecords, listForecastRecords, listMarketingMixRecords, listRankingItems, listSegmentSnapshots, reviewAnomalyItem } from './ai-domain-results.mjs'
import { approveAiActivationProposal, attachActivationProposalReviewerJob, createAiActivationProposal, listAiActivationProposals, markActivationProposalReviewerBlocked, rejectAiActivationProposal } from './ai-activation-proposals.mjs'
import {analystToolNames,executeAnalystTool,executeAnalystToolSet} from './ai-analyst-tools.mjs'
import {deploymentHealth,listDeploymentControls,saveDeploymentControl} from './ai-deployment-controls.mjs'
import {aiMonitoringSnapshot} from './ai-monitoring.mjs'
import {bindActorToRequestContext,createRequestContext} from './platform/request-context.mjs'
import {globalAdmission} from './platform/admission-control.mjs'
import {assertActorWorkspace,requestedWorkspaceId,tenantExecutionScope} from './platform/tenant-context.mjs'
import {appendAuditRecord,listAuditRecords} from './platform/audit-store.mjs'
import {permissionForRequest as centralizedPermissionForRequest} from './platform/access-policy.mjs'
import {assertWorkspaceMembership,seedWorkspaceCreator,listActorWorkspaces} from './platform/workspace-access.mjs'
import {validateOutboundDestination} from './platform/egress-policy.mjs'
import {markInboxProcessed,recordInboxEvent} from './platform/reliability-store.mjs'
import {createWebhookSubscription,createWebhookTestDelivery,listWebhookDeliveries,listWebhookDeliveryAttempts,listWebhookSubscriptions,replayWebhookDelivery,setWebhookSubscriptionStatus} from './platform/webhook-delivery-store.mjs'
import {createForm,getForm,listForms,listFormSubmissions,publishForm,submitForm} from './platform/forms-store.mjs'
import {createCustomObject,createCustomObjectRecord,createCustomObjectVersion,getCustomObject,listCustomObjectRecords,listCustomObjects,publishCustomObject} from './platform/custom-object-store.mjs'
import {archivePolicyRule,createPolicyRule,createPolicyRuleVersion,evaluatePublishedPolicyRule,getPolicyRule,listPolicyRules,publishPolicyRule,simulatePolicyExpression} from './platform/policy-engine.mjs'
import {archiveWorkflow,cancelWorkflowExecution,createWorkflow,createWorkflowApproval,createWorkflowVersion,decideWorkflowApproval,getWorkflow,listWorkflowApprovals,listWorkflowExecutionSteps,listWorkflowExecutions,listWorkflows,publishWorkflow,retryWorkflowExecution,simulateWorkflowDefinition,startWorkflowExecution} from './platform/workflow-store.mjs'
import {workflowActionCatalog} from './platform/workflow-action-catalog.mjs'
import {createDownloadGrant,createUploadIntent,listObjects,markObjectQuarantined,softDeleteObject} from './platform/object-lifecycle.mjs'
import {markObjectProcessingFailure} from './platform/document-processing.mjs'
import {querySearch,searchCapabilityProfile} from './platform/search-port.mjs'
import {runtimeGuardForRequest} from './platform/runtime-config-runtime.mjs'
import {beginProcessDrain,livenessState,markStartupComplete,readinessState,startupState} from './platform/process-health.mjs'
import {runtimeRoleAllows,runtimeRolePolicy} from './platform/runtime-role.mjs'
import {assertWorkspaceCell} from './platform/cell-placement.mjs'
import {createBoard,getBoardOperation,getBoardSnapshot,listBoards} from './platform/board-store.mjs'
import {moveCardController} from '../modules/boards/src/interfaces/http/move-card.controller.mjs'
import {evaluateAccessPermission} from '../modules/authorization/src/application/queries/evaluate-access/evaluate-access.handler.mjs'
import {handlePublishForm} from '../modules/forms/src/application/commands/publish-form/publish-form.handler.mjs'
import {handleSubmitForm} from '../modules/forms/src/application/commands/submit-form/submit-form.handler.mjs'
import {handleSimulateRule} from '../modules/rules/src/application/queries/simulate-rule/simulate-rule.handler.mjs'
import {handleUpdateWorkspace} from '../modules/workspaces/src/application/commands/update-workspace/update-workspace.handler.mjs'
import {handleRemoveMember} from '../modules/memberships/src/application/commands/remove-member/remove-member.handler.mjs'
import {handlePublishRule} from '../modules/rules/src/application/commands/publish-rule/publish-rule.handler.mjs'
import {handlePublishWorkflow} from '../modules/workflows/src/application/commands/publish-workflow/publish-workflow.handler.mjs'
import {handleRetryWorkflowExecution} from '../modules/workflows/src/application/commands/retry-step/retry-step.handler.mjs'
import {handleDecideApproval} from '../modules/approvals/src/application/commands/decide-approval/decide-approval.handler.mjs'
import {handleEvaluateEntitlement} from '../modules/entitlements/src/application/queries/evaluate-entitlement/evaluate-entitlement.handler.mjs'
import {handleDefineCustomObject} from '../modules/custom-objects/src/application/commands/define-object/define-object.handler.mjs'
import {handleQuerySearch} from '../modules/search/src/application/queries/query-search/query-search.handler.mjs'
import {handleAuthorizeUpload} from '../modules/documents/src/application/commands/authorize-upload/authorize-upload.handler.mjs'
import {handleConnectProvider} from '../modules/integrations/src/application/commands/connect-provider/connect-provider.handler.mjs'
import {handleReconcileIntegration} from '../modules/integrations/src/application/commands/reconcile-sync/reconcile-sync.handler.mjs'
import {handleReplayWebhookDelivery} from '../modules/webhooks/src/application/commands/replay-delivery/replay-delivery.handler.mjs'
import {handleReserveQuota} from '../modules/usage/src/application/commands/reserve-quota/reserve-quota.handler.mjs'
import {handleChangeSubscription} from '../modules/billing/src/application/commands/change-subscription/change-subscription.handler.mjs'
import {handleReconcilePayment} from '../modules/billing/src/application/commands/reconcile-payment/reconcile-payment.handler.mjs'
import {handleSubmitJob} from '../modules/jobs/src/application/commands/submit-job/submit-job.handler.mjs'
import {handleSendNotification} from '../modules/notifications/src/application/commands/send-notification/send-notification.handler.mjs'
import {handleRunReport} from '../modules/reporting/src/application/commands/run-report/run-report.handler.mjs'
import {handleStartLogin} from '../modules/identity/src/application/commands/start-login/start-login.handler.mjs'
import {handleRecoverAccount} from '../modules/identity/src/application/commands/recover-account/recover-account.handler.mjs'
import {handleApproveFile} from '../modules/documents/src/application/commands/approve-file/approve-file.handler.mjs'
import {handleRebuildSearchIndex} from '../modules/search/src/application/commands/rebuild-index/rebuild-index.handler.mjs'
import {handleUpdateOrganization} from '../modules/organizations/src/application/commands/update-organization/update-organization.handler.mjs'
import {handlePublishPolicy} from '../modules/authorization/src/application/commands/publish-policy/publish-policy.handler.mjs'
import {handleRequestInference} from '../modules/ai/src/application/commands/request-inference/request-inference.handler.mjs'
import {handleActivateModelResult} from '../modules/ai/src/application/commands/activate-model-result/activate-model-result.handler.mjs'
import {handleReplayDeadLetter} from '../modules/jobs/src/application/commands/replay-dead-letter/replay-dead-letter.handler.mjs'
import {handleSearchAudit} from '../modules/audit/src/application/queries/search-audit/search-audit.handler.mjs'
import {handleExportAudit} from '../modules/audit/src/application/commands/export-audit/export-audit.handler.mjs'

const runtimeRole=runtimeRolePolicy()

const CONNECTOR_PROVIDERS={
  'Google Ads':{
    provider:'google',
    authType:'oauth2',
    clientId:process.env.GOOGLE_OAUTH_CLIENT_ID||'',
    clientSecret:process.env.GOOGLE_OAUTH_CLIENT_SECRET||'',
    authorizeUrl:'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl:'https://oauth2.googleapis.com/token',
    scopes:['openid','email','https://www.googleapis.com/auth/adwords']
  },
  'Meta Ads':{
    provider:'meta',
    authType:'oauth2',
    clientId:process.env.META_OAUTH_CLIENT_ID||'',
    clientSecret:process.env.META_OAUTH_CLIENT_SECRET||'',
    authorizeUrl:'https://www.facebook.com/v23.0/dialog/oauth',
    tokenUrl:'https://graph.facebook.com/v23.0/oauth/access_token',
    scopes:['ads_management','ads_read','business_management']
  },
  'Microsoft Ads / Bing Ads':{provider:'microsoft_ads',authType:'oauth2',clientId:process.env.MICROSOFT_ADS_OAUTH_CLIENT_ID||'',clientSecret:process.env.MICROSOFT_ADS_OAUTH_CLIENT_SECRET||'',authorizeUrl:'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',tokenUrl:'https://login.microsoftonline.com/common/oauth2/v2.0/token',scopes:['openid','offline_access','https://ads.microsoft.com/msads.manage'],tokenScopes:['https://ads.microsoft.com/msads.manage','offline_access']},
  'LinkedIn Ads':{provider:'linkedin',authType:'oauth2',clientId:process.env.LINKEDIN_OAUTH_CLIENT_ID||'',clientSecret:process.env.LINKEDIN_OAUTH_CLIENT_SECRET||'',authorizeUrl:'https://www.linkedin.com/oauth/v2/authorization',tokenUrl:'https://www.linkedin.com/oauth/v2/accessToken',scopes:['rw_conversions','r_ads','r_ads_reporting']},
  'HubSpot':{provider:'hubspot',authType:'oauth2',clientId:process.env.HUBSPOT_OAUTH_CLIENT_ID||'',clientSecret:process.env.HUBSPOT_OAUTH_CLIENT_SECRET||'',authorizeUrl:'https://app.hubspot.com/oauth/authorize',tokenUrl:'https://api.hubapi.com/oauth/2026-03/token',scopes:['crm.objects.contacts.read','crm.objects.contacts.write','crm.objects.companies.read','crm.objects.deals.read']},
  'Salesforce':{provider:'salesforce',authType:'oauth2',clientId:process.env.SALESFORCE_OAUTH_CLIENT_ID||'',clientSecret:process.env.SALESFORCE_OAUTH_CLIENT_SECRET||'',authorizeUrl:'https://login.salesforce.com/services/oauth2/authorize',tokenUrl:'https://login.salesforce.com/services/oauth2/token',scopes:['api','refresh_token']},
  'Zoho CRM':{provider:'zoho',authType:'oauth2',clientId:process.env.ZOHO_OAUTH_CLIENT_ID||'',clientSecret:process.env.ZOHO_OAUTH_CLIENT_SECRET||'',authorizeUrl:'https://accounts.zoho.com/oauth/v2/auth',tokenUrl:'https://accounts.zoho.com/oauth/v2/token',scopes:['ZohoCRM.modules.ALL','ZohoCRM.settings.ALL']},
  'GA4':{provider:'google',authType:'oauth2',clientId:process.env.GOOGLE_OAUTH_CLIENT_ID||'',clientSecret:process.env.GOOGLE_OAUTH_CLIENT_SECRET||'',authorizeUrl:'https://accounts.google.com/o/oauth2/v2/auth',tokenUrl:'https://oauth2.googleapis.com/token',scopes:['openid','email','https://www.googleapis.com/auth/analytics.readonly']},
  'Google Calendar':{provider:'google',authType:'oauth2',clientId:process.env.GOOGLE_OAUTH_CLIENT_ID||'',clientSecret:process.env.GOOGLE_OAUTH_CLIENT_SECRET||'',authorizeUrl:'https://accounts.google.com/o/oauth2/v2/auth',tokenUrl:'https://oauth2.googleapis.com/token',scopes:['openid','email','https://www.googleapis.com/auth/calendar.events']},
  'WhatsApp':{provider:'meta',authType:'oauth2',clientId:process.env.META_OAUTH_CLIENT_ID||'',clientSecret:process.env.META_OAUTH_CLIENT_SECRET||'',authorizeUrl:'https://www.facebook.com/v23.0/dialog/oauth',tokenUrl:'https://graph.facebook.com/v23.0/oauth/access_token',scopes:['whatsapp_business_management','whatsapp_business_messaging']}
}
const SERVER_SECRET_CONNECTORS={
  'TikTok Ads':{
    provider:'tiktok',
    authType:'server_secret',
    capability:'native_server_capi',
    fields:[
      {key:'pixel_id',label:'Pixel / Event Source ID',secret:false},
      {key:'advertiser_id',label:'TikTok advertiser ID',secret:false},
      {key:'access_token',label:'Events / Reporting API access token',secret:true}
    ]
  },
  'Pinterest':{
    provider:'pinterest',
    authType:'server_secret',
    capability:'native_server_capi',
    fields:[
      {key:'ad_account_id',label:'Pinterest ad account ID',secret:false},
      {key:'access_token',label:'Conversions API access token',secret:true}
    ]
  },
  'Microsoft Ads CAPI':{
    provider:'microsoft_ads_capi',
    authType:'server_secret',
    capability:'native_server_capi',
    fields:[
      {key:'tag_id',label:'Microsoft UET tag ID',secret:false},
      {key:'capi_token',label:'Microsoft UET CAPI token',secret:true}
    ]
  },
  'X':{
    provider:'x_ads',
    authType:'server_secret',
    capability:'native_server_capi',
    fields:[
      {key:'pixel_id',label:'X Pixel ID',secret:false},
      {key:'access_token',label:'Conversion API access token',secret:true}
    ]
  }
}
const connectorTokenHealth=async(workspaceId)=>{
  const state=await getState()
  const connections=state.connectorConnections||[]
  const credentials=state.connectorCredentials||[]
  return connections.map(connection=>{
    const credential=credentials.find(x=>x.connector===connection.connector)
    const expiresAt=credential?.expiresAt||connection.expiresAt||null
    const expiresInSeconds=expiresAt?Math.floor((Date.parse(expiresAt)-Date.now())/1000):null
    const needsRefresh=expiresInSeconds!==null&&expiresInSeconds<=15*60
    const expired=expiresInSeconds!==null&&expiresInSeconds<=0
    return {
      connector:connection.connector,
      expiresAt,
      expiresInSeconds,
      needsRefresh,
      expired,
      status:expired?'expired':needsRefresh?'refresh_required':connection.status||'connected'
    }
  })
}

const refreshConnectorCredential=async(workspaceId,connector)=>{
  const provider=CONNECTOR_PROVIDERS[connector]
  if(!provider) throw new Error('connector does not support OAuth refresh')
  if(!provider.clientId||!provider.clientSecret) throw new Error('connector OAuth credentials are not configured')
  if(!connectorVaultReady()) throw new Error('connector credential vault is not configured')
  const state=await getState()
  const credential=(state.connectorCredentials||[]).find(x=>x.connector===connector)
  if(!credential?.encrypted) throw new Error(connector+' credential is not connected')
  const current=decryptSecret(credential.encrypted)
  const refreshToken=current?.refresh_token
  if(!refreshToken) throw new Error(connector+' did not provide a refresh token; reconnect the integration')
  const form=new URLSearchParams({
    grant_type:'refresh_token',
    refresh_token:String(refreshToken),
    client_id:provider.clientId,
    client_secret:provider.clientSecret
  })
  if(Array.isArray(provider.tokenScopes)&&provider.tokenScopes.length)form.set('scope',provider.tokenScopes.join(' '))
  const response=await fetch(provider.tokenUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form})
  const body=await response.json().catch(()=>({}))
  if(!response.ok||!body.access_token) throw new Error('OAuth token refresh failed: '+response.status)
  const merged={...current,...body,refresh_token:body.refresh_token||refreshToken}
  const now=new Date().toISOString()
  const expiresAt=body.expires_in?new Date(Date.now()+Number(body.expires_in)*1000).toISOString():credential.expiresAt||null
  await mutateState(s=>{
    const saved=(s.connectorCredentials||[]).find(x=>x.connector===connector)
    if(saved){saved.encrypted=encryptSecret(merged);saved.expiresAt=expiresAt;saved.updatedAt=now}
    const connection=(s.connectorConnections||[]).find(x=>x.connector===connector)
    if(connection){connection.status='connected';connection.expiresAt=expiresAt;connection.updatedAt=now}
    s.audit=s.audit||[]
    s.audit.unshift({id:randomUUID(),action:'connector.token_refreshed',entityId:connector,provider:provider.provider,at:now})
    s.audit=s.audit.slice(0,1000)
  })
  return {refreshed:true,expiresAt}
}

const CONNECTOR_REDIRECT_URI=process.env.CONNECTOR_OAUTH_REDIRECT_URI||''
const AUTH_GOOGLE_REDIRECT_URI=process.env.AUTH_GOOGLE_REDIRECT_URI||''
const AUTH_GOOGLE_SUCCESS_URL=process.env.AUTH_GOOGLE_SUCCESS_URL||''
const AUTH_PUBLIC_APP_URL=process.env.AUTH_PUBLIC_APP_URL||''
const CONNECTOR_SUCCESS_URL=process.env.CONNECTOR_OAUTH_SUCCESS_URL||''
const CONNECTOR_STATE_SECRET=process.env.CONNECTOR_OAUTH_STATE_SECRET||process.env.JWT_SECRET||'dev-only-change-me'
const base64url=value=>Buffer.from(value).toString('base64url')
const hashOAuthState=value=>createHash('sha256').update(String(value)).digest('hex')
const createOAuthState=workspaceId=>{
  const payload=Buffer.from(JSON.stringify({workspaceId,nonce:randomBytes(24).toString('base64url'),iat:Date.now()})).toString('base64url')
  const signature=createHmac('sha256',CONNECTOR_STATE_SECRET).update(payload).digest('base64url')
  return payload+'.'+signature
}
const parseOAuthState=value=>{
  try{
    const [payload,signature]=String(value||'').split('.')
    if(!payload||!signature) return null
    const expected=createHmac('sha256',CONNECTOR_STATE_SECRET).update(payload).digest()
    const actual=Buffer.from(signature,'base64url')
    if(actual.length!==expected.length||!timingSafeEqual(actual,expected)) return null
    const decoded=JSON.parse(Buffer.from(payload,'base64url').toString('utf8'))
    if(!decoded?.workspaceId||!/^[A-Za-z0-9_-]{1,64}$/.test(decoded.workspaceId)) return null
    if(!Number.isFinite(decoded.iat)||Date.now()-decoded.iat>15*60*1000) return null
    return decoded
  }catch{return null}
}
const createPkce=()=>{
  const verifier=base64url(randomBytes(48))
  const challenge=createHash('sha256').update(verifier).digest('base64url')
  return {verifier,challenge}
}

const PORT = Number(process.env.PORT || 3001)
const IS_PROD = process.env.NODE_ENV === 'production'
const AUTH_REQUIRED = process.env.AUTH_REQUIRED === 'true' || IS_PROD
const JWT_SECRET = process.env.JWT_SECRET || (IS_PROD ? '' : 'dev-only-change-me')
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || ''
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH || ''
const OBJECT_WORKER_TOKEN = process.env.OBJECT_WORKER_TOKEN || ''
const allowedOrigins = new Set((process.env.CORS_ALLOWED_ORIGINS || (IS_PROD ? '' : '*')).split(',').map(x=>x.trim()).filter(Boolean))
if (IS_PROD && (!JWT_SECRET || JWT_SECRET.length < 32)) throw new Error('JWT_SECRET must be at least 32 characters in production')
if (IS_PROD && CONNECTOR_STATE_SECRET.length < 32) throw new Error('CONNECTOR_OAUTH_STATE_SECRET must be at least 32 characters in production')
if (IS_PROD && (!ADMIN_EMAIL || !ADMIN_PASSWORD_HASH)) throw new Error('ADMIN_EMAIL and ADMIN_PASSWORD_HASH are required in production')
if (IS_PROD && allowedOrigins.size===0) throw new Error('CORS_ALLOWED_ORIGINS is required in production')
// The local workspace mounts many feature panels at once, so a shared loopback-IP
// limit of 240 can lock the developer out during a normal initial render. Keep the
// production default strict while allowing the full local dashboard to bootstrap.
const defaultRateLimitPerMinute=IS_PROD?240:5_000
const limitRequest=createRateLimiter({windowMs:60_000,max:Number(process.env.RATE_LIMIT_PER_MINUTE||defaultRateLimitPerMinute)})

const integrations = [
  'Ace Data Hub','Zoho CRM','Salesforce','LeadSquared','Meritto','HubSpot','HighLevel','Microsoft Dynamics 365','Freshsales','Custom CRM',
  'WhatsApp','Bitespeed','AiSensy','Gupshup','WATI','MoEngage','CleverTap','Mailchimp','Klaviyo','Brevo','Twilio SendGrid',
  'Exotel','Knowlarity','Tata Tele','MyOperator','Twilio',
  'Shopify','WooCommerce','Magento','WordPress','Typeform','React App','Custom Backend',
  'BigQuery','Snowflake','MongoDB','Oracle DB','Google Cloud Storage','Amazon S3',
  'Google Ads','Meta Ads','ChatGPT Ads','LinkedIn Ads','Microsoft Ads / Bing Ads','Microsoft Ads CAPI','X','Pinterest','TikTok Ads','Yahoo Ads','Taboola','Spotify Ads','Snapchat Ads','Criteo','DV360','Google Merchant Center','Meta Lead Ads','Meta CAPI','Meta Catalog','GA4','Google Calendar',
  'Apollo','Lusha','Calixa'
]
const agents = ['Meta Advanced CAPI','Google ECL / OCI','ChatGPT Ads CAPI','Call Tracking Events','Custom Integration','Lead Grading','CRM Enrichment','Voice Lead Qualification','Voice Scheduler','Meeting Reminder','Feedback Agent','Lead Reactivation','Attribution Agent','Deep Linking Agent','Fraud Detection Agent','Customer Journey Agent','Audiences Agent','Event Agent','Ask Ace']
const agentCatalog={
  'Meta Advanced CAPI':{category:'Lead Quality · Signal Return',description:'Send deduplicated server-side business outcomes to Meta Ads.',operationTab:'Delivery',action:'Operate Meta signal delivery',prerequisites:['Meta Ads connection','First-party identity','Business event']},
  'Google ECL / OCI':{category:'Lead Quality · Signal Return',description:'Return enhanced and offline conversion outcomes to Google Ads.',operationTab:'AdSync',action:'Operate Google conversion signals',prerequisites:['Google Ads connection','GCLID/GBRAID/WBRAID or hashed identity','Conversion action']},
  'ChatGPT Ads CAPI':{category:'Lead Quality · Signal Return',description:'Send server-side conversion events to ChatGPT Ads with oppref matching and event-ID deduplication.',operationTab:'ChatGPT Ads',action:'Operate ChatGPT Ads conversion measurement',prerequisites:['OPENAI_CONVERSIONS_API_KEY','OPENAI_ADS_PIXEL_ID','Consent-aware first-party conversion event']},
  'Call Tracking Events':{category:'Lead Quality · Signal Return',description:'Capture signed telephony events and attribute calls to acquisition context.',operationTab:'Calls',action:'Open call operations',prerequisites:['Call webhook provider','Customer or click identity']},
  'Custom Integration':{category:'Lead Quality · Signal Return',description:'Build tested adapters for proprietary CRM, backend, webhook or data systems.',operationTab:'Integrations',action:'Configure integrations',prerequisites:['Endpoint or source system','Authentication method','Field mapping']},
  'Lead Grading':{category:'Conversion · Handoff',description:'Score and prioritize persisted leads from CRM, journey and behavioral evidence.',operationTab:'Lead Grading',action:'Open lead grading',prerequisites:['Lead profiles','Journey or CRM evidence']},
  'CRM Enrichment':{category:'Conversion · Handoff',description:'Give sales acquisition, journey, behavior, call and messaging context before outreach.',operationTab:'Enrich',action:'Open enrichment',prerequisites:['Lead profile','CRM connection for writeback']},
  'Voice Lead Qualification':{category:'Conversion · Handoff',description:'Queue provider-backed qualification calls and preserve execution state.',operationTab:'Calls',action:'Open qualification calls',prerequisites:['Voice qualification provider','Lead phone','Approval policy']},
  'Voice Scheduler':{category:'Conversion · Handoff',description:'Create consultations from qualified leads and synchronize calendar context.',operationTab:'Meetings',action:'Open scheduling',prerequisites:['Qualified lead','Calendar or meeting provider']},
  'Meeting Reminder':{category:'Conversion · Handoff',description:'Send provider-backed reminders and persist reminder execution state.',operationTab:'Meetings',action:'Open reminders',prerequisites:['Scheduled meeting','Reminder provider']},
  'Feedback Agent':{category:'Conversion · Handoff',description:'Collect post-interaction feedback and surface objection themes.',operationTab:'Feedback',action:'Open feedback operations',prerequisites:['Customer interaction','Feedback provider or manual record']},
  'Lead Reactivation':{category:'Conversion · Recovery',description:'Detect renewed high-intent behavior from dormant leads and turn it into governed re-engagement work.',operationTab:'Follow-ups',action:'Open reactivation queue',prerequisites:['Persisted lead activity','Recent first-party intent event']},
  'Attribution Agent':{category:'Visibility & Attribution',description:'Inspect persisted first-touch, last-touch and assisted conversion evidence across stitched journeys.',operationTab:'Attribution',action:'Open attribution',prerequisites:['Tracked acquisition touch','Assisted conversion evidence']},
  'Deep Linking Agent':{category:'Tracking & Journey',description:'Create and operate governed deep-link routes with fallback destinations and activation evidence.',operationTab:'Deep Links',action:'Open deep links',prerequisites:['Destination route','Web fallback']},
  'Fraud Detection Agent':{category:'Tracking & Quality',description:'Surface suspicious identity and traffic patterns for review or blocking without silently discarding evidence.',operationTab:'Fraud',action:'Open fraud detection',prerequisites:['Tracked events','Identity or traffic evidence']},
  'Customer Journey Agent':{category:'Visibility & Attribution',description:'Explore stitched chronology across acquisition, CRM, calls, meetings, follow-ups and revenue outcomes.',operationTab:'Journeys',action:'Open customer journeys',prerequisites:['Persisted lead or customer identity','Journey events']},
  'Audiences Agent':{category:'Activation',description:'Build, materialize, suppress and sync first-party audiences from governed profile and behavioral evidence.',operationTab:'Audiences',action:'Open audience management',prerequisites:['Lead profiles','Consent-aware destination']},
  'Event Agent':{category:'Tracking & Activation',description:'Define safe business-event transformations and activate approved derived signals to destinations.',operationTab:'Events',action:'Open event manager',prerequisites:['Source event','Business condition']},
  'Ask Ace':{category:'Visibility & Attribution',description:'Query stitched journey, attribution, lead quality, audience and signal evidence in natural language.',operationTab:'Ask Ace',action:'Ask workspace questions',prerequisites:['Workspace evidence']}
}
const trackedEventsByWorkspace = new Map()

const leadReactivationCandidates=(profiles=[],events=[],followUps=[],options={})=>{
  const dormantDays=Math.max(7,Math.min(365,Number(options.dormantDays||30)))
  const recentDays=Math.max(1,Math.min(30,Number(options.recentDays||7)))
  const now=Date.now()
  const dormantCutoff=now-dormantDays*24*60*60*1000
  const recentCutoff=now-recentDays*24*60*60*1000
  const highIntent=/pricing|checkout|book|consult|apply|purchase|revenue|qualified|enrol|demo|contact_sales/i
  const openReactivation=new Set(
    (followUps||[])
      .filter(x=>x.status==='open'&&/reactivat/i.test(String(x.reason||'')))
      .map(x=>String(x.lead_ref||'').toLowerCase())
  )
  const candidates=[]
  for(const lead of profiles||[]){
    const leadRef=String(lead.external_lead_id||lead.name||lead.id||'')
    if(!leadRef||openReactivation.has(leadRef.toLowerCase()))continue
    const lastRaw=lead.journey?.previousLastActivity||lead.journey?.lastActivity||lead.journey?.last_activity||null
    if(!lastRaw)continue
    const lastTime=Date.parse(lastRaw)
    if(!Number.isFinite(lastTime)||lastTime>dormantCutoff)continue
    const matches=(events||[]).filter(event=>{
      const at=Date.parse(event.receivedAt||event.occurredAt||event.timestamp||'')
      if(!Number.isFinite(at)||at<recentCutoff)return false
      const name=String(event.event||event.eventType||event.name||'')
      if(!highIntent.test(name))return false
      const customer=String(event.customerId||event.customer_id||'')
      const device=String(event.deviceId||event.device_id||'')
      return customer===String(lead.external_lead_id||'')||(lead.device_id&&device===String(lead.device_id))
    }).sort((a,b)=>Date.parse(b.receivedAt||b.occurredAt||b.timestamp||'')-Date.parse(a.receivedAt||a.occurredAt||a.timestamp||''))
    const event=matches[0]
    if(!event)continue
    const eventAt=event.receivedAt||event.occurredAt||event.timestamp
    candidates.push({
      leadRef,
      name:lead.name||leadRef,
      grade:lead.grade||null,
      score:Number(lead.score||0),
      source:lead.source||null,
      campaign:lead.campaign||null,
      lastActivity:new Date(lastTime).toISOString(),
      dormantDays:Math.max(0,Math.floor((now-lastTime)/(24*60*60*1000))),
      renewedEvent:String(event.event||event.eventType||event.name||'high_intent_activity'),
      renewedAt:eventAt,
      renewedSource:event.utm_source||event.source||event.channel||'First-party',
      renewedCampaign:event.utm_campaign||event.campaign||null,
      reason:'Lead reactivation · renewed intent after '+Math.max(0,Math.floor((now-lastTime)/(24*60*60*1000)))+' dormant days'
    })
  }
  return candidates.sort((a,b)=>Date.parse(b.renewedAt)-Date.parse(a.renewedAt))
}

const sha256Normalized=value=>createHash('sha256').update(String(value||'').trim().toLowerCase()).digest('hex')
const sha256Phone=value=>createHash('sha256').update(String(value||'').replace(/\D/g,'')).digest('hex')
const buildSignalReplayPayload=(body,item={})=>{
  const payload={
    deliveryId:item.id||body.deliveryId||null,
    event:String(item.event||body.event||''),
    destination:String(item.destination||body.destination||''),
    idempotencyKey:item.idempotencyKey||body.idempotencyKey||null,
    customerId:item.customerId||body.customerId||null,
    externalEventId:item.externalEventId||body.externalEventId||null,
    occurredAt:body.occurredAt||null,
    value:body.value??null,
    currency:body.currency||null,
    orderId:body.orderId||null,
    gclid:body.gclid||null,
    gbraid:body.gbraid||null,
    wbraid:body.wbraid||null,
    msclkid:body.msclkid||body.data?.msclkid||null,
    epik:body.epik||body.data?.epik||body.data?.click_id||null,
    ttclid:body.ttclid||body.data?.ttclid||null,
    ttp:body.ttp||body.data?.ttp||null,
    twclid:body.twclid||body.data?.twclid||null,
    twpid:body.twpid||body.data?.twpid||null,
    fbc:body.fbc||null,
    fbp:body.fbp||null,
    oppref:body.oppref||body.openaiClickRef||null,
    obref:body.obref||body.openaiBrowserRef||null,
    openaiEventType:body.openaiEventType||null,
    openaiCustomEventName:body.openaiCustomEventName||null,
    openaiAmountMinor:body.openaiAmountMinor??body.data?.openaiAmountMinor??null,
    planId:body.planId||body.data?.planId||null,
    contents:Array.isArray(body.contents)?body.contents:(Array.isArray(body.data?.contents)?body.data.contents:null),
    optOut:body.optOut,
    country:body.country||null,
    city:body.city||null,
    region:body.region||null,
    postalCode:body.postalCode||body.postal_code||null,
    ipAddress:body.ipAddress||body.data?.ipAddress||null,
    userAgent:body.userAgent||body.data?.userAgent||null,
    anonymousId:body.anonymousId||body.visitorId||body.data?.anonymousId||body.data?.visitorId||null,
    externalId:body.externalId||body.data?.externalId||null,
    idfa:body.idfa||body.data?.idfa||null,
    androidAdvertisingId:body.androidAdvertisingId||body.data?.androidAdvertisingId||null,
    linkedinFirstPartyAdsTrackingUuid:body.linkedinFirstPartyAdsTrackingUuid||body.liFatId||body.data?.linkedinFirstPartyAdsTrackingUuid||body.data?.liFatId||null,
    linkedinConversionUrn:body.linkedinConversionUrn||body.data?.linkedinConversionUrn||null,
    microsoftUetTagId:body.microsoftUetTagId||body.data?.microsoftUetTagId||null,
    pinterestAdvertiserId:body.pinterestAdvertiserId||body.data?.pinterestAdvertiserId||null,
    tiktokPixelId:body.tiktokPixelId||body.data?.tiktokPixelId||null,
    tiktokEventSource:body.tiktokEventSource||body.data?.tiktokEventSource||null,
    xPixelId:body.xPixelId||body.data?.xPixelId||null,
    xEventId:body.xEventId||body.data?.xEventId||null,
    xEventName:body.xEventName||body.data?.xEventName||null,
    openaiPixelId:body.openaiPixelId||null,
    validateOnly:body.validateOnly===true,
    emailSha256:body.emailSha256||body.email_sha256||(body.email?sha256Normalized(body.email):null),
    phoneSha256:body.phoneSha256||body.phone_sha256||(body.phone?sha256Phone(body.phone):null),
    actionSource:body.actionSource||body.data?.actionSource||null,
    eventSourceUrl:body.eventSourceUrl||body.pageUrl||body.url||body.data?.eventSourceUrl||body.data?.pageUrl||body.data?.url||null,
    metaDatasetId:body.metaDatasetId||body.data?.metaDatasetId||null,
    googleCustomerId:body.googleCustomerId||null,
    googleConversionAction:body.googleConversionAction||null,
    adUserDataConsent:body.adUserDataConsent!==false,
    webhookUrl:body.webhookUrl||null,
    data:body.data&&typeof body.data==='object'?body.data:{}
  }
  return Object.fromEntries(Object.entries(payload).filter(([,value])=>value!==null&&value!==undefined&&value!==''))
}
const validateSignalDispatch=body=>{
  const destination=String(body.destination||'').toLowerCase()
  if(!body.event||!destination) return 'event and destination required'
  const isX=destination==='x'||destination.includes('x ads')||destination.includes('twitter')
  if(!destination.includes('meta')&&!destination.includes('google')&&!destination.includes('linkedin')&&!destination.includes('microsoft')&&!destination.includes('bing')&&!destination.includes('pinterest')&&!destination.includes('tiktok')&&!isX&&!destination.includes('webhook')&&!destination.includes('chatgpt')&&!destination.includes('openai')) return 'unsupported delivery destination'
  if(destination.includes('google')){
    const hasIdentity=Boolean(body.gclid||body.gbraid||body.wbraid||body.email||body.emailSha256||body.email_sha256||body.phone||body.phoneSha256||body.phone_sha256)
    if(!hasIdentity) return 'Google delivery requires gclid, gbraid, wbraid, or a user identifier'
  }
  if(destination.includes('meta')){
    const hasIdentity=Boolean(body.email||body.emailSha256||body.email_sha256||body.phone||body.phoneSha256||body.phone_sha256||body.externalId||body.customerId||body.fbc||body.fbp)
    if(!hasIdentity) return 'Meta delivery requires a customer identifier, click/browser identifier, email, or phone'
  }
  if(destination.includes('linkedin')){
    const hasIdentity=Boolean(body.email||body.emailSha256||body.email_sha256||body.linkedinFirstPartyAdsTrackingUuid||body.liFatId||body.androidAdvertisingId||body.data?.emailSha256||body.data?.linkedinFirstPartyAdsTrackingUuid||body.data?.liFatId||body.data?.androidAdvertisingId)
    if(!hasIdentity) return 'LinkedIn delivery requires hashed email, LinkedIn first-party tracking UUID, or Google advertising ID'
  }
  if(destination.includes('microsoft')||destination.includes('bing')){
    const hasIdentity=Boolean(body.msclkid||body.email||body.emailSha256||body.email_sha256||body.phone||body.phoneSha256||body.phone_sha256||body.anonymousId||body.visitorId||body.externalId||body.customerId||body.idfa||body.androidAdvertisingId||body.data?.msclkid)
    if(!hasIdentity) return 'Microsoft delivery requires msclkid or a supported first-party/device identifier'
  }
  if(destination.includes('pinterest')){
    const hasEmail=Boolean(body.email||body.emailSha256||body.email_sha256||body.data?.emailSha256)
    const hasMaid=Boolean(body.androidAdvertisingId||body.idfa||body.data?.androidAdvertisingId||body.data?.idfa)
    const hasRequestContext=Boolean((body.ipAddress||body.data?.ipAddress)&&(body.userAgent||body.data?.userAgent))
    if(!hasEmail&&!hasMaid&&!hasRequestContext) return 'Pinterest delivery requires hashed email, mobile advertising ID, or IP plus user agent'
  }
  if(destination.includes('tiktok')){
    const hasIdentity=Boolean(body.ttclid||body.ttp||body.email||body.emailSha256||body.email_sha256||body.phone||body.phoneSha256||body.phone_sha256||body.externalId||body.customerId||body.ipAddress||body.userAgent||body.data?.ttclid||body.data?.ttp)
    if(!hasIdentity) return 'TikTok delivery requires a click/cookie identifier, customer identifier, hashed contact, or request context'
  }
  if(isX){
    const hasIdentity=Boolean(body.twclid||body.twpid||body.email||body.emailSha256||body.email_sha256||body.phone||body.phoneSha256||body.phone_sha256||body.ipAddress||body.userAgent||body.data?.twclid||body.data?.twpid)
    if(!hasIdentity) return 'X delivery requires twclid/twpid, hashed contact, IP, or user agent'
  }
  if(destination.includes('chatgpt')||destination.includes('openai')){
    const actionSource=String(body.actionSource||'web').toLowerCase()
    if(['web','website'].includes(actionSource)&&!body.eventSourceUrl) return 'ChatGPT Ads web events require eventSourceUrl'
    if(body.openaiAmountMinor!==undefined&&body.openaiAmountMinor!==null&&body.openaiAmountMinor!==''){
      const amount=Number(body.openaiAmountMinor)
      if(!Number.isInteger(amount)||amount<0) return 'ChatGPT Ads amount must be a non-negative integer in currency minor units'
      if(!body.currency) return 'ChatGPT Ads currency is required when amount is present'
    }
  }
  if(destination.includes('webhook')&&body.webhookUrl){
    try{
      const target=new URL(String(body.webhookUrl))
      if(target.protocol!=='https:'&&!(!IS_PROD&&target.protocol==='http:')) return 'webhookUrl must use HTTPS'
    }catch{return 'webhookUrl is invalid'}
  }
  return null
}

const activationValue=(body,field)=>{
  if(!field)return null
  if(Object.prototype.hasOwnProperty.call(body,field))return body[field]
  if(body.data&&typeof body.data==='object'&&Object.prototype.hasOwnProperty.call(body.data,field))return body.data[field]
  return null
}
const activationConditionMatches=(condition,body)=>{
  if(!condition||!condition.field)return true
  const actual=activationValue(body,String(condition.field))
  const expected=condition.value
  const op=String(condition.operator||'equals')
  if(op==='exists')return actual!==null&&actual!==undefined&&String(actual)!==''
  if(op==='not_exists')return actual===null||actual===undefined||String(actual)===''
  if(op==='contains')return String(actual||'').toLowerCase().includes(String(expected||'').toLowerCase())
  if(op==='greater_than')return Number(actual)>Number(expected)
  if(op==='less_than')return Number(actual)<Number(expected)
  if(op==='one_of')return String(expected||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean).includes(String(actual||'').toLowerCase())
  return String(actual??'').toLowerCase()===String(expected??'').toLowerCase()
}
const activationRuleMatches=(rule,body)=>{
  if(String(rule.status||'active')!=='active')return false
  const trigger=String(rule.triggerEvent||'*').trim().toLowerCase()
  const eventName=String(body.event||body.eventType||body.name||'').trim().toLowerCase()
  if(trigger!=='*'&&trigger!==eventName)return false
  return (rule.conditions||[]).every(condition=>activationConditionMatches(condition,body))
}

const events = [
  {name:'Qualified Lead',source:'CRM',destinations:['Google Ads','Meta Ads'],latency:'real-time',status:'active'},
  {name:'Consultation Booked',source:'CRM',destinations:['Google Ads'],latency:'real-time',status:'active'},
  {name:'WhatsApp Started',source:'WhatsApp',destinations:['Google Ads','Meta Ads'],latency:'real-time',status:'active'},
  {name:'Call Connected',source:'Calling',destinations:['Meta Ads'],latency:'real-time',status:'active'},
  {name:'Enrolment',source:'CRM / Billing',destinations:['Google Ads','Meta Ads','LinkedIn Ads'],latency:'real-time',status:'active'},
]

const permissionForRequest=(method,path)=>evaluateAccessPermission(method,path)

const readRawBody = req => new Promise((resolve,reject)=>{
  const chunks=[]
  let size=0
  req.on('data',chunk=>{
    size+=chunk.length
    if(size>1_000_000){reject(new Error('payload too large'));req.destroy();return}
    chunks.push(chunk)
  })
  req.on('end',()=>resolve(Buffer.concat(chunks).toString('utf8')))
  req.on('error',reject)
})

const readBody = req => new Promise((resolve,reject)=>{
  let body=''
  req.on('data', chunk => {
    body += chunk
    if (body.length > 1_000_000) { reject(new Error('payload too large')); req.destroy() }
  })
  req.on('end', () => {
    if (!body) return resolve({})
    try { resolve(JSON.parse(body)) } catch { reject(new Error('invalid json')) }
  })
})

const send = (req,res,status,data,extra={}) => {
  const origin=resolveCorsOrigin(req.headers.origin,allowedOrigins)
  const requestId=req.requestId || randomUUID()
  res.writeHead(status, {
    ...securityHeaders,
    'Content-Type':'application/json; charset=utf-8',
    'Access-Control-Allow-Origin':origin,
    'Vary':'Origin',
    'Access-Control-Allow-Headers':'Content-Type, Authorization, X-Request-ID, X-Workspace-ID',
    'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
    'X-Request-ID':requestId,
    ...extra,
  })
  res.end(status===204?'':JSON.stringify(data))
}

const publicPaths=new Set(['/api/health','/api/ready','/api/auth/login','/api/auth/google/start','/api/auth/google/exchange','/api/auth/password/forgot','/api/auth/password/reset','/api/invitations/activate','/api/demo-requests','/api/demo-bookings','/api/track','/api/pricing/recommend','/api/pricing/quote','/api/public/navigation','/api/public/industries','/api/public/agents','/api/public/integrations','/api/public/connector-requests','/api/public/challenges','/api/public/case-studies','/api/public/resources','/api/public/resource-center','/api/webhooks/whatsapp','/api/webhooks/calls'])
const isPublicRequest=(method,path)=>publicPaths.has(path)||(method==='GET'&&path==='/api/integrations/oauth/callback')||(method==='GET'&&path==='/api/auth/google/callback')||(method==='POST'&&path==='/api/billing/webhook')||path==='/api/consent'
const meteredMetricFor=(method,path)=>{
  if(method!=='POST') return null
  if(path==='/api/track') return 'tracked_events'
  if(path==='/api/assisted-events') return 'assisted_events'
  if(path==='/api/signal-deliveries/dispatch') return 'signal_dispatches'
  if(path==='/api/audiences/sync') return 'audience_syncs'
  if(path==='/api/custom-integrations/test') return 'custom_integration_tests'
  if(path==='/api/qualification-calls'||path==='/api/qualification-calls/retry'||path==='/api/meetings/remind'||path==='/api/feedback/request') return 'agent_actions'
  if(path==='/api/whatsapp/messages') return 'agent_actions'
  return null
}
const server = http.createServer(async (req,res)=>{
  const requestContext=createRequestContext({req})
  req.context=requestContext
  req.requestId=requestContext.requestId
  const healthUrl=new URL(req.url, `http://localhost:${PORT}`)
  if(req.method==='GET'&&healthUrl.pathname==='/healthz'){
    return send(req,res,200,{...livenessState(),service:runtimeRole.role==='integration-ingress'?'ace-marketing-integration-ingress':'ace-marketing-api',requestId:req.requestId})
  }
  if(req.method==='GET'&&healthUrl.pathname==='/startupz'){
    const state=startupState()
    return send(req,res,state.ok?200:503,{...state,service:runtimeRole.role==='integration-ingress'?'ace-marketing-integration-ingress':'ace-marketing-api',requestId:req.requestId})
  }
  if(req.method==='GET'&&healthUrl.pathname==='/readyz'){
    const state=await readinessState({storageHealth})
    return send(req,res,state.ok?200:503,{...state,service:runtimeRole.role==='integration-ingress'?'ace-marketing-integration-ingress':'ace-marketing-api',requestId:req.requestId})
  }
  if(!runtimeRoleAllows({role:runtimeRole.role,method:req.method,path:healthUrl.pathname})){
    return send(req,res,404,{error:'not found',code:'runtime_route_not_exposed'})
  }
  const releaseAdmission=globalAdmission.acquire()
  if(!releaseAdmission){
    return send(req,res,503,{error:'server busy',code:'admission_capacity_exhausted',retryable:true},{'Retry-After':'1'})
  }
  let admissionReleased=false
  const releaseAdmissionOnce=()=>{
    if(admissionReleased)return
    admissionReleased=true
    releaseAdmission()
  }
  res.once('finish',releaseAdmissionOnce)
  res.once('close',releaseAdmissionOnce)
  const requestStartedAt=requestContext.startedAt
  const ip=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim()
  const rate=limitRequest(ip)
  if(!rate.allowed) return send(req,res,429,{error:'rate limit exceeded'},{'Retry-After':String(Math.max(1,Math.ceil((rate.resetAt-Date.now())/1000)))})
  const url = new URL(req.url, `http://localhost:${PORT}`)
  if (req.method === 'OPTIONS') return send(req,res,204,{})
  if (req.headers.origin && !resolveCorsOrigin(req.headers.origin,allowedOrigins)) return send(req,res,403,{error:'origin not allowed'})
  let workspaceId
  try{
    workspaceId=requestedWorkspaceId(req,{defaultWorkspaceId:process.env.DEFAULT_WORKSPACE_ID||'ws_default'})
  }catch(error){
    return send(req,res,400,{error:error instanceof Error?error.message:'invalid workspace scope',code:error?.code||'invalid_workspace_scope'})
  }
  if(String(process.env.CELL_ROUTING_REQUIRED||'false').toLowerCase()==='true'){
    try{
      await assertWorkspaceCell({
        workspaceId,
        expectedCell:process.env.ACE_CELL_ID||'',
        expectedRegion:process.env.ACE_CELL_REGION||null,
        routingEpoch:req.headers['x-ace-routing-epoch']||null
      })
    }catch(error){
      return send(req,res,Number(error?.status||503),{error:error instanceof Error?error.message:'workspace placement unavailable',code:error?.code||'cell_placement_unavailable'})
    }
  }
  if(url.pathname==='/api/consent'){
    if(req.method==='GET'){
      const subjectType=url.searchParams.get('subjectType')==='customer'?'customer':'visitor'
      const subjectId=String(url.searchParams.get('subjectId')||'')
      if(!subjectId) return send(req,res,400,{error:'subjectId required'})
      const record=await getConsent(workspaceId,subjectType,subjectId)
      return send(req,res,200,{record:record||null,defaults:{essential:true,analytics:false,marketing:false,personalization:false},policyVersion:process.env.CONSENT_POLICY_VERSION||'v1'})
    }
    if(req.method==='POST'){
      const body=await readBody(req)
      try{
        const forwarded=String(req.headers['x-forwarded-for']||'').split(',')[0].trim()
        const record=await saveConsent(workspaceId,body,{ip:forwarded||req.socket.remoteAddress||'',userAgent:req.headers['user-agent']||''})
        return send(req,res,200,{record})
      }catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'invalid consent request'})}
    }
  }
  if(req.method==='POST'&&url.pathname==='/api/billing/webhook'){
    try{
      const raw=await readRawBody(req)
      const event=verifyStripeWebhook(raw,req.headers['stripe-signature'])
      const result=await handleReconcilePayment({event})
      return send(req,res,200,{received:true,...result})
    }catch(error){
      return send(req,res,400,{error:error instanceof Error?error.message:'invalid billing webhook'})
    }
  }
  if(req.method==='GET'&&url.pathname==='/api/webhooks/whatsapp'){
    const check=verifyWhatsAppWebhookChallenge({
      mode:url.searchParams.get('hub.mode'),
      verifyToken:url.searchParams.get('hub.verify_token'),
      challenge:url.searchParams.get('hub.challenge')
    })
    if(!check.ok) return send(req,res,check.status,{error:check.error})
    res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','X-Request-ID':req.requestId})
    res.end(check.challenge)
    return
  }
  if(req.method==='POST'&&url.pathname==='/api/webhooks/whatsapp'){
    try{
      const raw=await readRawBody(req)
      if(!verifyWhatsAppWebhookSignature(raw,req.headers['x-hub-signature-256'])) return send(req,res,401,{error:'invalid WhatsApp webhook signature'})
      let payload={}
      try{payload=raw?JSON.parse(raw):{}}catch{return send(req,res,400,{error:'invalid WhatsApp webhook json'})}
      const events=parseWhatsAppWebhook(payload)
      const resolvedWorkspace=resolveWhatsAppWorkspace(events,req.headers['x-workspace-id'])
      if(!resolvedWorkspace) return send(req,res,400,{error:'unable to resolve workspace for WhatsApp phone number'})
      workspaceId=resolvedWorkspace
      const payloadHash=createHash('sha256').update(raw).digest('hex')
      const inboxRecords=[]
      for(const event of events){
        if(!event?.id)continue
        const record=await recordInboxEvent({
          source:'whatsapp',
          eventId:String(event.id)+':'+String(event.kind||'event')+':'+String(event.status||''),
          workspaceId,
          payloadHash
        }).catch(error=>{throw error})
        inboxRecords.push({event,record})
      }
      const duplicateCount=inboxRecords.filter(item=>item.record?.processed_at).length
      await withWorkspace(workspaceId,async()=>{
        const now=new Date().toISOString()
        await mutateState(s=>{
          s.whatsappEvents=s.whatsappEvents||[]
          for(const event of events){
            const duplicate=s.whatsappEvents.some(x=>x.id===event.id&&x.kind===event.kind&&x.status===event.status)
            if(!duplicate) s.whatsappEvents.unshift({...event,receivedAt:now})
          }
          s.whatsappEvents=s.whatsappEvents.slice(0,10000)
          s.audit=s.audit||[]
          s.audit.unshift({id:randomUUID(),action:'whatsapp.webhook.received',entityId:events[0]?.id||null,count:events.length,at:now})
          s.audit=s.audit.slice(0,1000)
        })
        for(const event of events){
          if(event.kind!=='message'||!event.from) continue
          await upsertLeadProfile(workspaceId,{
            externalLeadId:'whatsapp:'+event.from,
            name:event.contactName||null,
            phone:event.from,
            source:'WhatsApp',
            whatsappEngaged:true,
            lastActivity:event.timestamp,
            whatsappSummary:event.text||event.messageType,
            attributes:{whatsappMessageId:event.id,messageType:event.messageType,phoneNumberId:event.phoneNumberId,ctwaClid:event.referral?.ctwaClid||null,ctwaSourceId:event.referral?.sourceId||null,ctwaSourceUrl:event.referral?.sourceUrl||null,ctwaHeadline:event.referral?.headline||null}
          }).catch(()=>null)
          await recordAssistedEvent(workspaceId,{
            event:'whatsapp.message_received',
            eventType:'whatsapp.message_received',
            eventId:event.id,
            customerId:'whatsapp:'+event.from,
            phone:event.from,
            source:event.referral?.ctwaClid?'ctwa':'whatsapp',
            occurredAt:event.timestamp,
            data:{messageType:event.messageType,phoneNumberId:event.phoneNumberId,ctwaClid:event.referral?.ctwaClid||null,sourceId:event.referral?.sourceId||null,sourceUrl:event.referral?.sourceUrl||null,headline:event.referral?.headline||null,sourceType:event.referral?.sourceType||null}
          }).catch(()=>null)
        }
      })
      for(const {event,record} of inboxRecords){
        if(record?.processed_at||!event?.id)continue
        await markInboxProcessed({
          source:'whatsapp',
          eventId:String(event.id)+':'+String(event.kind||'event')+':'+String(event.status||''),
          workspaceId,
          result:{received:true}
        }).catch(()=>{})
      }
      return send(req,res,200,{received:true,workspaceId,events:events.length,duplicates:duplicateCount})
    }catch(error){
      return send(req,res,400,{error:error instanceof Error?error.message:'invalid WhatsApp webhook'})
    }
  }
  if(req.method==='POST'&&url.pathname==='/api/webhooks/calls'){
    try{
      const raw=await readRawBody(req)
      const verified=verifyCallWebhook(raw,req.headers)
      if(!verified.ok) return send(req,res,401,{error:verified.error})
      let body={}
      try{body=raw?JSON.parse(raw):{}}catch{return send(req,res,400,{error:'invalid call webhook json'})}
      const resolvedWorkspace=resolveCallWorkspace(body,req.headers['x-workspace-id'])
      if(!resolvedWorkspace) return send(req,res,400,{error:'unable to resolve workspace for call event'})
      workspaceId=resolvedWorkspace
      const event=normalizeCallEvent(body)
      const payloadHash=createHash('sha256').update(raw).digest('hex')
      const inboxRecord=await recordInboxEvent({
        source:'calls:'+String(event.provider||'provider'),
        eventId:String(event.id),
        workspaceId,
        payloadHash
      })
      let duplicate=Boolean(inboxRecord?.processed_at)
      await withWorkspace(workspaceId,async()=>{
        const now=new Date().toISOString()
        await mutateState(s=>{
          s.callEvents=s.callEvents||[]
          duplicate=s.callEvents.some(x=>x.id===event.id)
          if(!duplicate) s.callEvents.unshift({...event,receivedAt:now})
          s.callEvents=s.callEvents.slice(0,10000)
          s.audit=s.audit||[]
          s.audit.unshift({id:randomUUID(),action:'call.webhook.received',entityId:event.id,provider:event.provider,duplicate,at:now})
          s.audit=s.audit.slice(0,1000)
        })
        if(!duplicate){
          await upsertLeadProfile(workspaceId,{
            externalLeadId:event.customerId||('call:'+event.from),
            phone:event.from||null,
            source:event.source||'Telephony',
            campaign:event.campaign||null,
            lastActivity:event.endedAt||event.startedAt,
            callOutcome:event.disposition||event.status,
            callSummary:[event.status,event.durationSeconds?event.durationSeconds+'s':null,event.disposition].filter(Boolean).join(' · '),
            attributes:{callEventId:event.id,provider:event.provider,direction:event.direction,to:event.to,keyword:event.keyword||null,creative:event.creative||null,adGroup:event.adGroup||null}
          }).catch(()=>null)
          await recordAssistedEvent(workspaceId,{
            event:'call.completed',
            eventType:'call.completed',
            eventId:event.id,
            customerId:event.customerId||('call:'+event.from),
            phone:event.from||null,
            source:'call',
            occurredAt:event.endedAt||event.startedAt,
            gclid:event.gclid||null,
            fbclid:event.fbclid||null,
            msclkid:event.msclkid||null,
            data:{provider:event.provider,status:event.status,durationSeconds:event.durationSeconds,campaign:event.campaign,keyword:event.keyword,creative:event.creative,adGroup:event.adGroup}
          }).catch(()=>null)
        }
      })
      if(!inboxRecord?.processed_at){
        await markInboxProcessed({
          source:'calls:'+String(event.provider||'provider'),
          eventId:String(event.id),
          workspaceId,
          result:{received:true}
        }).catch(()=>{})
      }
      return send(req,res,200,{received:true,duplicate,workspaceId,eventId:event.id})
    }catch(error){
      return send(req,res,400,{error:error instanceof Error?error.message:'invalid call webhook'})
    }
  }
  if(req.method==='GET'&&url.pathname==='/api/integrations/oauth/callback'){
    const signed=parseOAuthState(url.searchParams.get('state'))
    if(!signed) return send(req,res,400,{error:'invalid or expired oauth state'})
    workspaceId=signed.workspaceId
  }
  if(!/^[A-Za-z0-9_-]{1,64}$/.test(workspaceId)) return send(req,res,400,{error:'invalid workspace id'})
  let usageReservationId=null
  const meteredMetric=meteredMetricFor(req.method||'GET',url.pathname)
  res.once('finish',()=>{
    const success=res.statusCode<400
    recordApiTelemetry(workspaceId,{
      requestId:req.requestId,
      method:req.method||'GET',
      path:url.pathname,
      statusCode:res.statusCode,
      latencyMs:Date.now()-requestStartedAt,
      usageReservationId:success?usageReservationId:null
    }).catch(()=>{}).finally(()=>{
      if(usageReservationId)finalizeReservation(workspaceId,usageReservationId,success).catch(()=>{})
    })
  })
  if(meteredMetric){
    let capacity
    try{
      capacity=await handleReserveQuota({workspaceId,metric:meteredMetric,quantity:1,requestId:req.requestId})
    }catch(error){
      return send(req,res,503,{
        error:'usage quota check unavailable',
        code:'quota_check_unavailable',
        retryable:true
      },{'Retry-After':'1'})
    }
    if(!capacity.allowed) return send(req,res,429,{error:'usage quota exceeded',metric:meteredMetric,usage:capacity})
    usageReservationId=capacity.reservationId||null
  }
  let authenticatedUser=null
  const protectedRequest=url.pathname.startsWith('/api/')&&!isPublicRequest(req.method||'GET',url.pathname)
  if(protectedRequest){
    const token=String(req.headers.authorization||'').replace(/^Bearer\s+/i,'')
    if(token){
      authenticatedUser=verifyToken(token,JWT_SECRET)
      if(!authenticatedUser) return send(req,res,401,{error:'unauthorized'})
      try{assertActorWorkspace(authenticatedUser,workspaceId)}catch(error){
        return send(req,res,403,{error:'token workspace mismatch',code:error?.code||'workspace_scope_mismatch'})
      }
    }else if(AUTH_REQUIRED||url.pathname==='/api/auth/me'){
      return send(req,res,401,{error:'unauthorized'})
    }
  }
  return withWorkspace(workspaceId,async()=>{
  let trackedEvents=trackedEventsByWorkspace.get(workspaceId)
  if(!trackedEvents){
    trackedEvents=await listTrackedEvents(workspaceId,{limit:5000}).catch(()=>[])
    trackedEventsByWorkspace.set(workspaceId,trackedEvents)
  }
  try {
    if(authenticatedUser){
      const authState=await getState()
      const session=(authState.sessions||[]).find(x=>x.jti===authenticatedUser.jti&&x.status==='active')
      const member=(authState.members||[]).find(x=>x.id===authenticatedUser.userId&&x.status==='active')
      if(!session||!member) return send(req,res,401,{error:'session revoked or member inactive'})
      if(session.expiresAt&&Date.parse(session.expiresAt)<=Date.now()) return send(req,res,401,{error:'session expired'})
      authenticatedUser={...authenticatedUser,role:member.role,email:member.email,userId:member.id}
      req.user=authenticatedUser
      req.tenantScope=tenantExecutionScope({actor:authenticatedUser,workspaceId})
      req.context=bindActorToRequestContext(req.context,{actor:authenticatedUser,workspaceId,tenantId:req.tenantScope.tenantId})
      const permission=permissionForRequest(req.method||'GET',url.pathname)
      if(!hasPermission(member.role,permission)) return send(req,res,403,{error:'forbidden',permission,role:member.role})
    }
    if(protectedRequest){
      const runtimeDecision=await runtimeGuardForRequest({
        method:req.method||'GET',
        path:url.pathname,
        workspaceId
      }).catch(error=>({
        allowed:false,
        state:'degraded',
        code:'runtime_config_unavailable',
        reason:error instanceof Error?error.message:'runtime configuration could not be evaluated',
        configurationVersion:null
      }))
      if(!runtimeDecision.allowed){
        return send(req,res,503,{
          error:runtimeDecision.reason||'operation unavailable under current runtime policy',
          code:runtimeDecision.code||'runtime_policy_blocked',
          state:runtimeDecision.state,
          configurationVersion:runtimeDecision.configurationVersion,
          retryable:['runtime_config_invalid','runtime_config_unavailable'].includes(runtimeDecision.code)
        })
      }
      req.runtimeConfigurationVersion=runtimeDecision.configurationVersion||null
    }
    if (req.method === 'GET' && url.pathname === '/api/health') return send(req,res,200,{ok:true,service:runtimeRole.role==='integration-ingress'?'ace-marketing-integration-ingress':'ace-marketing-api',time:new Date().toISOString(),requestId:req.requestId})
    if (req.method === 'GET' && url.pathname === '/api/dashboard-summary') {
      const state=await getState()
      const safe=async(fn,fallback)=>{try{return await fn()}catch{return fallback}}
      const [leadStats,attr,audienceStats,queue,monitoring,eventRules,agentRuns,meetings,followUps,feedbackResult,consentSummary,reportSchedules]=await Promise.all([
        safe(()=>leadOpsStats(workspaceId),{available:false,total:0,aGrade:0,abQuality:0}),
        safe(()=>attributionStats(workspaceId),{available:false,matchedEvents:0,unmatchedEvents:0,assistedEvents:0,activeClickSessions:0}),
        safe(()=>audienceOpsStats(workspaceId),{available:false,audiences:{total:0,active:0,activatedIdentities:0,suppressedIdentities:0,errors:0},profiles:{total:0}}),
        safe(()=>queueStats(workspaceId),{backend:'disabled',pending:0,leased:0,retry:0,succeeded:0,deadLetter:0}),
        safe(()=>monitoringSnapshot(workspaceId),{}),
        safe(()=>listEventRules(workspaceId),[]),
        safe(()=>listAgentRuns(workspaceId),[]),
        safe(()=>listPersistedMeetings(workspaceId),[]),
        safe(()=>listPersistedFollowUps(workspaceId),[]),
        safe(()=>listPersistedFeedback(workspaceId),{items:[]}),
        safe(()=>consentStats(workspaceId),{total:0,analytics:0,marketing:0,personalization:0,revoked:0}),
        safe(()=>listReportSchedules(workspaceId),[])
      ])
      const connectors=state.connectorConnections||[]
      const connectedConnectors=connectors.filter(x=>['connected','healthy','active'].includes(String(x.status||'').toLowerCase()))
      const deliveries=state.signalDeliveries||[]
      const integrationFlows=state.integrationFlows||[]
      const activeIntegrationFlows=integrationFlows.filter(x=>x.status==='active').length
      const activationRules=state.activationRules||[]
      const activeActivationRules=activationRules.filter(x=>x.status==='active').length
      const activationRuleRuns=state.activationRuleRuns||[]
      const failedDeliveries=deliveries.filter(x=>['failed','dead_letter'].includes(String(x.status||'').toLowerCase())).length
      const delivered=deliveries.filter(x=>['delivered','succeeded'].includes(String(x.status||'').toLowerCase())).length
      const terminal=deliveries.filter(x=>['delivered','succeeded','failed','dead_letter'].includes(String(x.status||'').toLowerCase())).length
      const deliveryRate=terminal?Number((delivered/terminal*100).toFixed(1)):null
      const trackedCount=trackedEvents.length
      const profiles=Number(leadStats?.total||audienceStats?.profiles?.total||0)
      const areas=[
        {key:'data',title:'Data foundation',tab:'Data Hub',ready:trackedCount>0||profiles>0,primary:trackedCount+profiles,detail:trackedCount+' tracked events · '+profiles+' profiles'},
        {key:'tracking',title:'Tracking & quality',tab:'Diagnostics',ready:eventRules.length>0||trackedCount>0,primary:eventRules.length,detail:eventRules.length+' event rules · '+Number((state.quarantinedEvents||[]).length)+' quarantined'},
        {key:'measurement',title:'Measurement',tab:'Attribution',ready:Boolean(attr?.available&&Number(attr?.matchedEvents||0)>0),primary:Number(attr?.matchedEvents||0),detail:Number(attr?.matchedEvents||0)+' matched · '+Number(attr?.unmatchedEvents||0)+' unmatched'},
        {key:'conversion',title:'Lead & conversion',tab:'Lead Grading',ready:profiles>0,primary:Number(leadStats?.abQuality||0),detail:Number(leadStats?.abQuality||0)+' A/B leads · '+meetings.length+' meetings'},
        {key:'activation',title:'Activation',tab:'Audiences',ready:Number(audienceStats?.audiences?.total||0)>0||deliveries.length>0||activeIntegrationFlows>0||activeActivationRules>0,primary:Number(audienceStats?.audiences?.total||0)+activeIntegrationFlows+activeActivationRules,detail:Number(audienceStats?.audiences?.total||0)+' audiences · '+activeIntegrationFlows+' active flows · '+activeActivationRules+' activation rules · '+deliveries.length+' deliveries'},
        {key:'operations',title:'Operations',tab:'Monitoring',ready:connectedConnectors.length>0,primary:connectedConnectors.length,detail:connectedConnectors.length+' connected · '+failedDeliveries+' failed deliveries'}
      ]
      const readiness=Math.round(areas.filter(x=>x.ready).length/areas.length*100)
      const feedbackItems=feedbackResult?.items||[]
      const voiceRuns=agentRuns.filter(x=>String(x.agent_type||x.agentType||'').toLowerCase()==='voice_qualification')
      const section=(state,count,detail)=>({state,count:Number(count||0),detail})
      const sections={
        Launchpad:section(readiness>=80?'live':readiness>0?'attention':'setup',readiness,readiness+'% workspace readiness'),
        Overview:section('live',trackedCount+profiles,'Live workspace summary'),
        AdSync:section(deliveries.length?'live':connectedConnectors.length?'attention':'setup',deliveries.length,deliveries.length+' signal deliveries'),
        'ChatGPT Ads':section(deliveries.some(x=>/chatgpt|openai/i.test(String(x.destination||'')))?'live':(process.env.OPENAI_CONVERSIONS_API_KEY&&process.env.OPENAI_ADS_PIXEL_ID)?'attention':'setup',deliveries.filter(x=>/chatgpt|openai/i.test(String(x.destination||''))).length,deliveries.filter(x=>/chatgpt|openai/i.test(String(x.destination||''))).length+' ChatGPT Ads deliveries'),
        Funnel:section(profiles?'live':trackedCount?'attention':'setup',profiles,profiles+' known lead profiles'),
        'Leak Monitor':section(profiles?'live':'setup',Number((state.leakRecoveries||[]).length),(state.leakRecoveries||[]).length+' recovery actions'),
        Events:section(eventRules.length?'live':'setup',eventRules.length,eventRules.length+' conversion rules'),
        Diagnostics:section(trackedCount||eventRules.length?'live':'setup',Number((state.quarantinedEvents||[]).length),(state.quarantinedEvents||[]).length+' quarantined events'),
        Adjustments:section(Number((state.performanceAdjustments||[]).length)>0?'live':Number(attr?.matchedEvents||0)>0?'attention':'setup',Number((state.performanceAdjustments||[]).length),(state.performanceAdjustments||[]).length+' governed adjustments'),
        'Match Quality':section((state.recentEvents||[]).length?'live':'setup',(state.recentEvents||[]).length,(state.recentEvents||[]).length+' events scored for identity coverage'),
        Reconciliation:section(trackedCount||deliveries.length||Number(attr?.assistedEvents||0)>0?'live':'setup',failedDeliveries+Number(attr?.unmatchedEvents||0),failedDeliveries+' failed · '+Number(attr?.unmatchedEvents||0)+' unmatched'),
        Fraud:section(Number((state.fraudSignals||[]).length)>0?'attention':trackedCount?'live':'setup',Number((state.fraudSignals||[]).length),(state.fraudSignals||[]).length+' suspicious signals'),
        'Deep Links':section(Number((state.deepLinks||[]).length)>0?'live':'setup',Number((state.deepLinks||[]).length),(state.deepLinks||[]).length+' measurable routes'),
        Sites:section(Number((state.sites||state.trackedSites||[]).length)>0?'live':trackedCount?'attention':'setup',Number((state.sites||state.trackedSites||[]).length),(state.sites||state.trackedSites||[]).length+' tracked sites'),
        Fingerprinting:section(trackedCount?'live':'setup',trackedCount,trackedCount+' events available for privacy-aware matching'),
        'Live Sync':section(trackedCount?'live':'setup',trackedCount,trackedCount+' tracked events'),
        'Data Hub':section(profiles||trackedCount?'live':'setup',profiles,profiles+' unified profiles'),
        'Customer 360':section(profiles?'live':'setup',profiles,profiles+' stitched customer profiles'),
        'Offline Attribution':section(Number(attr?.assistedEvents||0)>0?'live':connectedConnectors.length?'attention':'setup',Number(attr?.assistedEvents||0),Number(attr?.assistedEvents||0)+' assisted/offline events'),
        Matchback:section(Number(attr?.unmatchedEvents||0)>0?'attention':Number(attr?.matchedEvents||0)>0?'live':'setup',Number(attr?.unmatchedEvents||0),Number(attr?.unmatchedEvents||0)+' unmatched conversions'),
        'POS & Stores':section(Number((state.posTransactions||state.storeTransactions||[]).length)>0?'live':connectedConnectors.some(x=>/pos|shopify|woocommerce|magento|store/i.test(String(x.connector||x.name||'')))?'attention':'setup',Number((state.posTransactions||state.storeTransactions||[]).length),(state.posTransactions||state.storeTransactions||[]).length+' store transactions'),
        Journeys:section(profiles?'live':'setup',profiles,profiles+' stitched profiles'),
        Identity:section(profiles?'live':trackedCount?'attention':'setup',profiles,profiles+' resolved profiles'),
        Models:section(Number(attr?.matchedEvents||0)>0?'live':attr?.available?'attention':'setup',Number(attr?.matchedEvents||0),Number(attr?.matchedEvents||0)+' events available for model comparison'),
        Attribution:section(Number(attr?.matchedEvents||0)>0?'live':attr?.available?'attention':'setup',Number(attr?.matchedEvents||0),Number(attr?.matchedEvents||0)+' matched conversions'),
        Planner:section(Number(attr?.matchedEvents||0)>0?'live':attr?.available?'attention':'setup',Number(attr?.matchedEvents||0),Number(attr?.matchedEvents||0)+' matched events for planning'),
        Reports:section(reportSchedules.length?'live':Number(attr?.matchedEvents||0)>0?'attention':'setup',reportSchedules.length,reportSchedules.length+' scheduled reports'),
        'Grouped Performance':section((state.recentEvents||[]).length?'live':'setup',(state.recentEvents||[]).length,(state.recentEvents||[]).length+' persisted events available for grouping'),
        'Executive Briefs':section(reportSchedules.some(x=>x.report_type==='executive_brief')?'live':reportMailConfigured()?'attention':'setup',reportSchedules.filter(x=>x.report_type==='executive_brief').length,reportSchedules.filter(x=>x.report_type==='executive_brief').length+' executive briefs'),
        Enrich:section(profiles?'live':'setup',profiles,profiles+' enriched profiles'),
        'Lead Grading':section(profiles?'live':'setup',Number(leadStats?.abQuality||0),Number(leadStats?.abQuality||0)+' A/B leads'),
        Behavior:section(trackedCount||profiles?'live':'setup',trackedCount,trackedCount+' behavioral events'),
        Feed:section(deliveries.length?'live':connectedConnectors.length?'attention':'setup',deliveries.length,deliveries.length+' outbound feed deliveries'),
        Agents:section(agentRuns.length?'live':'attention',agentRuns.length,agentRuns.length+' persisted runs'),
        Routing:section(Number((state.routingDecisions||[]).length)>0?'live':profiles?'attention':'setup',Number((state.routingDecisions||[]).length),(state.routingDecisions||[]).length+' routing decisions'),
        'Follow-ups':section(followUps.length?'live':profiles?'attention':'setup',followUps.length,followUps.length+' follow-up tasks'),
        Calls:section(voiceRuns.length?'live':connectedConnectors.some(x=>/exotel|knowlarity|twilio|myoperator|tata/i.test(String(x.connector||x.name||'')))?'attention':'setup',voiceRuns.length,voiceRuns.length+' qualification runs'),
        Meetings:section(meetings.length?'live':connectedConnectors.some(x=>/calendar/i.test(String(x.connector||x.name||'')))?'attention':'setup',meetings.length,meetings.length+' scheduled meetings'),
        Feedback:section(feedbackItems.length?'live':agentRuns.some(x=>String(x.agent_type||'').toLowerCase()==='feedback')?'attention':'setup',feedbackItems.length,feedbackItems.length+' feedback responses'),
        Approvals:section(Number((state.approvals||state.approvalQueue||[]).length)>0?'attention':agentRuns.length?'live':'setup',Number((state.approvals||state.approvalQueue||[]).length),(state.approvals||state.approvalQueue||[]).length+' pending/recent approvals'),
        'Ask Ace':section(profiles||Number(attr?.matchedEvents||0)>0?'live':'attention',profiles+Number(attr?.matchedEvents||0),profiles||Number(attr?.matchedEvents||0)>0?'Grounded data available':'Connect data for grounded answers'),
        Integrations:section(connectedConnectors.length?'live':'setup',connectedConnectors.length,connectedConnectors.length+' connected systems'),
        'Data Flows':section(activeIntegrationFlows?'live':integrationFlows.length?'attention':'setup',activeIntegrationFlows,activeIntegrationFlows+' active flows'),
        'Real-Time Activation':section(activeActivationRules?'live':activationRules.length?'attention':'setup',activeActivationRules,activeActivationRules+' active rules · '+activationRuleRuns.length+' runs'),
        Personalization:section(Number((state.personalizationRules||[]).filter(x=>x.status==='active').length)?'live':(state.personalizationRules||[]).length?'attention':'setup',Number((state.personalizationRules||[]).filter(x=>x.status==='active').length),(state.personalizationRules||[]).length+' rules · '+(state.personalizationDecisions||[]).length+' decisions'),
        Exclusions:section(Number(audienceStats?.audiences?.suppressedIdentities||0)>0?'live':Number(audienceStats?.exclusions?.deviceIds||0)>0||Number(audienceStats?.exclusions?.converted||0)>0?'attention':'setup',Number(audienceStats?.audiences?.suppressedIdentities||0),Number(audienceStats?.audiences?.suppressedIdentities||0)+' suppressed identities'),
        Audiences:section(Number(audienceStats?.audiences?.total||0)>0?'live':'setup',Number(audienceStats?.audiences?.total||0),Number(audienceStats?.audiences?.total||0)+' audiences'),
        Delivery:section(deliveries.length?'live':'setup',deliveries.length,deliveries.length+' delivery records'),
        Monitoring:section('live',Number(monitoring?.openAlerts||monitoring?.alerts?.open||0),Number(monitoring?.openAlerts||monitoring?.alerts?.open||0)+' open alerts'),
        Alerts:section(Number(monitoring?.openAlerts||monitoring?.alerts?.open||0)>0?'attention':'live',Number(monitoring?.openAlerts||monitoring?.alerts?.open||0),Number(monitoring?.openAlerts||monitoring?.alerts?.open||0)+' open alerts'),
        Compliance:section(Number(consentSummary?.total||0)>0?'live':'attention',Number(consentSummary?.total||0),Number(consentSummary?.total||0)+' consent subjects'),
        Developers:section(Number((state.apiKeys||[]).filter(x=>x.status!=='revoked').length)>0||Number((state.webhooks||[]).length)>0?'live':'setup',Number((state.apiKeys||[]).filter(x=>x.status!=='revoked').length)+Number((state.webhooks||[]).length),(state.apiKeys||[]).filter(x=>x.status!=='revoked').length+' active API keys · '+(state.webhooks||[]).length+' webhooks'),
        Settings:section('live',connectedConnectors.length,'Workspace configuration')
      }
      const recent=[
        ...trackedEvents.slice(-8).map(x=>({id:x.id||randomUUID(),kind:'event',title:x.event||x.eventType||x.name||'Tracked event',meta:x.source||x.channel||'First-party',time:x.receivedAt||x.occurredAt||x.timestamp||null,tab:'Live Sync'})),
        ...deliveries.slice(0,8).map(x=>({id:'delivery:'+x.id,kind:'delivery',title:(x.event||'Signal')+' → '+(x.destination||'destination'),meta:x.status||'queued',time:x.updatedAt||x.createdAt||null,tab:'Delivery'})),
        ...agentRuns.slice(0,5).map(x=>({id:'agent:'+x.id,kind:'agent',title:x.agent_type||x.agentType||x.action_type||'Agent run',meta:x.status||'queued',time:x.created_at||x.createdAt||null,tab:'Agents'}))
      ].filter(x=>x.time).sort((a,b)=>Date.parse(b.time)-Date.parse(a.time)).slice(0,12)
      return send(req,res,200,{
        generatedAt:new Date().toISOString(),
        readiness,
        areas,
        sections,
        totals:{
          trackedEvents:trackedCount,
          profiles,
          connectedConnectors:connectedConnectors.length,
          totalConnectors:connectors.length,
          eventRules:eventRules.length,
          audiences:Number(audienceStats?.audiences?.total||0),
          activeAudiences:Number(audienceStats?.audiences?.active||0),
          matchedEvents:Number(attr?.matchedEvents||0),
          meetings:meetings.length,
          followUps:followUps.length,
          agentRuns:agentRuns.length,
          deliveries:deliveries.length,
          integrationFlows:integrationFlows.length,
          activeIntegrationFlows,
          activationRules:activationRules.length,
          activeActivationRules,
          activationRuleRuns:activationRuleRuns.length,
          failedDeliveries,
          deliveryRate,
          queueDeadLetter:Number(queue?.deadLetter||queue?.dead_letter||0),
          openAlerts:Number(monitoring?.openAlerts||monitoring?.alerts?.open||0)
        },
        recent
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/ready') {
      const persistence=await storageHealth()
      if(!persistence.ok) return send(req,res,503,{ok:false,persistence,time:new Date().toISOString()})
      const state=await getState()
      return send(req,res,200,{ok:true,persistence,records:{audiences:state.audiences.length,customIntegrations:state.customIntegrations.length},time:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/public/navigation') return send(req,res,200,publicNavigation)
    if (req.method === 'GET' && url.pathname === '/api/public/industries') return send(req,res,200,{items:publicIndustries})
    if (req.method === 'GET' && url.pathname === '/api/public/agents') return send(req,res,200,{items:publicAgents})
    if (req.method === 'GET' && url.pathname === '/api/public/integrations') return send(req,res,200,{groups:publicIntegrations})
    if (req.method === 'POST' && url.pathname === '/api/public/connector-requests') {
      const body=await readBody(req)
      const connector=String(body.connector||'').trim()
      const email=String(body.email||'').trim().toLowerCase()
      const company=String(body.company||'').trim()
      const businessNeed=String(body.businessNeed||body.message||'').trim()
      if(connector.length<2||connector.length>120) return send(req,res,400,{error:'connector must be 2-120 characters'})
      if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)||email.length>254) return send(req,res,400,{error:'valid business email required'})
      if(company.length>160) return send(req,res,400,{error:'company must be 160 characters or fewer'})
      if(businessNeed.length>1200) return send(req,res,400,{error:'businessNeed must be 1200 characters or fewer'})
      const item={
        id:'pub_ireq_'+randomUUID(),connector,email,company:company||null,businessNeed:businessNeed||null,
        status:'captured',source:'public_integrations',createdAt:new Date().toISOString()
      }
      await mutateState(s=>{
        s.publicConnectorRequests=s.publicConnectorRequests||[]
        s.publicConnectorRequests.unshift(item)
        s.publicConnectorRequests=s.publicConnectorRequests.slice(0,5000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'public.integration_requested',entityId:item.id,connector:item.connector,at:item.createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{id:item.id,status:item.status,connector:item.connector})
    }
    if (req.method === 'GET' && url.pathname === '/api/public/challenges') return send(req,res,200,{items:publicChallenges})
    if (req.method === 'GET' && url.pathname === '/api/public/case-studies') return send(req,res,200,{items:publicCaseStudies})
    if (req.method === 'GET' && url.pathname === '/api/public/resources') return send(req,res,200,{items:publicResources})
    if (req.method === 'GET' && url.pathname === '/api/public/resource-center') return send(req,res,200,publicResourceCenter)
    if (req.method === 'GET' && url.pathname === '/api/ctwa-attribution') {
      const state=await getState()
      const whatsapp=(state.whatsappEvents||[]).filter(x=>x.kind==='message'&&x.referral?.ctwaClid)
      const tracked=(state.recentEvents||[]).filter(x=>x?.data?.ctwaClid||x?.ctwaClid)
      const combined=[...whatsapp.map(x=>({
        id:x.id,phone:x.from||'',at:x.timestamp||x.receivedAt||null,ctwaClid:x.referral?.ctwaClid||'',
        sourceId:x.referral?.sourceId||'',sourceUrl:x.referral?.sourceUrl||'',headline:x.referral?.headline||'',
        event:'whatsapp.message_received',value:0,currency:null
      })),...tracked.map(x=>({
        id:x.id||x.eventId||randomUUID(),phone:x.phone||'',at:x.occurredAt||x.receivedAt||x.timestamp||null,
        ctwaClid:x.data?.ctwaClid||x.ctwaClid||'',sourceId:x.data?.sourceId||'',sourceUrl:x.data?.sourceUrl||'',
        headline:x.data?.headline||'',event:x.event||x.eventType||x.name||'event',value:Number(x.value||x.data?.value||0),currency:x.currency||x.data?.currency||null
      }))].filter(x=>x.ctwaClid)
      const byClick=new Map()
      for(const item of combined){
        const row=byClick.get(item.ctwaClid)||{ctwaClid:item.ctwaClid,sourceId:item.sourceId||'',sourceUrl:item.sourceUrl||'',headline:item.headline||'',messages:0,events:0,conversionValue:0,contacts:new Set(),lastActivity:null}
        if(item.event==='whatsapp.message_received')row.messages+=1
        else row.events+=1
        if(item.phone)row.contacts.add(String(item.phone))
        if(Number.isFinite(item.value)&&item.value>0)row.conversionValue+=Number(item.value)
        if(!row.sourceId&&item.sourceId)row.sourceId=item.sourceId
        if(!row.sourceUrl&&item.sourceUrl)row.sourceUrl=item.sourceUrl
        if(!row.headline&&item.headline)row.headline=item.headline
        if(item.at&&(!row.lastActivity||Date.parse(item.at)>Date.parse(row.lastActivity)))row.lastActivity=item.at
        byClick.set(item.ctwaClid,row)
      }
      const items=[...byClick.values()].map(x=>({...x,contacts:x.contacts.size})).sort((a,b)=>Date.parse(b.lastActivity||0)-Date.parse(a.lastActivity||0))
      return send(req,res,200,{
        available:true,
        stats:{
          referredMessages:whatsapp.length,
          attributedClicks:items.length,
          uniqueContacts:new Set(whatsapp.map(x=>x.from).filter(Boolean)).size,
          conversionValue:items.reduce((sum,x)=>sum+Number(x.conversionValue||0),0)
        },
        items:items.slice(0,200)
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/call-events') {
      const state=await getState()
      return send(req,res,200,{items:(state.callEvents||[]).slice(0,200)})
    }
    if (req.method === 'GET' && url.pathname === '/api/whatsapp/messages') {
      const state=await getState()
      return send(req,res,200,{items:(state.whatsappEvents||[]).slice(0,200)})
    }
    if (req.method === 'POST' && url.pathname === '/api/whatsapp/messages') {
      const body=await readBody(req)
      const to=String(body.to||'').replace(/\D/g,'')
      if(!to) return send(req,res,400,{error:'recipient phone is required'})
      const purpose=String(body.purpose||'transactional').toLowerCase()
      if(purpose==='marketing'){
        const subjectId=String(body.customerId||to)
        const consent=await consentAllows(workspaceId,{subjectType:body.customerId?'customer':'visitor',subjectId,category:'marketing'})
        if(!consent.allowed) return send(req,res,403,{error:'marketing consent required',reason:consent.reason})
      }
      try{
        const result=await sendWhatsAppMessage(workspaceId,body)
        const now=new Date().toISOString()
        await mutateState(s=>{
          s.whatsappEvents=s.whatsappEvents||[]
          s.whatsappEvents.unshift({
            kind:'outbound',
            id:result.externalId||('wa_out_'+randomUUID()),
            phoneNumberId:String(body.phoneNumberId||process.env.WHATSAPP_PHONE_NUMBER_ID||''),
            recipientId:to,
            messageType:body.templateName?'template':'text',
            text:body.text?String(body.text).slice(0,4000):'',
            templateName:body.templateName||null,
            status:'accepted',
            timestamp:now,
            provider:'whatsapp_cloud',
            latencyMs:result.latencyMs,
            receivedAt:now
          })
          s.whatsappEvents=s.whatsappEvents.slice(0,10000)
          s.audit=s.audit||[]
          s.audit.unshift({id:randomUUID(),action:'whatsapp.message.sent',entityId:result.externalId||null,recipient:to,at:now})
          s.audit=s.audit.slice(0,1000)
        })
        return send(req,res,202,{accepted:true,provider:result.provider,externalId:result.externalId,latencyMs:result.latencyMs})
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'WhatsApp message failed'})
      }
    }
    if (req.method === 'POST' && url.pathname === '/api/pricing/recommend') {
      const body=await readBody(req)
      const challenges=Array.isArray(body.challenges)?body.challenges:[]
      const names=[]
      if(challenges.includes('Lead quality')) names.push('Meta Advanced CAPI','Google ECL / OCI','Call Tracking Events','Custom Integration')
      if(challenges.includes('Conversion leakage')) names.push('Lead Grading','CRM Enrichment','Voice Lead Qualification','Voice Scheduler','Meeting Reminder','Feedback Agent','Lead Reactivation')
      if(challenges.includes('Attribution')) names.push('Ask Ace')
      return send(req,res,200,{recommended:[...new Set(names)],generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/pricing/quote') {
      const body=await readBody(req)
      const leads=Number(body.leads||0)
      const channels=Array.isArray(body.channels)?body.channels:[]
      const agents=Array.isArray(body.agents)?body.agents:[]
      if(!Number.isFinite(leads)||leads<1) return send(req,res,400,{error:'valid lead volume required'})
      if(channels.length===0) return send(req,res,400,{error:'at least one channel required'})
      if(agents.length===0) return send(req,res,400,{error:'at least one agent required'})
      const item={id:'quote_'+randomUUID(),status:'captured',leads,channels,agents,dataHomes:Array.isArray(body.dataHomes)?body.dataHomes:[],challenges:Array.isArray(body.challenges)?body.challenges:[],createdAt:new Date().toISOString()}
      await mutateState(s=>{s.quoteRequests.unshift(item);s.quoteRequests=s.quoteRequests.slice(0,5000);s.audit.unshift({id:randomUUID(),action:'pricing.quote_requested',entityId:item.id,at:item.createdAt})})
      return send(req,res,201,item)
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/login') {
      const body=await readBody(req)
      try{
        const result=await handleStartLogin({
          workspaceId,
          email:body.email,
          password:body.password,
          jwtSecret:JWT_SECRET,
          adminEmail:ADMIN_EMAIL,
          adminPasswordHash:ADMIN_PASSWORD_HASH,
          isProd:IS_PROD,
          ttlSeconds:Number(process.env.TOKEN_TTL_SECONDS||3600)
        })
        return send(req,res,200,result)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'login failed',code:error?.code||'login_failed'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/auth/google/start') {
      if(!process.env.GOOGLE_OAUTH_CLIENT_ID||!process.env.GOOGLE_OAUTH_CLIENT_SECRET||!AUTH_GOOGLE_REDIRECT_URI) return send(req,res,503,{error:'Google login is not configured'})
      const stateToken=createOAuthState(workspaceId)
      const pkce=createPkce()
      const now=new Date().toISOString()
      const expiresAt=new Date(Date.now()+10*60*1000).toISOString()
      await mutateState(s=>{
        s.googleLoginStates=s.googleLoginStates||[]
        s.googleLoginStates=s.googleLoginStates.filter(x=>Date.parse(x.expiresAt)>Date.now())
        s.googleLoginStates.unshift({stateHash:hashOAuthState(stateToken),workspaceId,verifier:pkce.verifier,createdAt:now,expiresAt})
      })
      const auth=new URL('https://accounts.google.com/o/oauth2/v2/auth')
      auth.searchParams.set('client_id',process.env.GOOGLE_OAUTH_CLIENT_ID)
      auth.searchParams.set('redirect_uri',AUTH_GOOGLE_REDIRECT_URI)
      auth.searchParams.set('response_type','code')
      auth.searchParams.set('state',stateToken)
      auth.searchParams.set('scope','openid email profile')
      auth.searchParams.set('code_challenge',pkce.challenge)
      auth.searchParams.set('code_challenge_method','S256')
      auth.searchParams.set('prompt','select_account')
      return send(req,res,200,{authorizationUrl:auth.toString(),expiresAt})
    }
    if (req.method === 'GET' && url.pathname === '/api/auth/google/callback') {
      const stateToken=String(url.searchParams.get('state')||'')
      const code=String(url.searchParams.get('code')||'')
      const providerError=String(url.searchParams.get('error')||'')
      if(providerError) return send(req,res,400,{error:'Google authorization failed',providerError})
      const parsed=parseOAuthState(stateToken)
      if(!parsed||!code) return send(req,res,400,{error:'invalid Google login callback'})
      workspaceId=parsed.workspaceId
      return withWorkspace(workspaceId,async()=>{
        const state=await getState()
        const pending=(state.googleLoginStates||[]).find(x=>x.stateHash===hashOAuthState(stateToken)&&Date.parse(x.expiresAt)>Date.now())
        if(!pending) return send(req,res,400,{error:'expired Google login state'})
        const body=new URLSearchParams({
          grant_type:'authorization_code',
          code,
          client_id:process.env.GOOGLE_OAUTH_CLIENT_ID||'',
          client_secret:process.env.GOOGLE_OAUTH_CLIENT_SECRET||'',
          redirect_uri:AUTH_GOOGLE_REDIRECT_URI,
          code_verifier:pending.verifier
        })
        const tokenResponse=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body})
        const tokenRaw=await tokenResponse.text()
        let tokenBody={}
        try{tokenBody=tokenRaw?JSON.parse(tokenRaw):{}}catch{}
        if(!tokenResponse.ok||!tokenBody.access_token) return send(req,res,400,{error:'Google token exchange failed'})
        const userResponse=await fetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:'Bearer '+tokenBody.access_token}})
        const user=await userResponse.json()
        const email=String(user.email||'').trim().toLowerCase()
        if(!email||user.email_verified===false) return send(req,res,403,{error:'verified Google email required'})
        const member=(state.members||[]).find(x=>String(x.email).toLowerCase()===email&&x.status==='active')
        if(!member){
          if(AUTH_GOOGLE_SUCCESS_URL){
            const target=new URL(AUTH_GOOGLE_SUCCESS_URL)
            target.searchParams.set('auth_error','not_member')
            target.hash='/login'
            res.writeHead(302,{Location:target.toString()});res.end();return
          }
          return send(req,res,403,{error:'Google account is not an active workspace member'})
        }
        const rawCode=randomBytes(32).toString('base64url')
        const codeHash=createHash('sha256').update(rawCode).digest('hex')
        const expiresAt=new Date(Date.now()+2*60*1000).toISOString()
        await mutateState(s=>{
          s.googleLoginStates=(s.googleLoginStates||[]).filter(x=>x.stateHash!==pending.stateHash)
          s.googleLoginExchanges=s.googleLoginExchanges||[]
          s.googleLoginExchanges.unshift({codeHash,userId:member.id,email:member.email,role:member.role,name:member.name,workspaceId,expiresAt,used:false})
          s.googleLoginExchanges=s.googleLoginExchanges.filter(x=>!x.used&&Date.parse(x.expiresAt)>Date.now()).slice(0,200)
          s.audit=s.audit||[]
          s.audit.unshift({id:randomUUID(),action:'auth.google_verified',entityId:member.id,at:new Date().toISOString()})
          s.audit=s.audit.slice(0,1000)
        })
        if(!AUTH_GOOGLE_SUCCESS_URL) return send(req,res,200,{exchangeCode:rawCode,workspaceId})
        const target=new URL(AUTH_GOOGLE_SUCCESS_URL)
        target.searchParams.set('google_code',rawCode)
        target.searchParams.set('google_workspace',workspaceId)
        target.hash='/login'
        res.writeHead(302,{Location:target.toString()});res.end()
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/google/exchange') {
      const body=await readBody(req)
      const code=String(body.code||'')
      const targetWorkspace=String(body.workspaceId||workspaceId)
      if(!code||!/^[A-Za-z0-9_-]{1,64}$/.test(targetWorkspace)) return send(req,res,400,{error:'code and valid workspaceId required'})
      workspaceId=targetWorkspace
      return withWorkspace(workspaceId,async()=>{
        const state=await getState()
        const codeHash=createHash('sha256').update(code).digest('hex')
        const exchange=(state.googleLoginExchanges||[]).find(x=>x.codeHash===codeHash&&!x.used&&Date.parse(x.expiresAt)>Date.now())
        if(!exchange) return send(req,res,400,{error:'invalid or expired Google login code'})
        const ttl=Number(process.env.TOKEN_TTL_SECONDS||3600)
        const jti=randomUUID()
        const expiresAt=new Date(Date.now()+ttl*1000).toISOString()
        const token=createToken({email:exchange.email,userId:exchange.userId,workspaceId,role:exchange.role,jti},JWT_SECRET,ttl)
        await mutateState(s=>{
          const found=(s.googleLoginExchanges||[]).find(x=>x.codeHash===codeHash)
          if(found){found.used=true;found.usedAt=new Date().toISOString()}
          s.sessions=s.sessions||[]
          s.sessions.unshift({jti,userId:exchange.userId,email:exchange.email,role:exchange.role,status:'active',createdAt:new Date().toISOString(),expiresAt})
          s.sessions=s.sessions.filter(x=>!x.expiresAt||Date.parse(x.expiresAt)>Date.now()).slice(0,5000)
          s.audit=s.audit||[]
          s.audit.unshift({id:randomUUID(),action:'auth.google_login',entityId:exchange.userId,at:new Date().toISOString()})
          s.audit=s.audit.slice(0,1000)
        })
        return send(req,res,200,{token,user:{id:exchange.userId,email:exchange.email,name:exchange.name,role:exchange.role},workspaceId,expiresIn:ttl})
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/password/forgot') {
      const body=await readBody(req)
      try{
        const result=await handleRecoverAccount({mode:'request',email:body.email,isProd:IS_PROD})
        return send(req,res,202,result)
      }catch(error){
        return send(req,res,Number(error?.status||500),{error:error instanceof Error?error.message:'password reset request failed',code:error?.code||'password_reset_request_failed'})
      }
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/password/reset') {
      const body=await readBody(req)
      try{
        const result=await handleRecoverAccount({mode:'complete',token:body.token,password:body.password,isProd:IS_PROD})
        return send(req,res,200,result)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'password reset failed',code:error?.code||'password_reset_failed'})
      }
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
      const jti=req.user?.jti
      if(jti) await mutateState(s=>{
        const session=(s.sessions||[]).find(x=>x.jti===jti)
        if(session){session.status='revoked';session.revokedAt=new Date().toISOString()}
        s.audit.unshift({id:randomUUID(),action:'auth.logout',entityId:req.user?.userId||'unknown',at:new Date().toISOString()})
      })
      return send(req,res,200,{ok:true})
    }
    if (req.method === 'GET' && url.pathname === '/api/auth/me') {
      return send(req,res,200,{user:{id:req.user.userId,email:req.user.email,role:req.user.role},workspaceId})
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/workspace/switch') {
      const body=await readBody(req)
      const targetWorkspaceId=String(body.workspaceId||'').trim()
      if(!/^[A-Za-z0-9_-]{1,64}$/.test(targetWorkspaceId)) return send(req,res,400,{error:'invalid workspace id'})
      const state=await withWorkspace('ws_default',()=>getState())
      const target=(state.workspaces||[]).find(item=>String(item.id)===targetWorkspaceId)
      if(!target) return send(req,res,404,{error:'workspace not found'})
      let targetMember
      try{
        const targetState=await withWorkspace(targetWorkspaceId,()=>getState())
        targetMember=assertWorkspaceMembership(targetState,req.user)
      }catch(error){
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'auth.workspace_switch_denied',entityType:'workspace',entityId:targetWorkspaceId,requestId:req.requestId,traceId:req.context?.traceId,outcome:'denied',metadata:{reason:error?.code||'workspace_membership_required'}}).catch(()=>{})
        return send(req,res,403,{error:'workspace membership required',code:error?.code||'workspace_membership_required'})
      }
      const ttl=Number(process.env.TOKEN_TTL_SECONDS||3600)
      const jti=randomUUID()
      const now=new Date().toISOString()
      const expiresAt=new Date(Date.now()+ttl*1000).toISOString()
      const targetRole=String(targetMember.role||req.user.role||'analyst')
      const token=createToken({email:req.user.email,userId:req.user.userId,workspaceId:targetWorkspaceId,role:targetRole,jti},JWT_SECRET,ttl)
      await mutateState(s=>{
        const previous=(s.sessions||[]).find(item=>item.jti===req.user.jti)
        if(previous){previous.status='revoked';previous.revokedAt=now}
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'auth.workspace_switched',entityId:targetWorkspaceId,userId:req.user.userId,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      await withWorkspace(targetWorkspaceId,()=>mutateState(s=>{
        s.sessions=s.sessions||[]
        s.sessions.unshift({jti,userId:req.user.userId,email:req.user.email,role:targetRole,status:'active',createdAt:now,expiresAt})
        s.sessions=s.sessions.filter(item=>!item.expiresAt||Date.parse(item.expiresAt)>Date.now()).slice(0,5000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'auth.workspace_session_started',entityId:req.user.userId,sourceWorkspaceId:workspaceId,at:now})
        s.audit=s.audit.slice(0,1000)
      }))
      await appendAuditRecord({workspaceId:targetWorkspaceId,actorId:req.user.userId,action:'auth.workspace_switched',entityType:'workspace',entityId:targetWorkspaceId,requestId:req.requestId,traceId:req.context?.traceId,metadata:{sourceWorkspaceId:workspaceId}})
      return send(req,res,200,{token,workspaceId:targetWorkspaceId,expiresIn:ttl})
    }
    if (req.method === 'GET' && url.pathname === '/api/members') {
      const state=await getState()
      return send(req,res,200,{items:(state.members||[]).map(({passwordHash,...member})=>member)})
    }
    if (req.method === 'POST' && url.pathname === '/api/members/invite') {
      const memberCapacity=await resourceCountAllowed(workspaceId,'members')
      if(!memberCapacity.allowed) return send(req,res,429,{error:'member limit reached',usage:memberCapacity})
      const body=await readBody(req)
      const email=String(body.email||'').trim().toLowerCase()
      const role=String(body.role||'analyst')
      if(!email.includes('@')) return send(req,res,400,{error:'valid email required'})
      if(!['owner','admin','analyst','operator'].includes(role)) return send(req,res,400,{error:'invalid role'})
      const state=await getState()
      if((state.members||[]).some(x=>String(x.email).toLowerCase()===email&&x.status==='active')) return send(req,res,409,{error:'member already exists'})
      const rawToken=randomBytes(24).toString('base64url')
      const tokenHash=createHash('sha256').update(rawToken).digest('hex')
      const invitation={id:'inv_'+randomUUID(),email,role,tokenHash,status:'pending',createdAt:new Date().toISOString(),expiresAt:new Date(Date.now()+7*24*60*60*1000).toISOString(),invitedBy:req.user.userId}
      await mutateState(s=>{
        s.invitations=s.invitations||[]
        s.invitations.unshift(invitation)
        s.audit.unshift({id:randomUUID(),action:'member.invited',entityId:invitation.id,email,role,at:invitation.createdAt})
      })
      return send(req,res,201,{id:invitation.id,email,role,status:'pending',expiresAt:invitation.expiresAt,inviteToken:rawToken,notice:'Send this invite token through your approved email provider; only its SHA-256 hash is stored.'})
    }
    if (req.method === 'POST' && url.pathname === '/api/members/role') {
      const body=await readBody(req)
      const memberId=String(body.memberId||'')
      const role=String(body.role||'')
      if(!memberId||!['owner','admin','analyst','operator'].includes(role)) return send(req,res,400,{error:'memberId and valid role required'})
      if(memberId===req.user.userId&&req.user.role==='owner'&&role!=='owner') return send(req,res,409,{error:'owner cannot remove their own owner role'})
      let updated=null
      await mutateState(s=>{
        const member=(s.members||[]).find(x=>x.id===memberId)
        if(member){member.role=role;member.updatedAt=new Date().toISOString();updated={...member};delete updated.passwordHash}
        s.sessions=(s.sessions||[]).map(x=>x.userId===memberId?{...x,status:'revoked',revokedAt:new Date().toISOString()}:x)
        s.audit.unshift({id:randomUUID(),action:'member.role_changed',entityId:memberId,role,at:new Date().toISOString()})
      })
      return updated?send(req,res,200,updated):send(req,res,404,{error:'member not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/members/deactivate') {
      const body=await readBody(req)
      try{
        const updated=await handleRemoveMember({
          workspaceId,
          memberId:body.memberId,
          actorId:req.user?.userId||null
        })
        return updated?send(req,res,200,updated):send(req,res,404,{error:'member not found'})
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'member deactivation failed',code:error?.code||'member_deactivation_failed'})
      }
    }
    if (req.method === 'POST' && url.pathname === '/api/invitations/activate') {
      const body=await readBody(req)
      const inviteToken=String(body.inviteToken||'')
      const password=String(body.password||'')
      const name=String(body.name||'').trim()
      if(!inviteToken||password.length<8||!name) return send(req,res,400,{error:'inviteToken, name and password length >= 8 required'})
      const tokenHash=createHash('sha256').update(inviteToken).digest('hex')
      const state=await getState()
      const invitation=(state.invitations||[]).find(x=>x.tokenHash===tokenHash&&x.status==='pending')
      if(!invitation||Date.parse(invitation.expiresAt)<=Date.now()) return send(req,res,400,{error:'invalid or expired invitation'})
      const member={id:'usr_'+randomUUID(),email:invitation.email,name,role:invitation.role,status:'active',passwordHash:hashPassword(password),createdAt:new Date().toISOString()}
      await mutateState(s=>{
        s.members=s.members||[]
        s.members.push(member)
        const inv=(s.invitations||[]).find(x=>x.id===invitation.id)
        if(inv){inv.status='accepted';inv.acceptedAt=new Date().toISOString()}
        s.audit.unshift({id:randomUUID(),action:'member.activated',entityId:member.id,email:member.email,role:member.role,at:member.createdAt})
      })
      return send(req,res,201,{user:{id:member.id,email:member.email,name:member.name,role:member.role},workspaceId})
    }
    if (req.method === 'POST' && url.pathname === '/api/demo-requests') {
      const body = await readBody(req)
      if (!body.email || !body.company) return send(req,res,400,{error:'email and company are required'})
      const item={id:randomUUID(),status:'captured',request:body,createdAt:new Date().toISOString()}
      await mutateState(s=>{s.demoRequests.unshift(item);s.demoRequests=s.demoRequests.slice(0,5000)})
      return send(req,res,201,item)
    }
    if (req.method === 'POST' && url.pathname === '/api/demo-bookings') {
      const body=await readBody(req)
      const demoRequestId=String(body.demoRequestId||'').trim()
      const startsAt=String(body.startsAt||'').trim()
      if(!demoRequestId) return send(req,res,400,{error:'demoRequestId required'})
      const startDate=new Date(startsAt)
      if(!startsAt||Number.isNaN(startDate.getTime())) return send(req,res,400,{error:'valid startsAt required'})
      if(startDate.getTime()<Date.now()-60000) return send(req,res,400,{error:'demo booking must be in the future'})
      if(startDate.getTime()>Date.now()+90*24*60*60*1000) return send(req,res,400,{error:'demo booking must be within 90 days'})
      const state=await getState()
      const demoRequest=(state.demoRequests||[]).find(x=>x.id===demoRequestId)
      if(!demoRequest) return send(req,res,404,{error:'demo request not found'})
      const existing=(state.demoBookings||[]).find(x=>x.demoRequestId===demoRequestId&&x.status==='confirmed')
      if(existing) return send(req,res,200,existing)
      const item={
        id:'demo_booking_'+randomUUID(),demoRequestId,status:'confirmed',startsAt:startDate.toISOString(),
        durationMinutes:45,email:String(demoRequest.request?.email||''),company:String(demoRequest.request?.company||''),
        createdAt:new Date().toISOString()
      }
      await mutateState(s=>{
        s.demoBookings=s.demoBookings||[]
        s.demoBookings.unshift(item)
        s.demoBookings=s.demoBookings.slice(0,5000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'demo.booking_confirmed',entityId:item.id,demoRequestId,startsAt:item.startsAt,at:item.createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,item)
    }
    if (req.method === 'GET' && url.pathname === '/api/workspace/overview') {
      const [leadStats,attr,agentRuns]=await Promise.all([
        leadOpsStats(workspaceId).catch(()=>({available:false,total:0,abQuality:0})),
        attributionStats(workspaceId).catch(()=>({available:false,matchedEvents:0,matchedValue:0,matchRate:0})),
        listAgentRuns(workspaceId,100).catch(()=>[])
      ])
      const state=await getState()
      const activeAgents=new Set(agentRuns.filter(x=>['queued','running','succeeded','completed'].includes(String(x.status||'').toLowerCase())).map(x=>x.agent_type||x.agentType)).size
      return send(req,res,200,{
        revenueAttributed:Number(attr?.matchedValue||0),
        qualifiedLeads:Number(leadStats?.abQuality||0),
        signalCoverage:attr?.matchRate==null?null:Number(attr.matchRate),
        activeAgents,
        profiles:Number(leadStats?.total||0),
        matchedEvents:Number(attr?.matchedEvents||0),
        deliveries:Number((state.signalDeliveries||[]).length)
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/integrations') {
      const state=await getState()
      const tokenHealth=await connectorTokenHealth(workspaceId).catch(()=>[])
      const connections=state.connectorConnections||[]
      return send(req,res,200,{items:integrations.map(name=>{
        if(name==='Ace Data Hub'){
          return {name,status:'connected',provider:'ace',authType:'internal',capability:'canonical_destination',configured:true,readSupported:false,backfillSupported:false,incrementalSyncSupported:false,writeSupported:true,updatedAt:null,tokenHealth:null}
        }
        if(name==='ChatGPT Ads'){
          const configured=Boolean(process.env.OPENAI_CONVERSIONS_API_KEY&&process.env.OPENAI_ADS_PIXEL_ID)
          return {name,status:configured?'connected':'needs_configuration',provider:'openai',authType:'server_secret',capability:'native_server_capi',configured,updatedAt:null,tokenHealth:null}
        }
        const saved=connections.find(x=>x.connector===name)
        const provider=CONNECTOR_PROVIDERS[name]
        const secretProvider=SERVER_SECRET_CONNECTORS[name]
        const health=tokenHealth.find(x=>x.connector===name)||null
        return {
          name,
          status:saved?.status||(provider?'available':secretProvider?'available':'manual'),
          provider:provider?.provider||secretProvider?.provider||'custom',
          authType:provider?.authType||secretProvider?.authType||'manual',
          capability:provider?'native_oauth':secretProvider?.capability||'configurable_adapter',
          readSupported:connectorReadCatalog().includes(name),
          backfillSupported:connectorReadCatalog().includes(name),
          incrementalSyncSupported:connectorReadCatalog().includes(name),
          configured:provider?Boolean(provider.clientId&&provider.clientSecret&&CONNECTOR_REDIRECT_URI):secretProvider?connectorVaultReady():false,
          credentialFields:secretProvider?.fields||[],
          updatedAt:saved?.updatedAt||null,
          tokenHealth:health
        }
      }),requests:(state.integrationRequests||[]).slice(0,100)})
    }
    if (req.method === 'GET' && url.pathname === '/api/integrations/sync-schedules') {
      const items=await listConnectorSyncSchedules({workspaceId})
      return send(req,res,200,{items,readConnectors:connectorReadCatalog()})
    }
    if (req.method === 'POST' && url.pathname === '/api/integrations/sync-schedules') {
      const body=await readBody(req)
      const connector=String(body.connector||'').trim()
      if(!connectorReadCatalog().includes(connector))return send(req,res,400,{error:'connector does not support read synchronization',supported:connectorReadCatalog()})
      try{
        const item=await saveConnectorSyncSchedule({
          workspaceId,
          connector,
          enabled:body.enabled!==false,
          intervalMinutes:Number(body.intervalMinutes||60),
          options:body.options&&typeof body.options==='object'?body.options:{}
        })
        return send(req,res,200,{item})
      }catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'invalid connector schedule'})}
    }
    if (req.method === 'GET' && url.pathname === '/api/integrations/sync-runs') {
      const connector=String(url.searchParams.get('connector')||'').trim()||null
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||50),200))
      const items=await listConnectorSyncRuns({workspaceId,connector,limit})
      return send(req,res,200,{items,readConnectors:connectorReadCatalog()})
    }
    if (req.method === 'GET' && url.pathname === '/api/integrations/data-summary') {
      return send(req,res,200,await connectorDataSummary(workspaceId))
    }
    if (req.method === 'POST' && url.pathname === '/api/integrations/sync') {
      const body=await readBody(req)
      const connector=String(body.connector||'').trim()
      const mode=String(body.mode||'incremental').trim().toLowerCase()
      if(!connectorReadCatalog().includes(connector))return send(req,res,400,{error:'connector does not support read synchronization',connector,supported:connectorReadCatalog()})
      if(!['backfill','incremental','manual'].includes(mode))return send(req,res,400,{error:'mode must be backfill, incremental, or manual'})
      const parseDate=value=>{
        if(value==null||value==='')return null
        const date=new Date(value)
        if(Number.isNaN(date.getTime()))throw new Error('invalid sync date')
        return date.toISOString()
      }
      let start=null,end=null
      try{start=parseDate(body.start);end=parseDate(body.end)}catch(error){return send(req,res,400,{error:error.message})}
      if(start&&end&&Date.parse(start)>Date.parse(end))return send(req,res,400,{error:'sync start must be before end'})
      const operationKey=String(req.headers['idempotency-key']||req.requestId||randomUUID())
      const job=await handleSubmitJob({
        workspaceId,
        kind:'connector_sync',
        payload:{connector,mode,start,end,options:body.options&&typeof body.options==='object'?body.options:{}},
        idempotencyKey:'connector-sync:'+connector+':'+operationKey,
        maxAttempts:Number(process.env.CONNECTOR_SYNC_MAX_ATTEMPTS||3),
        deadlineAt:new Date(Date.now()+Number(process.env.CONNECTOR_SYNC_JOB_DEADLINE_MS||30*60*1000)).toISOString(),
        inputSnapshot:{schemaVersion:'connector-sync.v1',connector,mode,start,end,capturedAt:new Date().toISOString()},
        resultSchemaVersion:'connector-sync-result.v1'
      })
      if(!job)return send(req,res,503,{error:'durable connector sync requires DATABASE_URL'})
      return send(req,res,202,{jobId:job.id,status:job.status,connector,mode})
    }
    if (req.method === 'GET' && url.pathname === '/api/integration-flows') {
      const state=await getState()
      const items=(state.integrationFlows||[]).slice().sort((a,b)=>Date.parse(b.updatedAt||b.createdAt||0)-Date.parse(a.updatedAt||a.createdAt||0))
      const active=items.filter(x=>x.status==='active').length
      const healthy=items.filter(x=>x.lastTestStatus==='passed').length
      return send(req,res,200,{items,stats:{total:items.length,active,healthy,needsAttention:Math.max(0,items.length-healthy)}})
    }
    if (req.method === 'POST' && url.pathname === '/api/integration-flows') {
      const body=await readBody(req)
      const name=String(body.name||'').trim()
      const source=String(body.source||'').trim()
      const destination=String(body.destination||'').trim()
      if(name.length<2||name.length>120) return send(req,res,400,{error:'name must be 2-120 characters'})
      if(!source||!destination) return send(req,res,400,{error:'source and destination are required'})
      if(source===destination) return send(req,res,400,{error:'source and destination must be different'})
      const now=new Date().toISOString()
      const item={
        id:'flow_'+randomUUID(),
        name,
        source,
        destination,
        object:String(body.object||'Lead / customer event').slice(0,120),
        trigger:String(body.trigger||'On record change').slice(0,120),
        identityField:String(body.identityField||'email / phone / click id').slice(0,120),
        mode:['Real-time','Every 15 minutes','Hourly','Daily'].includes(body.mode)?body.mode:'Real-time',
        status:'paused',
        executionSupported:false,
        executionMode:null,
        lastTestAt:null,
        lastTestStatus:'not_tested',
        lastTestDetail:'Run a readiness test before activation.',
        createdAt:now,
        updatedAt:now
      }
      await mutateState(s=>{
        s.integrationFlows=s.integrationFlows||[]
        s.integrationFlows.unshift(item)
        s.integrationFlows=s.integrationFlows.slice(0,500)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'integration_flow.created',entityId:item.id,source,destination,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/integration-flows/test') {
      const body=await readBody(req)
      const id=String(body.id||'')
      const state=await getState()
      const item=(state.integrationFlows||[]).find(x=>x.id===id)
      if(!item) return send(req,res,404,{error:'integration flow not found'})
      const connections=state.connectorConnections||[]
      const custom=await listCustomIntegrations(workspaceId).catch(()=>[])
      const readiness=name=>{
        const native=connections.find(x=>x.connector===name)
        const customMatch=custom.find(x=>String(x.name||'').toLowerCase()===String(name).toLowerCase())
        if(native) return ['connected','healthy','active'].includes(String(native.status||'').toLowerCase())
        if(customMatch) return ['healthy','connected','active'].includes(String(customMatch.status||'').toLowerCase())
        return false
      }
      const sourceReady=readiness(item.source)
      const destinationReady=item.destination==='Ace Data Hub'?true:readiness(item.destination)
      const executionSupported=connectorReadCatalog().includes(item.source)&&item.destination==='Ace Data Hub'
      const passed=sourceReady&&destinationReady&&executionSupported
      const now=new Date().toISOString()
      const detail=!sourceReady
        ?'Connect '+item.source+' before activation.'
        :!destinationReady
          ?'Connect '+item.destination+' before activation.'
          :!executionSupported
            ?'This generic flow pair is not executable. Use Ace Data Hub as the destination for ingestion, or use Event Rules / Audiences / CRM writeback for governed cross-provider activation.'
            :'Source is readable and Ace Data Hub is available. This flow will execute through durable connector sync jobs.'
      await mutateState(s=>{
        const flow=(s.integrationFlows||[]).find(x=>x.id===id)
        if(flow){flow.executionSupported=executionSupported;flow.executionMode=executionSupported?'connector_sync':null;flow.lastTestAt=now;flow.lastTestStatus=passed?'passed':'needs_attention';flow.lastTestDetail=detail;flow.updatedAt=now}
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'integration_flow.tested',entityId:id,status:passed?'passed':'needs_attention',at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,{id,passed,sourceReady,destinationReady,detail,testedAt:now})
    }
    if (req.method === 'POST' && url.pathname === '/api/integration-flows/toggle') {
      const body=await readBody(req)
      const id=String(body.id||'')
      const enabled=Boolean(body.enabled)
      const snapshot=await getState()
      const existing=(snapshot.integrationFlows||[]).find(x=>x.id===id)
      if(!existing) return send(req,res,404,{error:'integration flow not found'})
      if(enabled&&existing.lastTestStatus!=='passed') return send(req,res,409,{error:'flow must pass its readiness test before activation'})
      if(enabled&&existing.executionSupported!==true) return send(req,res,409,{error:'flow pair does not have an executable runtime adapter'})
      const cadenceMinutes={'Real-time':5,'Every 15 minutes':15,'Hourly':60,'Daily':1440}[existing.mode]||60
      let schedule=null
      if(existing.executionSupported===true){
        schedule=await saveConnectorSyncSchedule({
          workspaceId,
          connector:existing.source,
          enabled,
          intervalMinutes:cadenceMinutes,
          options:{integrationFlowId:id,destination:existing.destination,object:existing.object,trigger:existing.trigger}
        })
      }
      const now=new Date().toISOString()
      await mutateState(s=>{
        const flow=(s.integrationFlows||[]).find(x=>x.id===id)
        if(flow){flow.status=enabled?'active':'paused';flow.scheduleId=schedule?.id||flow.scheduleId||null;flow.updatedAt=now}
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:enabled?'integration_flow.activated':'integration_flow.paused',entityId:id,scheduleId:schedule?.id||null,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,{id,status:enabled?'active':'paused',schedule,updatedAt:now})
    }
    if (req.method === 'POST' && url.pathname === '/api/integration-requests') {
      const body=await readBody(req)
      const connector=String(body.connector||'').trim()
      const businessNeed=String(body.businessNeed||'').trim()
      if(connector.length<2||connector.length>120) return send(req,res,400,{error:'connector must be 2-120 characters'})
      if(businessNeed.length<5||businessNeed.length>1000) return send(req,res,400,{error:'businessNeed must be 5-1000 characters'})
      const now=new Date().toISOString()
      const item={
        id:'ireq_'+randomUUID(),
        connector,
        businessNeed,
        direction:['Inbound','Outbound','Bidirectional'].includes(body.direction)?body.direction:'Bidirectional',
        priority:['Normal','High','Critical'].includes(body.priority)?body.priority:'Normal',
        status:'requested',
        requestedBy:req.user?.email||req.user?.userId||'workspace',
        createdAt:now
      }
      await mutateState(s=>{
        s.integrationRequests=s.integrationRequests||[]
        s.integrationRequests.unshift(item)
        s.integrationRequests=s.integrationRequests.slice(0,500)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'integration.requested',entityId:item.id,connector:item.connector,priority:item.priority,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'GET' && url.pathname === '/api/webhook-subscriptions'){
      return send(req,res,200,{items:await listWebhookSubscriptions({workspaceId})})
    }
    if (req.method === 'POST' && url.pathname === '/api/webhook-subscriptions'){
      const body=await readBody(req)
      try{
        const created=await createWebhookSubscription({
          workspaceId,
          name:body.name,
          destinationUrl:body.destinationUrl,
          eventTypes:body.eventTypes,
          signingSecret:body.signingSecret||null,
          signingKeyId:body.signingKeyId||null,
          maxAttempts:body.maxAttempts,
          retryWindowSeconds:body.retryWindowSeconds,
          actorId:req.user?.userId||null
        })
        await appendAuditRecord({
          workspaceId,actorId:req.user?.userId,action:'webhook.subscription_created',
          entityType:'webhook_subscription',entityId:created.subscription.id,
          requestId:req.requestId,traceId:req.context?.traceId,
          metadata:{destination:new URL(created.subscription.destinationUrl).hostname,eventTypes:created.subscription.eventTypes}
        }).catch(()=>{})
        return send(req,res,201,created)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'webhook subscription creation failed',code:error?.code||'webhook_subscription_create_failed'})
      }
    }
    const webhookSubscriptionStatusMatch=url.pathname.match(/^\/api\/webhook-subscriptions\/([^/]+)\/status$/)
    if(req.method==='POST'&&webhookSubscriptionStatusMatch){
      const body=await readBody(req)
      try{
        const subscription=await setWebhookSubscriptionStatus({
          workspaceId,id:decodeURIComponent(webhookSubscriptionStatusMatch[1]),status:body.status
        })
        if(!subscription)return send(req,res,404,{error:'webhook subscription not found'})
        await appendAuditRecord({
          workspaceId,actorId:req.user?.userId,action:'webhook.subscription_status_changed',
          entityType:'webhook_subscription',entityId:subscription.id,
          requestId:req.requestId,traceId:req.context?.traceId,metadata:{status:subscription.status}
        }).catch(()=>{})
        return send(req,res,200,subscription)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'webhook status change failed',code:error?.code||'webhook_status_change_failed'})
      }
    }
    const webhookSubscriptionTestMatch=url.pathname.match(/^\/api\/webhook-subscriptions\/([^/]+)\/test$/)
    if(req.method==='POST'&&webhookSubscriptionTestMatch){
      try{
        const delivery=await createWebhookTestDelivery({
          workspaceId,subscriptionId:decodeURIComponent(webhookSubscriptionTestMatch[1]),actorId:req.user?.userId||null
        })
        if(!delivery)return send(req,res,404,{error:'webhook subscription not found'})
        await appendAuditRecord({
          workspaceId,actorId:req.user?.userId,action:'webhook.test_queued',
          entityType:'webhook_delivery',entityId:delivery.id,
          requestId:req.requestId,traceId:req.context?.traceId
        }).catch(()=>{})
        return send(req,res,202,delivery)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'webhook test delivery failed',code:error?.code||'webhook_test_failed'})
      }
    }
    if(req.method==='GET'&&url.pathname==='/api/webhook-deliveries'){
      return send(req,res,200,{items:await listWebhookDeliveries({
        workspaceId,
        subscriptionId:url.searchParams.get('subscriptionId')||null,
        status:url.searchParams.get('status')||null,
        limit:Number(url.searchParams.get('limit')||100)
      })})
    }
    const webhookAttemptsMatch=url.pathname.match(/^\/api\/webhook-deliveries\/([^/]+)\/attempts$/)
    if(req.method==='GET'&&webhookAttemptsMatch){
      return send(req,res,200,{items:await listWebhookDeliveryAttempts({workspaceId,deliveryId:decodeURIComponent(webhookAttemptsMatch[1])})})
    }
    const webhookReplayMatch=url.pathname.match(/^\/api\/webhook-deliveries\/([^/]+)\/replay$/)
    if(req.method==='POST'&&webhookReplayMatch){
      try{
        const delivery=await handleReplayWebhookDelivery({workspaceId,deliveryId:decodeURIComponent(webhookReplayMatch[1]),actorId:req.user?.userId||null})
        if(!delivery)return send(req,res,404,{error:'webhook delivery not found'})
        await appendAuditRecord({
          workspaceId,actorId:req.user?.userId,action:'webhook.delivery_replayed',
          entityType:'webhook_delivery',entityId:delivery.id,
          requestId:req.requestId,traceId:req.context?.traceId,metadata:{replayOf:delivery.replayOf}
        }).catch(()=>{})
        return send(req,res,202,delivery)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'webhook replay failed',code:error?.code||'webhook_replay_failed'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/custom-integrations') return send(req,res,200,{items:await listCustomIntegrations(workspaceId)})
    if (req.method === 'POST' && url.pathname === '/api/custom-integrations/test') {
      const body=await readBody(req)
      if(!body.baseUrl&&!body.id) return send(req,res,400,{error:'baseUrl or id required'})
      try{
        const result=await handleReconcileIntegration({workspaceId,input:body})
        return send(req,res,result.ok?200:422,{...result,testedAt:new Date().toISOString()})
      }catch(error){
        return send(req,res,422,{ok:false,error:error instanceof Error?error.message:'connection test failed',testedAt:new Date().toISOString()})
      }
    }
    if (req.method === 'POST' && url.pathname === '/api/custom-integrations') {
      const integrationCapacity=await resourceCountAllowed(workspaceId,'custom_integrations')
      if(!integrationCapacity.allowed) return send(req,res,429,{error:'custom integration limit reached',usage:integrationCapacity})
      const body=await readBody(req)
      if(!body.name || !body.baseUrl || !body.identity) return send(req,res,400,{error:'name, baseUrl and identity required'})
      const item=await handleConnectProvider({workspaceId,input:body})
      await mutateState(s=>{s.audit.unshift({id:randomUUID(),action:'custom_integration.created',entityId:item.id,at:new Date().toISOString()});s.audit=s.audit.slice(0,1000)})
      return send(req,res,201,item)
    }
    if (req.method === 'POST' && url.pathname === '/api/integrations/connect-secret') {
      const body=await readBody(req)
      const connector=String(body.connector||'')
      const definition=SERVER_SECRET_CONNECTORS[connector]
      if(!definition) return send(req,res,400,{error:'connector does not support server-secret configuration'})
      if(!connectorVaultReady()) return send(req,res,503,{error:'connector credential vault is not configured',required:['CONNECTOR_ENCRYPTION_KEY']})
      const values={}
      for(const field of definition.fields){
        const value=String(body.credentials?.[field.key]||'').trim()
        if(!value) return send(req,res,400,{error:field.label+' is required',field:field.key})
        if(value.length>4096) return send(req,res,400,{error:field.label+' is too long',field:field.key})
        values[field.key]=value
      }
      const now=new Date().toISOString()
      const encrypted=encryptSecret(values)
      await mutateState(s=>{
        s.connectorCredentials=s.connectorCredentials||[]
        const existingCredential=s.connectorCredentials.find(x=>x.connector===connector)
        const credential={id:existingCredential?.id||'cred_'+randomUUID(),connector,provider:definition.provider,encrypted,expiresAt:null,updatedAt:now,createdAt:existingCredential?.createdAt||now}
        if(existingCredential)Object.assign(existingCredential,credential);else s.connectorCredentials.unshift(credential)
        s.connectorConnections=s.connectorConnections||[]
        const existingConnection=s.connectorConnections.find(x=>x.connector===connector)
        const connection={id:existingConnection?.id||'conn_'+randomUUID(),connector,provider:definition.provider,status:'connected',authType:'server_secret',createdAt:existingConnection?.createdAt||now,updatedAt:now,expiresAt:null}
        if(existingConnection)Object.assign(existingConnection,connection);else s.connectorConnections.unshift(connection)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'connector.server_secret_connected',entityId:connector,provider:definition.provider,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{connector,status:'connected',authType:'server_secret',provider:definition.provider,updatedAt:now})
    }
    if (req.method === 'POST' && url.pathname === '/api/integrations/connect') {
      const body=await readBody(req)
      const connector=String(body.connector||'')
      if(!connector) return send(req,res,400,{error:'connector required'})
      const provider=CONNECTOR_PROVIDERS[connector]
      if(!provider) return send(req,res,200,{connector,status:'manual_configuration_required',authType:'manual'})
      if(!CONNECTOR_REDIRECT_URI || !provider.clientId || !provider.clientSecret) {
        const now=new Date().toISOString()
        await mutateState(s=>{
          s.connectorConnections=s.connectorConnections||[]
          const existing=s.connectorConnections.find(x=>x.connector===connector)
          const record={id:existing?.id||'conn_'+randomUUID(),connector,provider:provider.provider,status:'needs_configuration',authType:provider.authType,createdAt:existing?.createdAt||now,updatedAt:now}
          if(existing) Object.assign(existing,record); else s.connectorConnections.unshift(record)
        })
        return send(req,res,409,{connector,status:'needs_configuration',required:['CONNECTOR_OAUTH_REDIRECT_URI',provider.provider.toUpperCase()+'_OAUTH_CLIENT_ID',provider.provider.toUpperCase()+'_OAUTH_CLIENT_SECRET']})
      }
      const stateToken=createOAuthState(workspaceId)
      const pkce=createPkce()
      const createdAt=new Date().toISOString()
      const expiresAt=new Date(Date.now()+10*60*1000).toISOString()
      await mutateState(s=>{
        s.oauthStates=s.oauthStates||[]
        s.oauthStates=s.oauthStates.filter(x=>Date.parse(x.expiresAt)>Date.now())
        s.oauthStates.unshift({stateHash:hashOAuthState(stateToken),workspaceId,connector,provider:provider.provider,verifier:pkce.verifier,createdAt,expiresAt})
        s.audit.unshift({id:randomUUID(),action:'connector.oauth_started',entityId:connector,at:createdAt})
      })
      const auth=new URL(provider.authorizeUrl)
      auth.searchParams.set('client_id',provider.clientId)
      auth.searchParams.set('redirect_uri',CONNECTOR_REDIRECT_URI)
      auth.searchParams.set('response_type','code')
      auth.searchParams.set('state',stateToken)
      auth.searchParams.set('scope',provider.scopes.join(' '))
      auth.searchParams.set('code_challenge',pkce.challenge)
      auth.searchParams.set('code_challenge_method','S256')
      if(provider.provider==='google') auth.searchParams.set('access_type','offline')
      if(provider.provider==='google') auth.searchParams.set('prompt','consent')
      if(connector==='Zoho CRM'){auth.searchParams.set('access_type','offline');auth.searchParams.set('prompt','consent')}
      return send(req,res,200,{connector,status:'authorization_required',authorizationUrl:auth.toString(),expiresAt})
    }
    if (req.method === 'GET' && url.pathname === '/api/integrations/oauth/callback') {
      const stateToken=String(url.searchParams.get('state')||'')
      const code=String(url.searchParams.get('code')||'')
      const providerError=String(url.searchParams.get('error')||'')
      if(providerError) return send(req,res,400,{error:'provider authorization failed',providerError})
      if(!stateToken||!code) return send(req,res,400,{error:'state and code required'})
      const snapshot=await getState()
      const pending=(snapshot.oauthStates||[]).find(x=>x.stateHash===hashOAuthState(stateToken)&&x.workspaceId===workspaceId)
      if(!pending || Date.parse(pending.expiresAt)<=Date.now()) return send(req,res,400,{error:'invalid or expired oauth state'})
      const provider=CONNECTOR_PROVIDERS[pending.connector]
      if(!provider) return send(req,res,400,{error:'unsupported connector provider'})
      const tokenBody=new URLSearchParams({
        client_id:provider.clientId,
        client_secret:provider.clientSecret,
        redirect_uri:CONNECTOR_REDIRECT_URI,
        code,
        grant_type:'authorization_code',
        code_verifier:pending.verifier
      })
      if(Array.isArray(provider.tokenScopes)&&provider.tokenScopes.length)tokenBody.set('scope',provider.tokenScopes.join(' '))
      const tokenResponse=await fetch(provider.tokenUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:tokenBody})
      const tokenPayload=await tokenResponse.json().catch(()=>({}))
      if(!tokenResponse.ok) return send(req,res,502,{error:'oauth token exchange failed',provider:provider.provider,status:tokenResponse.status})
      if(!connectorVaultReady()) return send(req,res,503,{error:'connector credential vault is not configured'})
      const encrypted=encryptSecret(tokenPayload)
      const now=new Date().toISOString()
      const expiresAt=tokenPayload.expires_in?new Date(Date.now()+Number(tokenPayload.expires_in)*1000).toISOString():null
      await mutateState(s=>{
        s.oauthStates=(s.oauthStates||[]).filter(x=>x.stateHash!==hashOAuthState(stateToken))
        s.connectorCredentials=s.connectorCredentials||[]
        const old=s.connectorCredentials.find(x=>x.connector===pending.connector)
        const credential={id:old?.id||'cred_'+randomUUID(),connector:pending.connector,provider:provider.provider,encrypted,expiresAt,updatedAt:now,createdAt:old?.createdAt||now}
        if(old) Object.assign(old,credential); else s.connectorCredentials.unshift(credential)
        s.connectorConnections=s.connectorConnections||[]
        const connection=s.connectorConnections.find(x=>x.connector===pending.connector)
        const record={id:connection?.id||'conn_'+randomUUID(),connector:pending.connector,provider:provider.provider,status:'connected',authType:'oauth2',createdAt:connection?.createdAt||now,updatedAt:now,expiresAt}
        if(connection) Object.assign(connection,record); else s.connectorConnections.unshift(record)
        s.audit.unshift({id:randomUUID(),action:'connector.connected',entityId:pending.connector,provider:provider.provider,at:now})
      })
      if(CONNECTOR_SUCCESS_URL){
        const success=new URL(CONNECTOR_SUCCESS_URL)
        success.searchParams.set('connector',pending.connector)
        success.searchParams.set('status','connected')
        res.writeHead(302,{Location:success.toString(),'Cache-Control':'no-store'})
        return res.end()
      }
      return send(req,res,200,{connector:pending.connector,status:'connected',expiresAt})
    }
    if (req.method === 'POST' && url.pathname === '/api/integrations/oauth/callback') {
      const body=await readBody(req)
      const stateToken=String(body.state||'')
      const code=String(body.code||'')
      if(!stateToken||!code) return send(req,res,400,{error:'state and code required'})
      const snapshot=await getState()
      const pending=(snapshot.oauthStates||[]).find(x=>x.stateHash===hashOAuthState(stateToken)&&x.workspaceId===workspaceId)
      if(!pending || Date.parse(pending.expiresAt)<=Date.now()) return send(req,res,400,{error:'invalid or expired oauth state'})
      const provider=CONNECTOR_PROVIDERS[pending.connector]
      if(!provider) return send(req,res,400,{error:'unsupported connector provider'})
      const tokenBody=new URLSearchParams({
        client_id:provider.clientId,
        client_secret:provider.clientSecret,
        redirect_uri:CONNECTOR_REDIRECT_URI,
        code,
        grant_type:'authorization_code',
        code_verifier:pending.verifier
      })
      if(Array.isArray(provider.tokenScopes)&&provider.tokenScopes.length)tokenBody.set('scope',provider.tokenScopes.join(' '))
      const tokenResponse=await fetch(provider.tokenUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:tokenBody})
      const tokenPayload=await tokenResponse.json().catch(()=>({}))
      if(!tokenResponse.ok) return send(req,res,502,{error:'oauth token exchange failed',provider:provider.provider,status:tokenResponse.status})
      if(!connectorVaultReady()) return send(req,res,503,{error:'connector credential vault is not configured'})
      const encrypted=encryptSecret(tokenPayload)
      const now=new Date().toISOString()
      const expiresAt=tokenPayload.expires_in?new Date(Date.now()+Number(tokenPayload.expires_in)*1000).toISOString():null
      await mutateState(s=>{
        s.oauthStates=(s.oauthStates||[]).filter(x=>x.stateHash!==hashOAuthState(stateToken))
        s.connectorCredentials=s.connectorCredentials||[]
        const old=s.connectorCredentials.find(x=>x.connector===pending.connector)
        const credential={id:old?.id||'cred_'+randomUUID(),connector:pending.connector,provider:provider.provider,encrypted,expiresAt,updatedAt:now,createdAt:old?.createdAt||now}
        if(old) Object.assign(old,credential); else s.connectorCredentials.unshift(credential)
        s.connectorConnections=s.connectorConnections||[]
        const connection=s.connectorConnections.find(x=>x.connector===pending.connector)
        const record={id:connection?.id||'conn_'+randomUUID(),connector:pending.connector,provider:provider.provider,status:'connected',authType:'oauth2',createdAt:connection?.createdAt||now,updatedAt:now,expiresAt}
        if(connection) Object.assign(connection,record); else s.connectorConnections.unshift(record)
        s.audit.unshift({id:randomUUID(),action:'connector.connected',entityId:pending.connector,provider:provider.provider,at:now})
      })
      return send(req,res,200,{connector:pending.connector,status:'connected',expiresAt})
    }
    if (req.method === 'POST' && url.pathname === '/api/integrations/refresh') {
      const body=await readBody(req)
      const connector=String(body.connector||'')
      if(!connector)return send(req,res,400,{error:'connector required'})
      try{
        const result=await refreshConnectorCredential(workspaceId,connector)
        return send(req,res,200,{connector,status:'connected',refreshed:result.refreshed,expiresAt:result.expiresAt})
      }catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'connector refresh failed',connector})}
    }
    if (req.method === 'POST' && url.pathname === '/api/integrations/disconnect') {
      const body=await readBody(req)
      const connector=String(body.connector||'')
      if(!connector) return send(req,res,400,{error:'connector required'})
      const now=new Date().toISOString()
      await mutateState(s=>{
        s.connectorCredentials=(s.connectorCredentials||[]).filter(x=>x.connector!==connector)
        s.connectorConnections=s.connectorConnections||[]
        const connection=s.connectorConnections.find(x=>x.connector===connector)
        if(connection){connection.status='disconnected';connection.updatedAt=now}
        s.audit.unshift({id:randomUUID(),action:'connector.disconnected',entityId:connector,at:now})
      })
      return send(req,res,200,{connector,status:'disconnected'})
    }
    if (req.method === 'POST' && url.pathname === '/api/ask-ace') {
      const body=await readBody(req)
      const question=String(body.question||'').trim()
      if(!question) return send(req,res,400,{error:'question required'})
      if(question.length>500) return send(req,res,400,{error:'question too long'})
      const q=question.toLowerCase()
      const [attribution,leadStats,leads,activationRuns,audiences,monitoring,state,routingDecisions,agentRuns,meetings,feedbackResult,followUpItems]=await Promise.all([
        attributionStats(workspaceId).catch(()=>({available:false})),
        leadOpsStats(workspaceId).catch(()=>({available:false})),
        listLeadProfiles(workspaceId,500).catch(()=>[]),
        listActivationRuns(workspaceId,200).catch(()=>[]),
        listLeadAudiences(workspaceId).catch(()=>[]),
        monitoringSnapshot(workspaceId).catch(()=>({})),
        getState().catch(()=>({})),
        listRoutingDecisions(workspaceId,500).catch(()=>[]),
        listAgentRuns(workspaceId,500).catch(()=>[]),
        listPersistedMeetings(workspaceId).catch(()=>[]),
        listPersistedFeedback(workspaceId).catch(()=>({items:[]})),
        listPersistedFollowUps(workspaceId).catch(()=>[])
      ])
      const pct=(part,total)=>total?Number(((Number(part||0)/Number(total))*100).toFixed(1)):0
      const money=value=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(Number(value||0))
      const sourceMap=new Map()
      const campaignMap=new Map()
      for(const lead of leads){
        const source=String(lead.source||'Unknown')
        const campaign=String(lead.campaign||'Unattributed')
        const high=['A','B'].includes(String(lead.grade||''))
        const score=Number(lead.score||0)
        for(const [map,key] of [[sourceMap,source],[campaignMap,campaign]]){
          const current=map.get(key)||{name:key,total:0,highQuality:0,scoreTotal:0}
          current.total+=1
          current.scoreTotal+=score
          if(high) current.highQuality+=1
          map.set(key,current)
        }
      }
      const summarize=map=>[...map.values()].map(x=>({...x,qualityRate:pct(x.highQuality,x.total),averageScore:x.total?Number((x.scoreTotal/x.total).toFixed(1)):0})).sort((a,b)=>b.highQuality-a.highQuality)
      const sources=summarize(sourceMap)
      const campaigns=summarize(campaignMap)
      const topSource=sources[0]||null
      const topCampaign=campaigns[0]||null
      const connectorConnections=(state.connectorConnections||[])
      const connectorHealth=(state.connectorHealth||[])
      const connectedConnectors=connectorConnections.filter(x=>x.status==='connected').length
      const unhealthyConnectors=connectorHealth.filter(x=>!['healthy','connected','active'].includes(String(x.status||'').toLowerCase()))
      const failedActivations=activationRuns.filter(x=>x.status==='failed').length
      const completedActivations=activationRuns.filter(x=>x.status==='succeeded').length
      const activationSuccess=pct(completedActivations,completedActivations+failedActivations)
      const suppressAudiences=audiences.filter(x=>String(x.mode||'').toLowerCase()==='suppress')
      const staleAudiences=audiences.filter(x=>x.status==='error'||x.last_sync_error)
      const evidence=(label,value,note,source)=>({label,value:String(value),note,source})
      const normalizeRef=value=>String(value||'').trim().toLowerCase()
      const knownLeadRefs=new Set(leads.flatMap(x=>[x.external_lead_id,x.name,x.customer_id].map(normalizeRef).filter(Boolean)))
      const uniqueKnown=(rows,selector)=>{
        const refs=new Set()
        for(const row of rows||[]){
          const ref=normalizeRef(selector(row))
          if(ref&&(!knownLeadRefs.size||knownLeadRefs.has(ref)))refs.add(ref)
        }
        return refs.size
      }
      const voiceRuns=(agentRuns||[]).filter(x=>String(x.agent_type||'')==='voice_qualification')
      const feedbackItems=feedbackResult?.items||[]
      const followUpCoverageCount=uniqueKnown(followUpItems,x=>x.lead_ref)
      const funnelCoverage=[
        {key:'lead',label:'Lead profiles',count:leads.length,source:'Lead operations'},
        {key:'routing',label:'Routed leads',count:uniqueKnown(routingDecisions,x=>x.lead_ref),source:'Routing decisions'},
        {key:'qualification',label:'Voice-qualified/attempted',count:uniqueKnown(voiceRuns,x=>x.entity_id||x.input?.lead),source:'Agent runs'},
        {key:'meeting',label:'Meetings scheduled',count:uniqueKnown(meetings,x=>x.lead_ref),source:'Meetings'},
        {key:'follow_up',label:'Follow-ups created',count:followUpCoverageCount,source:'Follow-up operations'},
        {key:'feedback',label:'Feedback captured',count:uniqueKnown(feedbackItems,x=>x.lead_ref),source:'Feedback'}
      ].map((x,index)=>({...x,coverage:index===0?100:pct(x.count,Math.max(1,leads.length))}))
      const weakestHandoff=funnelCoverage.slice(1).sort((a,b)=>a.coverage-b.coverage)[0]||null
      const candidateLead=leads
        .map(lead=>({
          lead,
          refs:[lead.id,lead.external_lead_id,lead.customer_id,lead.name].filter(Boolean).map(value=>String(value).trim()).filter(value=>value.length>=3)
        }))
        .find(entry=>entry.refs.some(ref=>q.includes(ref.toLowerCase())))?.lead||null
      const sameLeadForAsk=(lead,ref)=>{
        const value=normalizeRef(ref)
        if(!value)return false
        return [lead.id,lead.external_lead_id,lead.customer_id,lead.name].filter(Boolean).some(x=>normalizeRef(x)===value)
      }
      const specificJourney=candidateLead?(()=>{
        const timeline=[]
        const push=(type,title,detail,at,source,meta={})=>{if(at)timeline.push({type,title,detail,at,source,...meta})}
        push('profile','Customer profile created','Canonical lead/customer profile entered the workspace.',candidateLead.created_at,'CRM / identity')
        for(const event of trackedEvents.filter(event=>{
          const refs=[event.customerId,event.leadId,event.externalLeadId,event.visitorId,event.deviceId,event.device_id]
          return refs.some(ref=>sameLeadForAsk(candidateLead,ref))||(candidateLead.device_id&&refs.some(ref=>String(ref||'')===String(candidateLead.device_id)))
        })){
          push('event',String(event.event||event.eventType||event.name||'Tracked event').replaceAll('_',' '),'First-party activity captured.',event.occurredAt||event.receivedAt||event.timestamp,event.source||event.channel||'Tracking',{event:event.event||event.eventType||event.name||null,value:event.value||null})
        }
        for(const item of routingDecisions.filter(x=>sameLeadForAsk(candidateLead,x.lead_ref)))push('routing',item.rule_name||'Lead routed',item.destination||item.reason||'Routing decision',item.created_at,'Routing',{destination:item.destination||null})
        for(const item of followUpItems.filter(x=>sameLeadForAsk(candidateLead,x.lead_ref))){
          push('follow_up',item.reason||'Follow-up created',(item.channel||'channel')+' · '+(item.status||'open'),item.created_at,'Follow-up',{status:item.status||null,dueAt:item.due_at||null})
          if(item.completed_at)push('follow_up_completed','Follow-up completed',item.reason||'',item.completed_at,'Follow-up',{status:'completed'})
        }
        for(const item of meetings.filter(x=>sameLeadForAsk(candidateLead,x.lead_ref))){
          push('meeting','Meeting scheduled',(item.owner||'Owner')+' · '+(item.status||'confirmed'),item.starts_at||item.created_at,'Meetings',{startsAt:item.starts_at,status:item.status||null,meetingLink:item.meeting_link||null})
          if(item.last_reminder_at)push('reminder','Meeting reminder sent',String(item.reminders_sent||1)+' reminder(s)',item.last_reminder_at,'Meetings')
        }
        for(const item of feedbackItems.filter(x=>sameLeadForAsk(candidateLead,x.lead_ref)))push('feedback','Feedback recorded',(item.theme||'Uncategorized')+(item.score!=null?' · '+item.score+'/5':''),item.created_at,'Feedback',{score:item.score,theme:item.theme||null})
        for(const item of agentRuns.filter(x=>sameLeadForAsk(candidateLead,x.entity_id)||sameLeadForAsk(candidateLead,x.input?.lead)||sameLeadForAsk(candidateLead,x.input?.leadRef)))push('agent',String(item.agent_type||item.action_type||'Agent run').replaceAll('_',' '),String(item.status||'queued'),item.created_at,'Agents',{status:item.status||null})
        if(candidateLead.call_summary)push('call','Call context',String(candidateLead.call_summary),candidateLead.updated_at,'Calls')
        if(candidateLead.whatsapp_summary)push('whatsapp','WhatsApp context',String(candidateLead.whatsapp_summary),candidateLead.updated_at,'WhatsApp')
        if(candidateLead.crm_stage)push('stage','Current CRM stage',String(candidateLead.crm_stage),candidateLead.updated_at,'CRM',{stage:candidateLead.crm_stage})
        timeline.sort((a,b)=>Date.parse(a.at||0)-Date.parse(b.at||0))
        return {
          leadId:candidateLead.id,
          externalLeadId:candidateLead.external_lead_id||null,
          name:candidateLead.name||candidateLead.external_lead_id||candidateLead.id,
          source:candidateLead.source||'First-party',
          campaign:candidateLead.campaign||null,
          stage:candidateLead.crm_stage||candidateLead.grade||'Lead',
          grade:candidateLead.grade||null,
          score:Number(candidateLead.score||0),
          touchpoints:timeline.length,
          timeline
        }
      })():null
      let intent='workspace_summary'
      let answer=''
      let insights=[]
      let confidence='medium'
      let followUps=[]
      let journeyTimeline=[]
      if(specificJourney&&(q.includes('journey')||q.includes('timeline')||q.includes('touchpoint')||q.includes('path'))){
        intent='customer_journey'
        journeyTimeline=specificJourney.timeline
        const last=specificJourney.timeline[specificJourney.timeline.length-1]||null
        answer=specificJourney.name+' has '+specificJourney.touchpoints+' persisted touchpoints from '+specificJourney.source+(specificJourney.campaign?' / '+specificJourney.campaign:'')+'. Current stage: '+specificJourney.stage+'.'+(last?' Latest observed activity: '+last.title+' via '+last.source+'.':' No linked operational activity is available beyond the profile.')
        insights=[
          evidence('Customer',specificJourney.name,specificJourney.externalLeadId||specificJourney.leadId,'Lead profile'),
          evidence('Source / campaign',specificJourney.source+(specificJourney.campaign?' · '+specificJourney.campaign:''),specificJourney.touchpoints+' persisted touchpoints','Stitched journey'),
          evidence('Current stage',specificJourney.stage,'Grade '+String(specificJourney.grade||'—')+' · score '+specificJourney.score,'Lead operations')
        ]
        confidence='high'
        followUps=['Where did '+specificJourney.name+' last engage?','What follow-ups exist for '+specificJourney.name+'?','Show attribution health for this workspace']
      }else if(q.includes('funnel')||q.includes('drop')||q.includes('handoff')||q.includes('step-by-step')||q.includes('step by step')||q.includes('stage coverage')){
        intent='funnel_monitoring'
        const total=leads.length
        answer=total
          ? 'The workspace has '+total+' persisted lead profiles. '+funnelCoverage.slice(1).map(x=>x.label+': '+x.count+' ('+x.coverage+'% coverage)').join(' · ')+'.'+(weakestHandoff?' The thinnest observed handoff is '+weakestHandoff.label+' at '+weakestHandoff.coverage+'% coverage.':'')
          : 'There are no persisted lead profiles yet, so step-by-step funnel coverage cannot be measured reliably.'
        insights=funnelCoverage.map(x=>evidence(x.label,x.count,(x.coverage||0)+'% of persisted lead profiles',x.source))
        confidence=total?'high':'low'
        followUps=['Which leads have not reached routing yet?','How many leads reached meetings?','Where is attribution breaking after the handoff?']
      }else if(q.includes('campaign')||q.includes('revenue')||q.includes('roas')||q.includes('channel')){
        intent='campaign_performance'
        const matchedValue=Number(attribution.matchedValue||0)
        answer=topCampaign
          ? topCampaign.name+' currently has the strongest observed lead-quality signal: '+topCampaign.highQuality+' A/B-grade leads from '+topCampaign.total+' profiled leads.'+(matchedValue>0?' Matched assisted-event value is '+money(matchedValue)+'.':'')
          : matchedValue>0
            ? 'The workspace has '+money(matchedValue)+' in matched assisted-event value, but there is not enough campaign-level lead data to name a strongest campaign confidently.'
            : 'There is not enough connected campaign or matched-revenue data to answer this reliably yet.'
        insights=[
          evidence('Top campaign',topCampaign?.name||'Not enough data',topCampaign?topCampaign.qualityRate+'% A/B lead rate':'No campaign profile data','Lead profiles'),
          evidence('Matched value',matchedValue?money(matchedValue):'No matched value',Number(attribution.matchedEvents||0)+' matched assisted events','Attribution store'),
          evidence('Attribution match rate',attribution.available?Number(attribution.matchRate||0)+'%':'Unavailable',Number(attribution.unmatchedEvents||0)+' unmatched events','Attribution store')
        ]
        confidence=topCampaign||matchedValue?'high':'low'
        followUps=['Which campaign has the weakest lead quality?','How much revenue is currently unmatched?','Which source should I scale based on lead quality?']
      }else if(q.includes('qualified')||q.includes('lead quality')||q.includes('lead')||q.includes('junk')){
        intent='lead_quality'
        const high=Number(leadStats.abQuality||0),total=Number(leadStats.total||0),rate=pct(high,total)
        answer=total
          ? high+' of '+total+' active lead profiles are A/B grade ('+rate+'%). Average score is '+Number(leadStats.averageScore||0)+'.'+(topSource?' '+topSource.name+' currently contributes the most high-quality profiles.':'')
          : 'No persisted lead profiles are available yet, so lead-quality conclusions would be speculative.'
        insights=[
          evidence('A/B-grade leads',high,rate+'% of active profiles','Lead operations'),
          evidence('Average lead score',Number(leadStats.averageScore||0),'A grade: '+Number(leadStats.aGrade||0)+' · D grade: '+Number(leadStats.dGrade||0),'Lead operations'),
          evidence('Strongest source',topSource?.name||'Not enough data',topSource?topSource.highQuality+' high-quality leads · '+topSource.qualityRate+'% quality rate':'No source profile data','Lead profiles')
        ]
        confidence=total?'high':'low'
        followUps=['Which source is sending the most low-quality leads?','Which campaign has the highest A/B-grade rate?','What should we suppress to reduce wasted spend?']
      }else if(q.includes('suppress')||q.includes('audience')||q.includes('retarget')){
        intent='audience_suppression'
        const lowQuality=Number(leadStats.dGrade||0)+Number(leadStats.cGrade||0)
        const first=suppressAudiences[0]
        answer=first
          ? first.name+' is already configured as a suppression audience with '+Number(first.matched_size||0)+' matched identities.'+(lowQuality>0?' There are also '+lowQuality+' C/D-grade leads that may be candidates for tighter exclusion rules, subject to your policy.':'')
          : lowQuality>0
            ? 'There are '+lowQuality+' C/D-grade leads in the current profile set, but no persisted suppression audience is available to confirm they are excluded from paid media.'
            : 'There is not enough audience or lead-grade data to recommend a suppression action confidently.'
        insights=[
          evidence('Suppression audiences',suppressAudiences.length,first?first.name:'None persisted','Audience store'),
          evidence('C/D-grade leads',lowQuality,'Potential low-quality pool before policy checks','Lead operations'),
          evidence('Audience sync issues',staleAudiences.length,staleAudiences.length?'Review provider sync state':'No audience sync errors observed','Audience store')
        ]
        confidence=first||lowQuality?'medium':'low'
        followUps=['Which audience has a sync error?','How many low-quality users are still targetable?','Which high-intent audience is ready to activate?']
      }else if(q.includes('integration')||q.includes('connector')||q.includes('sync')||q.includes('signal health')||q.includes('delivery')){
        intent='signal_health'
        answer=connectedConnectors+' of '+connectorConnections.length+' configured connectors are connected. '+(unhealthyConnectors.length?unhealthyConnectors.length+' connector-health records need review.':'No connector-health records are currently flagged.')+(failedActivations?' '+failedActivations+' recent activation runs failed.':'')
        insights=[
          evidence('Connected connectors',connectedConnectors,connectorConnections.length+' configured connection records','Workspace state'),
          evidence('Connector health issues',unhealthyConnectors.length,unhealthyConnectors.length?'Review connector-health details':'No connector-health issues observed','Connector state'),
          evidence('Activation success rate',activationSuccess+'%',failedActivations+' failed · '+activationRuns.filter(x=>['queued','processing','retrying'].includes(String(x.status))).length+' queued/retrying','Activation runs'),
          evidence('API health',monitoring?.api?.errorRate!==undefined?Number(monitoring.api.errorRate)+'% error rate':'Available in monitoring','Latest operational snapshot','Observability')
        ]
        confidence=connectorConnections.length||activationRuns.length?'high':'medium'
        followUps=['Which connector needs attention first?','How many activation runs are failing?','Are any audiences failing to sync?']
      }else if(q.includes('attribution')||q.includes('match')||q.includes('unmatched')||q.includes('journey')){
        intent='attribution_health'
        answer=attribution.available
          ? 'Attribution currently matches '+Number(attribution.matchedEvents||0)+' of '+Number(attribution.assistedEvents||0)+' assisted events ('+Number(attribution.matchRate||0)+'%). '+Number(attribution.unmatchedEvents||0)+' remain unmatched, with '+money(attribution.matchedValue||0)+' in matched value.'
          : 'The attribution store is not available, so I cannot give a grounded journey-match answer.'
        insights=[
          evidence('Match rate',attribution.available?Number(attribution.matchRate||0)+'%':'Unavailable',Number(attribution.matchedEvents||0)+' matched events','Attribution store'),
          evidence('Unmatched events',Number(attribution.unmatchedEvents||0),'Needs identity or source reconciliation','Attribution store'),
          evidence('Matched value',money(attribution.matchedValue||0),Number(attribution.activeClickSessions||0)+' active click sessions','Attribution store')
        ]
        confidence=attribution.available?'high':'low'
        followUps=['Why are events unmatched?','Which identity method is matching most events?','How much matched value comes from assisted conversions?']
      }else{
        const readiness=[attribution.available,leadStats.available,connectedConnectors>0,audiences.length>0,activationRuns.length>0].filter(Boolean).length
        answer='I can currently ground answers across '+readiness+'/5 operational data areas: attribution, lead profiles, connectors, audiences, and activation runs. Ask about lead quality, campaigns/revenue, attribution, audience suppression, or signal health for a more specific analysis.'
        insights=[
          evidence('Lead profiles',Number(leadStats.total||0),'Average score '+Number(leadStats.averageScore||0),'Lead operations'),
          evidence('Attribution match rate',attribution.available?Number(attribution.matchRate||0)+'%':'Unavailable',Number(attribution.unmatchedEvents||0)+' unmatched','Attribution store'),
          evidence('Connected connectors',connectedConnectors,unhealthyConnectors.length+' health issue(s)','Workspace state')
        ]
        confidence=readiness>=3?'high':'medium'
        followUps=['Which campaign is producing the best-quality leads?','Where is attribution breaking?','Which audience should we suppress?']
      }
      return send(req,res,200,{answer,insights,intent,confidence,followUps,journey:journeyTimeline.length?specificJourney:null,journeyTimeline,generatedAt:new Date().toISOString(),grounded:true})
    }
    if (req.method === 'GET' && url.pathname === '/api/events') {
      const [items,runs,stats]=await Promise.all([listEventRules(workspaceId),listEventRuleRuns(workspaceId,50),eventRuleStats(workspaceId)])
      return send(req,res,200,{items,runs,stats,templates:[
        {id:'pricing_page_lead',category:'Lead quality',name:'Pricing-page Lead',description:'Identify form submissions that showed pricing-page intent before converting.',useCase:'Prioritize high-commercial-intent leads and return a stronger optimization signal.',sourceEvent:'form_submitted',condition:{field:'properties.pricingPageViews',operator:'gte',value:1},outputEvent:'pricing_page_lead',destinations:['Google Ads','Meta Ads'],valueMode:'copy',currency:'INR'},
        {id:'new_customer_purchase',category:'Commerce',name:'New Customer Purchase',description:'Separate first-time buyers from repeat purchasers.',useCase:'Measure and optimize true new-customer acquisition and CAC.',sourceEvent:'purchase',condition:{field:'properties.customerType',operator:'equals',value:'new'},outputEvent:'new_customer_purchase',destinations:['Google Ads','Meta Ads'],valueMode:'copy',currency:'INR'},
        {id:'repeat_purchase',category:'Commerce',name:'Repeat Purchase',description:'Identify purchases from customers with prior completed orders.',useCase:'Build retention and loyalty cohorts and separate repeat revenue from acquisition revenue.',sourceEvent:'purchase',condition:{field:'properties.purchaseCount',operator:'gte',value:2},outputEvent:'repeat_purchase',destinations:['Google Ads','Meta Ads'],valueMode:'copy',currency:'INR'},
        {id:'abandoned_checkout',category:'Commerce',name:'Abandoned Checkout',description:'Accept a checkout-abandoned event emitted by your commerce webhook/backend after the configured inactivity window.',useCase:'Build recovery audiences and measure checkout leakage without pretending a stateless browser rule can detect elapsed time.',sourceEvent:'checkout_abandoned',condition:{field:'properties.reason',operator:'exists',value:null},outputEvent:'abandoned_checkout',destinations:['Google Ads','Meta Ads'],valueMode:'copy',currency:'INR'},
        {id:'high_value_purchase',category:'Commerce',name:'High-value Purchase',description:'Create a conversion signal only when order value crosses the configured threshold.',useCase:'Build high-value cohorts and teach bidding systems which purchases matter most.',sourceEvent:'purchase',condition:{field:'value',operator:'gte',value:4000},outputEvent:'high_value_purchase',destinations:['Google Ads','Meta Ads'],valueMode:'copy',currency:'INR'},
        {id:'category_interest_event',category:'Personalization',name:'Category Interest',description:'Create a category-specific intent signal from viewed or purchased product categories.',useCase:'Build category audiences and feed personalization workflows from first-party behavior.',sourceEvent:'product_interaction',condition:{field:'properties.productCategory',operator:'equals',value:'skin'},outputEvent:'category_interest',destinations:['Google Ads','Meta Ads'],valueMode:'copy',currency:'INR'},
        {id:'prepaid_order',category:'Commerce',name:'Prepaid Order',description:'Separate prepaid orders from cash-on-delivery or other payment modes.',useCase:'Optimize acquisition toward lower-risk, higher-confidence orders.',sourceEvent:'purchase',condition:{field:'properties.paymentType',operator:'equals',value:'prepaid'},outputEvent:'prepaid_order',destinations:['Google Ads','Meta Ads'],valueMode:'copy',currency:'INR'},
        {id:'fulfilled_order',category:'Commerce',name:'Fulfilled Order',description:'Promote only orders that progressed to fulfillment.',useCase:'Return post-purchase quality instead of optimizing only on checkout completion.',sourceEvent:'order_status',condition:{field:'properties.status',operator:'equals',value:'fulfilled'},outputEvent:'fulfilled_order',destinations:['Google Ads','Meta Ads'],valueMode:'copy',currency:'INR'},
        {id:'returned_order',category:'Commerce',name:'Returned Order',description:'Capture returned or rejected orders as a downstream quality signal.',useCase:'Exclude poor-fit cohorts from lookalikes and analyze return-driven waste.',sourceEvent:'order_status',condition:{field:'properties.status',operator:'equals',value:'returned'},outputEvent:'returned_order',destinations:[],valueMode:'copy',currency:'INR'},
        {id:'first_touch_attribution',category:'Attribution',name:'First-touch Attribution',description:'Capture the first known marketing touch for a stitched customer journey.',useCase:'Preserve acquisition-source evidence for first-touch reporting and journey analysis.',sourceEvent:'attribution_touch',condition:{field:'properties.touchType',operator:'equals',value:'first'},outputEvent:'first_touch_attribution',destinations:[],valueMode:'copy',currency:'INR'},
        {id:'last_touch_attribution',category:'Attribution',name:'Last-touch Attribution',description:'Capture the final marketing touch before a qualified or revenue outcome.',useCase:'Compare closing-channel influence against first-touch and multi-touch views.',sourceEvent:'attribution_touch',condition:{field:'properties.touchType',operator:'equals',value:'last'},outputEvent:'last_touch_attribution',destinations:[],valueMode:'copy',currency:'INR'}
      ]})
    }
    if (req.method === 'POST' && url.pathname === '/api/events/rules') {
      const body=await readBody(req)
      try{
        const item=await createEventRule(workspaceId,body,req.user?.email||req.user?.userId||null)
        return send(req,res,201,{item})
      }catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'invalid event rule'})}
    }
    if (req.method === 'POST' && url.pathname === '/api/events/rules/toggle') {
      const body=await readBody(req)
      if(!body.id||typeof body.enabled!=='boolean') return send(req,res,400,{error:'id and enabled boolean required'})
      const item=await setEventRuleEnabled(workspaceId,String(body.id),body.enabled)
      return item?send(req,res,200,{item}):send(req,res,404,{error:'event rule not found'})
    }
    if (req.method === 'GET' && url.pathname === '/api/adjustments') {
      const state=await getState()
      return send(req,res,200,{items:(state.adjustments||[]).slice(0,500)})
    }
    if (req.method === 'POST' && url.pathname === '/api/adjustments') {
      const body=await readBody(req)
      const event=String(body.event||'').trim()
      const source=String(body.source||'').trim()
      const destination=String(body.destination||'').trim()
      const reason=String(body.reason||'').trim()
      if(!event||!source||!destination||!reason) return send(req,res,400,{error:'event, source, destination and reason are required'})
      const parseValue=value=>{
        if(value==null||value==='')return null
        const numeric=Number(value)
        return Number.isFinite(numeric)?numeric:String(value).slice(0,200)
      }
      const now=new Date().toISOString()
      const item={
        id:'adj_'+randomUUID(),
        event:event.slice(0,160),
        source:source.slice(0,160),
        destination:destination.slice(0,160),
        fromValue:parseValue(body.fromValue),
        toValue:parseValue(body.toValue),
        currency:String(body.currency||'INR').slice(0,12),
        reason:reason.slice(0,500),
        status:'pending',
        createdAt:now,
        createdBy:req.user?.email||req.user?.userId||null
      }
      await mutateState(s=>{
        s.adjustments=s.adjustments||[]
        s.adjustments.unshift(item)
        s.adjustments=s.adjustments.slice(0,1000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'adjustment.created',entityId:item.id,event:item.event,destination:item.destination,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/adjustments/preview') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const state=await getState()
      const item=(state.adjustments||[]).find(x=>x.id===body.id)
      if(!item) return send(req,res,404,{error:'adjustment not found'})
      const payload={
        eventId:item.id,
        event:item.event,
        destination:item.destination,
        adjustment:{from:item.fromValue??null,to:item.toValue??null,currency:item.currency||null,reason:item.reason||null},
        idempotencyKey:createHash('sha256').update(workspaceId+':'+item.id).digest('hex')
      }
      return send(req,res,200,{item,payload,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/adjustments/apply') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const now=new Date().toISOString()
      let updated=null
      await mutateState(s=>{
        const item=(s.adjustments||[]).find(x=>x.id===body.id)
        if(item){item.status='applied';item.appliedAt=now;item.updatedAt=now;updated={...item}}
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'adjustment.applied',entityId:String(body.id),at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return updated?send(req,res,200,{...updated,auditId:randomUUID()}):send(req,res,404,{error:'adjustment not found'})
    }
    if (req.method === 'GET' && url.pathname === '/api/fingerprinting') {
      const [attr,profiles,state]=await Promise.all([attributionStats(workspaceId),listLeadProfiles(workspaceId,500),getState()])
      const matched=Number(attr?.matchedEvents||0),unmatched=Number(attr?.unmatchedEvents||0),total=matched+unmatched
      const deviceProfiles=profiles.filter(x=>x.device_id).length
      const wa=(state.whatsappEvents||[]).filter(x=>x.kind==='message').length
      const calls=(state.callEvents||[]).length
      const scenarios=[
        {name:'third_party_checkout',evidence:Number(attr?.activeClickSessions||0),matchRate:total?Number((matched/total*100).toFixed(1)):null},
        {name:'whatsapp_handoff',evidence:wa,matchRate:wa&&total?Number((matched/total*100).toFixed(1)):null},
        {name:'call_handoff',evidence:calls,matchRate:calls&&total?Number((matched/total*100).toFixed(1)):null},
        {name:'returning_device',evidence:deviceProfiles,matchRate:deviceProfiles&&profiles.length?Number((deviceProfiles/profiles.length*100).toFixed(1)):null}
      ]
      return send(req,res,200,{available:true,continuityRate:total?Number((matched/total*100).toFixed(1)):null,ambiguousRate:total?Number((unmatched/total*100).toFixed(1)):null,scenarios,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/fingerprinting/test') {
      const body=await readBody(req)
      if(!body.scenario) return send(req,res,400,{error:'scenario required'})
      const [attr,profiles,state]=await Promise.all([attributionStats(workspaceId),listLeadProfiles(workspaceId,500),getState()])
      const key=String(body.scenario).toLowerCase()
      const evidence=key.includes('whatsapp')?(state.whatsappEvents||[]).length:key.includes('call')?(state.callEvents||[]).length:key.includes('device')?profiles.filter(x=>x.device_id).length:Number(attr?.activeClickSessions||0)
      const result={id:'fptest_'+randomUUID(),scenario:String(body.scenario),status:evidence>0?'evidence_available':'no_evidence',deterministicMatch:Number(attr?.matchedEvents||0)>0,evidenceCount:evidence,testedAt:new Date().toISOString()}
      await mutateState(s=>{s.fingerprintTests=s.fingerprintTests||[];s.fingerprintTests.unshift(result);s.fingerprintTests=s.fingerprintTests.slice(0,200);s.audit=s.audit||[];s.audit.unshift({id:randomUUID(),action:'fingerprinting.test',entityId:result.id,scenario:result.scenario,status:result.status,at:result.testedAt});s.audit=s.audit.slice(0,1000)})
      return send(req,res,200,result)
    }
    if (req.method === 'GET' && url.pathname === '/api/fingerprinting/matches') {
      const live=await attributionStats(workspaceId)
      return send(req,res,200,{items:(live?.recent||[]).filter(x=>x.status==='matched').slice(0,100),methods:live?.methods||[]})
    }
    if (req.method === 'GET' && url.pathname === '/api/sites') {
      const state=await getState()
      const settings=state.settings||{}
      const domainMap=new Map()
      const ensure=(domain,environment='production')=>{
        if(!domain)return null
        const clean=String(domain).replace(/^https?:\/\//,'').split('/')[0]
        if(!clean)return null
        const item=domainMap.get(clean)||{domain:clean,environment,events:0,lastEventAt:null}
        domainMap.set(clean,item)
        return item
      }
      ensure(settings.primaryDomain||state.launchpad?.primaryDomain||'')
      for(const event of trackedEvents){
        let domain=event.domain||event.host||''
        if(!domain&&event.url){try{domain=new URL(String(event.url)).host}catch{}}
        const item=ensure(domain,event.environment||'production')
        if(item){item.events++;const time=event.receivedAt||event.occurredAt||event.timestamp;if(time&&(!item.lastEventAt||Date.parse(time)>Date.parse(item.lastEventAt)))item.lastEventAt=time}
      }
      for(const cfg of state.sites||[]){const item=ensure(cfg.domain,cfg.environment||'production');if(item)Object.assign(item,cfg)}
      const totalTracked=Math.max(1,trackedEvents.length)
      const items=[...domainMap.values()].map(x=>({
        domain:x.domain,
        environment:x.environment||'production',
        pixel:x.events>0?'active':'needs_review',
        server:'connected',
        coverage:Number((x.events/totalTracked*100).toFixed(1)),
        events:x.events,
        lastEventAt:x.lastEventAt,
        consent:'workspace policy'
      }))
      return send(req,res,200,{items,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/sites') {
      const body=await readBody(req)
      const raw=String(body.domain||'').trim().toLowerCase()
      const domain=raw.replace(/^https?:\/\//,'').split('/')[0]
      if(!domain||!domain.includes('.')) return send(req,res,400,{error:'valid domain required'})
      const environment=['production','staging','development'].includes(String(body.environment||'').toLowerCase())?String(body.environment).toLowerCase():'production'
      const now=new Date().toISOString()
      let item=null
      await mutateState(s=>{
        s.sites=s.sites||[]
        const existing=s.sites.find(x=>String(x.domain).toLowerCase()===domain)
        if(existing){existing.environment=environment;existing.updatedAt=now;item={...existing};return}
        item={id:'site_'+randomUUID(),domain,environment,createdAt:now}
        s.sites.unshift(item)
        s.sites=s.sites.slice(0,200)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'site.created',entityId:item.id,domain,environment,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,item?.createdAt===now?201:200,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/sites/test') {
      const body=await readBody(req)
      if(!body.domain) return send(req,res,400,{error:'domain required'})
      const domain=String(body.domain)
      const matching=trackedEvents.filter(x=>{
        const raw=String(x.domain||x.host||x.url||'')
        return raw.includes(domain)
      })
      const state=await getState()
      const consentReady=Boolean((state.consentPreferences||state.settings?.consentMode||state.settings?.primaryDomain))
      const result={id:'sitetest_'+randomUUID(),domain,pixel:matching.length>0,server:true,consent:consentReady,crossDomain:matching.some(x=>x.customerId||x.visitorId||x.deviceId||x.device_id),eventsObserved:matching.length,testedAt:new Date().toISOString()}
      await mutateState(s=>{s.siteTests=s.siteTests||[];s.siteTests.unshift(result);s.siteTests=s.siteTests.slice(0,200)})
      return send(req,res,200,result)
    }
    if (req.method === 'GET' && url.pathname === '/api/sites/debug') {
      const domain=String(url.searchParams.get('domain')||'')
      const state=await getState()
      const source=[...trackedEvents].slice(-200).reverse()
      const persisted=(state.recentEvents||[]).slice(0,200)
      const items=[...source,...persisted].filter((x,index,arr)=>arr.findIndex(y=>String(y.id||y.eventId||'')===String(x.id||x.eventId||''))===index)
      return send(req,res,200,{domain,items:items.filter(x=>!domain||String(x.domain||x.host||x.url||'').includes(domain)).slice(0,100)})
    }
    if (req.method === 'GET' && url.pathname === '/api/match-quality') {
      const state=await getState()
      const events=(state.recentEvents||[]).slice(0,5000)
      const signalWeight={customerId:3,emailSha256:3,phoneSha256:3,deviceId:2,visitorId:2,gclid:2,gbraid:2,wbraid:2,fbclid:2,msclkid:2,oppref:2,obref:1,ipAddress:1,userAgent:1}
      const normalizedEvent=event=>({
        customerId:event.customerId||null,
        emailSha256:event.emailSha256||event.email_sha256||null,
        phoneSha256:event.phoneSha256||event.phone_sha256||null,
        deviceId:event.deviceId||event.device_id||null,
        visitorId:event.visitorId||null,
        gclid:event.gclid||null,gbraid:event.gbraid||null,wbraid:event.wbraid||null,
        fbclid:event.fbclid||null,msclkid:event.msclkid||null,
        oppref:event.oppref||event.openaiClickRef||null,obref:event.obref||event.openaiBrowserRef||null,
        ipAddress:event.ipAddress||null,userAgent:event.userAgent||null
      })
      const scoreOne=event=>{
        const ids=normalizedEvent(event)
        const present=Object.entries(ids).filter(([,value])=>Boolean(value)).map(([key])=>key)
        const points=present.reduce((n,key)=>n+(signalWeight[key]||0),0)
        const max=12
        const score=Math.min(100,Math.round(points/max*100))
        const missing=Object.keys(signalWeight).filter(key=>!ids[key])
        return {score,present,missing}
      }
      const rows=new Map()
      let totalScore=0, strong=0, weak=0
      const signalCounts=Object.fromEntries(Object.keys(signalWeight).map(k=>[k,0]))
      for(const event of events){
        const quality=scoreOne(event)
        totalScore+=quality.score
        if(quality.score>=70)strong++
        if(quality.score<40)weak++
        for(const key of quality.present)signalCounts[key]=(signalCounts[key]||0)+1
        const key=String(event.event||event.eventType||event.name||'unknown')
        const row=rows.get(key)||{event:key,count:0,totalScore:0,sourceCounts:{}}
        row.count++
        row.totalScore+=quality.score
        const source=String(event.source||event.channel||event.utm_source||'Unknown')
        row.sourceCounts[source]=(row.sourceCounts[source]||0)+1
        rows.set(key,row)
      }
      const items=[...rows.values()].map(row=>({
        event:row.event,
        count:row.count,
        averageScore:row.count?Math.round(row.totalScore/row.count):0,
        topSource:Object.entries(row.sourceCounts).sort((a,b)=>b[1]-a[1])[0]?.[0]||'Unknown'
      })).sort((a,b)=>b.count-a.count)
      const coverage=Object.entries(signalCounts).map(([signal,count])=>({signal,count,rate:events.length?Number((count/events.length*100).toFixed(1)):0})).sort((a,b)=>b.rate-a.rate)
      const recommendations=[]
      const rate=s=>coverage.find(x=>x.signal===s)?.rate||0
      if(rate('emailSha256')<50)recommendations.push({key:'email_hash',title:'Increase hashed email coverage',detail:'Capture consented email earlier and hash it server-side before activation.',tab:'Data Hub'})
      if(rate('phoneSha256')<40)recommendations.push({key:'phone_hash',title:'Increase hashed phone coverage',detail:'Normalize and hash phone values server-side where users provide them.',tab:'Data Hub'})
      if(rate('customerId')<50)recommendations.push({key:'customer_id',title:'Persist a stable first-party customer ID',detail:'Use one durable customer/lead identifier across web, CRM and offline events.',tab:'Identity'})
      if(rate('gclid')+rate('gbraid')+rate('wbraid')<25)recommendations.push({key:'google_click_ids',title:'Improve Google click-ID capture',detail:'Preserve GCLID/GBRAID/WBRAID from landing session through conversion.',tab:'Sites'})
      if(rate('fbclid')<20)recommendations.push({key:'meta_click_id',title:'Improve Meta click-ID capture',detail:'Preserve Meta click/browser identifiers alongside first-party identity.',tab:'Sites'})
      if(rate('oppref')<10)recommendations.push({key:'oppref',title:'Preserve ChatGPT Ads oppref',detail:'Capture the OpenAI click reference from landing URLs and carry it into conversion events.',tab:'ChatGPT Ads'})
      if(rate('deviceId')<30)recommendations.push({key:'device_id',title:'Strengthen device identity',detail:'Persist deterministic first-party device IDs where available.',tab:'Fingerprinting'})
      const averageScore=events.length?Math.round(totalScore/events.length):0
      return send(req,res,200,{
        available:events.length>0,
        averageScore,
        totalEvents:events.length,
        strongEvents:strong,
        weakEvents:weak,
        strongRate:events.length?Number((strong/events.length*100).toFixed(1)):0,
        weakRate:events.length?Number((weak/events.length*100).toFixed(1)):0,
        coverage,
        items,
        recommendations,
        note:'AceMarketing internal identity-coverage score; not a provider-reported Meta, Google, or OpenAI match-quality score.',
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/fraud') {
      const [profiles,state]=await Promise.all([listLeadProfiles(workspaceId,500),getState()])
      const countDriver=key=>profiles.filter(x=>(x.score_drivers||[]).some(d=>d.key===key)).length
      const duplicates=countDriver('duplicate')
      const invalid=countDriver('invalid_contact')
      const fraudHigh=profiles.filter(x=>(x.score_drivers||[]).some(d=>d.key==='fraud'&&Number(d.points)<=-30)).length
      const lowQuality=profiles.filter(x=>x.grade==='D').length
      const recent=trackedEvents.filter(x=>Date.now()-Date.parse(x.receivedAt||x.occurredAt||0)<5*60*1000)
      const identityCounts=new Map()
      for(const event of recent){const id=event.customerId||event.visitorId||event.deviceId||event.device_id||event.emailSha256||event.phoneSha256;if(id)identityCounts.set(id,(identityCounts.get(id)||0)+1)}
      const burst=[...identityCounts.values()].filter(n=>n>=20).length
      const items=[
        {key:'duplicate_lead_burst',name:'Duplicate lead burst',severity:duplicates?'high':'info',affected:duplicates,source:'Lead profiles',description:'Profiles penalized by duplicate-identity scoring evidence.'},
        {key:'bot_form_activity',name:'High-velocity identity activity',severity:burst?'high':'info',affected:burst,source:'First-party events',description:'Identities generating unusually high event volume in a five-minute window.'},
        {key:'invalid_phone_pattern',name:'Invalid contact evidence',severity:invalid?'medium':'info',affected:invalid,source:'Lead profiles',description:'Profiles penalized by contact-validation evidence.'},
        {key:'high_fraud_score',name:'High fraud-risk profiles',severity:fraudHigh?'high':'info',affected:fraudHigh,source:'Lead scoring',description:'Profiles with the strongest fraud-risk penalty.'},
        {key:'low_quality_pool',name:'Low-quality lead pool',severity:lowQuality?'low':'info',affected:lowQuality,source:'Lead grades',description:'D-grade leads available for review or suppression policy.'}
      ].filter(x=>x.affected>0)
      return send(req,res,200,{items,blocked:state.fraudBlocks||[],reviews:(state.reviewQueue||[]).filter(x=>x.kind==='fraud'),generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/fraud/block') {
      const body=await readBody(req)
      if(!body.pattern) return send(req,res,400,{error:'pattern required'})
      const item={pattern:String(body.pattern),status:'blocked_from_optimization',ruleId:'fraud_'+randomUUID(),appliedAt:new Date().toISOString(),appliedBy:req.user?.email||req.user?.userId||null}
      await mutateState(s=>{s.fraudBlocks=s.fraudBlocks||[];if(!s.fraudBlocks.some(x=>x.pattern===item.pattern))s.fraudBlocks.unshift(item);s.fraudBlocks=s.fraudBlocks.slice(0,500);s.audit=s.audit||[];s.audit.unshift({id:randomUUID(),action:'fraud.blocked',entityId:item.ruleId,pattern:item.pattern,at:item.appliedAt});s.audit=s.audit.slice(0,1000)})
      return send(req,res,200,item)
    }
    if (req.method === 'POST' && url.pathname === '/api/fraud/review') {
      const body=await readBody(req)
      if(!body.pattern) return send(req,res,400,{error:'pattern required'})
      const now=new Date().toISOString()
      const item={id:'review_'+randomUUID(),kind:'fraud',pattern:String(body.pattern),status:'queued',createdAt:now,requestedBy:req.user?.email||req.user?.userId||null}
      await mutateState(s=>{
        s.reviewQueue=s.reviewQueue||[]
        s.reviewQueue.unshift(item)
        s.reviewQueue=s.reviewQueue.slice(0,1000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'fraud.review_queued',entityId:item.id,pattern:item.pattern,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,202,item)
    }
    if (req.method === 'GET' && url.pathname === '/api/deep-links') {
      const state=await getState()
      const items=(state.deepLinks||[]).map(link=>{
        const events=(state.deepLinkEvents||[]).filter(x=>x.slug===link.slug)
        const clicks=events.filter(x=>x.kind==='click').length
        const appOpens=events.filter(x=>x.kind==='app_open').length
        const conversions=events.filter(x=>x.kind==='conversion').length
        return {...link,clicks,appOpens,conversions,conversionRate:clicks?Number((conversions/clicks*100).toFixed(1)):0}
      })
      return send(req,res,200,{items,stats:{active:items.filter(x=>x.status==='active').length,draft:items.filter(x=>x.status!=='active').length,clicks:items.reduce((n,x)=>n+x.clicks,0),appOpens:items.reduce((n,x)=>n+x.appOpens,0),conversions:items.reduce((n,x)=>n+x.conversions,0)},generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/deep-links') {
      const body=await readBody(req)
      if(!body.name||!body.slug||!body.target||!body.fallback) return send(req,res,400,{error:'name, slug, target and fallback required'})
      const slug=String(body.slug).trim().toLowerCase().replace(/[^a-z0-9-]+/g,'-').replace(/^-|-$/g,'')
      if(!slug)return send(req,res,400,{error:'valid slug required'})
      let created=null
      await mutateState(s=>{
        s.deepLinks=s.deepLinks||[]
        if(s.deepLinks.some(x=>x.slug===slug))return
        created={id:'dl_'+randomUUID(),name:String(body.name),slug,target:String(body.target),fallback:String(body.fallback),status:'draft',createdAt:new Date().toISOString()}
        s.deepLinks.unshift(created)
      })
      return created?send(req,res,201,created):send(req,res,409,{error:'slug already exists'})
    }
    if (req.method === 'POST' && url.pathname === '/api/deep-links/event') {
      const body=await readBody(req)
      if(!body.slug||!['click','app_open','conversion'].includes(String(body.kind))) return send(req,res,400,{error:'slug and valid kind required'})
      const event={id:'dle_'+randomUUID(),slug:String(body.slug),kind:String(body.kind),customerId:body.customerId||null,value:body.value??null,source:body.source||null,createdAt:new Date().toISOString()}
      await mutateState(s=>{s.deepLinkEvents=s.deepLinkEvents||[];s.deepLinkEvents.unshift(event);s.deepLinkEvents=s.deepLinkEvents.slice(0,10000)})
      return send(req,res,201,event)
    }
    if (req.method === 'POST' && url.pathname === '/api/deep-links/activate') {
      const body=await readBody(req)
      if(!body.slug) return send(req,res,400,{error:'slug required'})
      let updated=null
      await mutateState(s=>{const item=(s.deepLinks||[]).find(x=>x.slug===String(body.slug));if(item){item.status='active';item.activatedAt=new Date().toISOString();updated={...item}}})
      return updated?send(req,res,200,updated):send(req,res,404,{error:'deep link not found'})
    }
    if (req.method === 'GET' && url.pathname === '/api/reconciliation') {
      const [state,attr,eventStats]=await Promise.all([getState(),attributionStats(workspaceId),trackedEventStats(workspaceId)])
      const deliveries=state.signalDeliveries||[]
      const quarantined=state.quarantinedEvents||[]
      const adjustments=state.adjustments||[]
      const duplicateAudit=(state.audit||[]).filter(x=>String(x.action||'').includes('duplicate'))
      const grouped={}
      for(const item of deliveries){
        const key=String(item.destination||'Unknown')
        const row=grouped[key]||{destination:key,total:0,delivered:0,queued:0,failed:0}
        row.total++
        const status=String(item.status||'queued').toLowerCase()
        if(['delivered','succeeded'].includes(status))row.delivered++
        else if(['failed','dead_letter'].includes(status))row.failed++
        else row.queued++
        grouped[key]=row
      }
      const channels=Object.values(grouped).map(row=>({...row,successRate:row.total?Number((row.delivered/row.total*100).toFixed(1)):0,gap:Math.max(0,row.total-row.delivered)}))
      const matched=Number(attr?.matchedEvents||0),unmatched=Number(attr?.unmatchedEvents||0),assisted=Number(attr?.assistedEvents||0)
      const terminal=deliveries.filter(x=>['delivered','succeeded','failed','dead_letter'].includes(String(x.status||'').toLowerCase()))
      const failed=terminal.filter(x=>['failed','dead_letter'].includes(String(x.status||'').toLowerCase())).length
      const issues=[
        {key:'unmatched_attribution',label:'Unmatched attribution',count:unmatched,severity:unmatched?'warning':'healthy',detail:'Offline/assisted conversions without a deterministic or assisted match.',action:'reprocess'},
        {key:'failed_deliveries',label:'Failed deliveries',count:failed,severity:failed?'critical':'healthy',detail:'Provider signal deliveries that failed or reached dead-letter state.',action:'retry'},
        {key:'duplicate_evidence',label:'Duplicate evidence',count:duplicateAudit.length,severity:duplicateAudit.length?'warning':'healthy',detail:'Duplicate activity detected by idempotency/audit controls.',action:'review'},
        {key:'quarantined_events',label:'Quarantined events',count:quarantined.length,severity:quarantined.length?'warning':'healthy',detail:'Events isolated because schema or field validation requires review.',action:'review'}
      ]
      const score=Math.max(0,Math.min(100,100-Math.min(35,unmatched*2)-Math.min(30,failed*5)-Math.min(20,duplicateAudit.length*3)-Math.min(15,quarantined.length*2)))
      return send(req,res,200,{
        available:true,
        score,
        totals:{
          trackedEvents:Number(eventStats?.total??0),
          assistedEvents:assisted,
          matchedEvents:matched,
          unmatchedEvents:unmatched,
          deliveries:deliveries.length,
          failedDeliveries:failed,
          duplicates:duplicateAudit.length,
          quarantined:quarantined.length,
          pendingAdjustments:adjustments.filter(x=>String(x.status||'pending').toLowerCase()!=='applied').length
        },
        channels,
        issues,
        recentActions:(state.reconciliationActions||[]).slice(0,50),
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/reconciliation/action') {
      const body=await readBody(req)
      const issue=String(body.issue||'').trim()
      if(!['unmatched_attribution','failed_deliveries','duplicate_evidence','quarantined_events'].includes(issue)) return send(req,res,400,{error:'valid reconciliation issue required'})
      let result={status:'queued',detail:'Review queued'}
      if(issue==='unmatched_attribution'){
        const r=await reconcileAttribution(workspaceId,Math.max(1,Math.min(500,Number(body.limit||250))))
        result={status:'completed',detail:'Attribution reconciliation completed',matched:Number(r?.matched||0),unmatched:Number(r?.unmatched||0)}
      }else if(issue==='failed_deliveries'){
        if(!queueAvailable()) return send(req,res,503,{error:'signal delivery queue unavailable',required:'DATABASE_URL'})
        const state=await getState()
        const failed=(state.signalDeliveries||[]).filter(x=>['failed','dead_letter'].includes(String(x.status||'').toLowerCase())).slice(0,Math.max(1,Math.min(250,Number(body.limit||100))))
        const now=new Date().toISOString()
        const jobs=[]
        for(const item of failed){
          await mutateState(s=>{
            const target=(s.signalDeliveries||[]).find(x=>x.id===item.id)
            if(target){target.status='queued';target.nextAttemptAt=now;target.updatedAt=now;target.lastError=null}
          })
          const replayPayload=item.replayPayload||buildSignalReplayPayload(item,item)
          const job=await handleSubmitJob({workspaceId,kind:'signal_delivery',idempotencyKey:'reconcile-retry:'+item.id+':'+Date.now(),payload:{...replayPayload,deliveryId:item.id,event:item.event,destination:item.destination,idempotencyKey:item.idempotencyKey}})
          jobs.push(job?.id||null)
        }
        result={status:'queued',detail:'Failed deliveries re-queued',replayed:failed.length,jobs:jobs.filter(Boolean)}
      }else{
        result={status:'review',detail:issue==='duplicate_evidence'?'Duplicate evidence queued for adjustment/review.':'Quarantined events queued for schema review.'}
      }
      const action={id:'recon_'+randomUUID(),issue,status:result.status,detail:result.detail,createdAt:new Date().toISOString(),createdBy:req.user?.email||req.user?.userId||'workspace',result}
      await mutateState(s=>{
        s.reconciliationActions=s.reconciliationActions||[]
        s.reconciliationActions.unshift(action)
        s.reconciliationActions=s.reconciliationActions.slice(0,500)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'reconciliation.action',entityId:action.id,issue,status:action.status,at:action.createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,action)
    }
    if (req.method === 'GET' && url.pathname === '/api/diagnostics') {
      const [state,attr,jobs]=await Promise.all([getState(),attributionStats(workspaceId),queueStats(workspaceId)])
      const deliveries=state.signalDeliveries||[]
      const delivered=deliveries.filter(x=>x.status==='delivered').length
      const failed=deliveries.filter(x=>x.status==='dead_letter').length
      const duplicateCount=(state.audit||[]).filter(x=>String(x.action||'').includes('duplicate')).length
      const clickTotal=Number(attr?.activeClickSessions||0)
      const clickCovered=Number(attr?.clickIdCoverage?.gclid||0)+Number(attr?.clickIdCoverage?.fbclid||0)+Number(attr?.clickIdCoverage?.braid||0)
      const clickIdCoverage=clickTotal?Number(Math.min(100,(clickCovered/clickTotal*100)).toFixed(2)):0
      const connectorProblems=(state.connectorHealth||[]).filter(x=>String(x.status||'').toLowerCase()!=='healthy')
      const quarantined=Number(state.quarantinedEvents?.length||0)
      const deliveryRate=deliveries.length?delivered/deliveries.length:1
      const score=Math.max(0,Math.min(100,Math.round(100-(failed*4)-(connectorProblems.length*3)-(quarantined>0?4:0)-(clickTotal&&clickIdCoverage<90?6:0))))
      const issues=[]
      if(duplicateCount) issues.push({key:'duplicate_conversions',severity:'warning',affected:duplicateCount})
      if(clickTotal&&clickIdCoverage<95) issues.push({key:'missing_click_ids',severity:'warning',affectedPercent:Number((100-clickIdCoverage).toFixed(2))})
      if(failed) issues.push({key:'delivery_failures',severity:failed>10?'critical':'warning',affected:failed})
      for(const item of connectorProblems.slice(0,5)) issues.push({key:'connector_health',severity:'warning',connector:item.name,status:item.status})
      if(quarantined) issues.push({key:'schema_mismatch',severity:'info',quarantined})
      return send(req,res,200,{available:true,score,duplicateRate:deliveries.length?Number((duplicateCount/Math.max(1,deliveries.length)*100).toFixed(2)):0,clickIdCoverage,quarantined,deliveryRate:Number((deliveryRate*100).toFixed(2)),queue:jobs,issues,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/diagnostics/scan') {
      const resultId='scan_'+randomUUID()
      const startedAt=new Date().toISOString()
      const [state,attr,jobs]=await Promise.all([getState(),attributionStats(workspaceId),queueStats(workspaceId)])
      const result={
        id:resultId,
        startedAt,
        completedAt:new Date().toISOString(),
        signalDeliveries:(state.signalDeliveries||[]).length,
        deadLetter:(state.signalDeliveries||[]).filter(x=>x.status==='dead_letter').length,
        connectorIssues:(state.connectorHealth||[]).filter(x=>String(x.status||'').toLowerCase()!=='healthy').length,
        unmatchedAttribution:Number(attr?.unmatchedEvents||0),
        queue:jobs
      }
      await mutateState(s=>{
        s.diagnosticScans=s.diagnosticScans||[]
        s.diagnosticScans.unshift(result)
        s.diagnosticScans=s.diagnosticScans.slice(0,100)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'diagnostics.scan_completed',entityId:resultId,at:result.completedAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,result)
    }
    if (req.method === 'POST' && url.pathname === '/api/diagnostics/replay') {
      const body=await readBody(req)
      if(!body.issue) return send(req,res,400,{error:'issue required'})
      const replayId='diag_'+randomUUID()
      const now=new Date().toISOString()
      await mutateState(s=>{
        s.diagnosticReplays=s.diagnosticReplays||[]
        s.diagnosticReplays.unshift({id:replayId,issue:String(body.issue),status:'queued',createdAt:now})
        s.diagnosticReplays=s.diagnosticReplays.slice(0,250)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'diagnostics.replay_queued',entityId:replayId,issue:String(body.issue),at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,202,{queued:true,issue:body.issue,replayId,status:'queued'})
    }
    if (req.method === 'GET' && url.pathname === '/api/leak-monitor') {
      const [profiles,followUps,meetings,routes,state]=await Promise.all([
        listLeadProfiles(workspaceId,500),
        listPersistedFollowUps(workspaceId),
        listPersistedMeetings(workspaceId),
        listRoutingDecisions(workspaceId,500),
        getState()
      ])
      const defaults={new:30,lead:60,qualified:60,routed:120,contacted:240,consultation:720}
      const thresholds={...defaults,...(state.leakMonitorSettings||{})}
      const now=Date.now()
      const leadRef=lead=>String(lead.external_lead_id||lead.id||lead.name||'')
      const stageKey=value=>{
        const s=String(value||'lead').toLowerCase()
        if(/won|converted|customer|enrolled|closed/.test(s))return 'converted'
        if(/consult|meeting|appointment|demo/.test(s))return 'consultation'
        if(/contact|called|reached/.test(s))return 'contacted'
        if(/route|assign|owner/.test(s))return 'routed'
        if(/qualif|mql|sql/.test(s))return 'qualified'
        if(/new|created/.test(s))return 'new'
        return 'lead'
      }
      const getActivity=lead=>{
        const candidates=[lead.updated_at,lead.created_at,lead.journey?.lastActivity,lead.attributes?.lastActivity].filter(Boolean).map(x=>Date.parse(x)).filter(Number.isFinite)
        return candidates.length?Math.max(...candidates):Date.parse(lead.created_at||0)
      }
      const items=[]
      for(const lead of profiles){
        const stage=stageKey(lead.crm_stage)
        if(stage==='converted')continue
        const ref=leadRef(lead)
        const last=getActivity(lead)
        const ageMinutes=Math.max(0,Math.round((now-last)/60000))
        const threshold=Number(thresholds[stage]||thresholds.lead||60)
        const openFollowUps=followUps.filter(x=>String(x.lead_ref)===ref&&String(x.status)==='open')
        const futureMeetings=meetings.filter(x=>String(x.lead_ref)===ref&&Date.parse(x.starts_at||0)>now&&String(x.status)!=='cancelled')
        const route=routes.find(x=>String(x.lead_ref)===ref)
        const recovered=(state.leakRecoveries||[]).find(x=>x.leadRef===ref&&x.status==='queued')
        const missingHandoff=
          stage==='qualified'&&!route?'Qualified lead has no routing decision':
          stage==='routed'&&!openFollowUps.length?'Routed lead has no open follow-up':
          stage==='contacted'&&!futureMeetings.length?'Contacted lead has no future meeting':
          stage==='consultation'&&!openFollowUps.length?'Consultation-stage lead has no recovery follow-up':
          ''
        const stalled=ageMinutes>=threshold
        if(!stalled&&!missingHandoff)continue
        const severity=missingHandoff&&ageMinutes>=threshold*2?'critical':ageMinutes>=threshold*2?'high':'medium'
        items.push({
          id:'leak_'+String(lead.id||ref),
          leadRef:ref,
          name:lead.name||ref,
          stage,
          crmStage:lead.crm_stage||'Lead',
          grade:lead.grade||null,
          score:Number(lead.score||0),
          source:lead.source||'First-party',
          campaign:lead.campaign||null,
          ageMinutes,
          thresholdMinutes:threshold,
          severity,
          reason:missingHandoff||('No meaningful activity for '+ageMinutes+' minutes'),
          evidence:{
            hasRoute:Boolean(route),
            openFollowUps:openFollowUps.length,
            futureMeetings:futureMeetings.length,
            lastActivity:last?new Date(last).toISOString():null
          },
          recoveryQueued:Boolean(recovered)
        })
      }
      items.sort((a,b)=>((({critical:3,high:2,medium:1}[b.severity]||0)-({critical:3,high:2,medium:1}[a.severity]||0))||b.ageMinutes-a.ageMinutes))
      const stageCounts=items.reduce((acc,x)=>{acc[x.stage]=(acc[x.stage]||0)+1;return acc},{})
      const recoveries=(state.leakRecoveries||[]).slice(0,100)
      return send(req,res,200,{
        items,
        thresholds,
        stats:{
          total:items.length,
          critical:items.filter(x=>x.severity==='critical').length,
          high:items.filter(x=>x.severity==='high').length,
          medium:items.filter(x=>x.severity==='medium').length,
          recoveryQueued:items.filter(x=>x.recoveryQueued).length,
          stageCounts
        },
        recoveries,
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/leak-monitor/settings') {
      const body=await readBody(req)
      const allowed=['new','lead','qualified','routed','contacted','consultation']
      const settings={}
      for(const key of allowed){
        if(body[key]==null)continue
        const value=Number(body[key])
        if(!Number.isFinite(value)||value<5||value>43200) return send(req,res,400,{error:key+' threshold must be 5-43200 minutes'})
        settings[key]=Math.round(value)
      }
      await mutateState(s=>{s.leakMonitorSettings={...(s.leakMonitorSettings||{}),...settings};s.audit=s.audit||[];s.audit.unshift({id:randomUUID(),action:'leak_monitor.settings_updated',settings,at:new Date().toISOString()});s.audit=s.audit.slice(0,1000)})
      return send(req,res,200,{settings})
    }
    if (req.method === 'POST' && url.pathname === '/api/leak-monitor/recover') {
      const body=await readBody(req)
      const leadRef=String(body.leadRef||'').trim()
      if(!leadRef) return send(req,res,400,{error:'leadRef required'})
      const channel=String(body.channel||'call').toLowerCase()
      if(!['call','voice','whatsapp','email'].includes(channel)) return send(req,res,400,{error:'unsupported recovery channel'})
      const delayMinutes=Math.max(0,Math.min(10080,Number(body.delayMinutes||0)))
      const reason=String(body.reason||'Funnel leak recovery').trim().slice(0,300)
      const existing=(await listPersistedFollowUps(workspaceId)).find(x=>String(x.lead_ref)===leadRef&&String(x.status)==='open'&&String(x.reason||'').startsWith('Leak recovery'))
      if(existing) return send(req,res,200,{duplicate:true,item:existing})
      const followUp=await createFollowUp(workspaceId,{leadRef,reason:'Leak recovery · '+reason,channel,priority:String(body.priority||'high'),delayMinutes,owner:String(body.owner||'Growth recovery queue')})
      if(!followUp) return send(req,res,503,{error:'follow-up store unavailable'})
      const recovery={id:'leakrec_'+randomUUID(),leadRef,followUpId:followUp.id,channel,status:'queued',reason,createdAt:new Date().toISOString(),createdBy:req.user?.email||req.user?.userId||'workspace'}
      await mutateState(s=>{s.leakRecoveries=s.leakRecoveries||[];s.leakRecoveries.unshift(recovery);s.leakRecoveries=s.leakRecoveries.slice(0,1000);s.audit=s.audit||[];s.audit.unshift({id:randomUUID(),action:'leak_monitor.recovery_queued',entityId:recovery.id,leadRef,followUpId:followUp.id,at:recovery.createdAt});s.audit=s.audit.slice(0,1000)})
      return send(req,res,201,{duplicate:false,item:followUp,recovery})
    }
    if (req.method === 'GET' && url.pathname === '/api/funnel') {
      const [allProfiles,allMeetings]=await Promise.all([listLeadProfiles(workspaceId,500),listPersistedMeetings(workspaceId)])
      const allowedPeriods=new Set([7,30,90])
      const requestedDays=Number(url.searchParams.get('periodDays')||30)
      const periodDays=allowedPeriods.has(requestedDays)?requestedDays:30
      const cutoff=Date.now()-periodDays*24*60*60*1000
      const requestedChannel=String(url.searchParams.get('channel')||'').trim()
      const requestedAccount=String(url.searchParams.get('account')||'').trim()
      const requestedDisposition=String(url.searchParams.get('disposition')||'').trim()
      const inWindow=item=>{
        const raw=item.updated_at||item.updatedAt||item.created_at||item.createdAt||item.starts_at||item.startsAt||null
        if(!raw)return true
        const time=Date.parse(raw)
        return Number.isNaN(time)||time>=cutoff
      }
      const accountFor=lead=>String(
        lead.attributes?.adAccountName||
        lead.attributes?.adAccount||
        lead.attributes?.accountName||
        lead.attributes?.account||
        'Default / Unknown'
      )
      const periodProfiles=allProfiles.filter(inWindow)
      const channels=[...new Set(periodProfiles.map(lead=>String(lead.source||'First-party')))].sort((a,b)=>a.localeCompare(b))
      const accounts=[...new Set(periodProfiles.map(accountFor))].sort((a,b)=>a.localeCompare(b))
      let profiles=periodProfiles
      if(requestedChannel)profiles=profiles.filter(lead=>String(lead.source||'First-party')===requestedChannel)
      if(requestedAccount)profiles=profiles.filter(lead=>accountFor(lead)===requestedAccount)
      const qualifiedStages=new Set(['qualified','consultation','opportunity','converted','enrolled','closed_won','customer'])
      const consultationStages=new Set(['consultation','opportunity','converted','enrolled','closed_won','customer'])
      const bookingStages=new Set(['converted','enrolled','closed_won','customer'])
      const leadKey=lead=>String(lead.external_lead_id||lead.name||lead.id)
      const profileByLead=new Map()
      for(const lead of profiles){
        profileByLead.set(leadKey(lead),lead)
        if(lead.name)profileByLead.set(String(lead.name),lead)
      }
      const meetings=allMeetings.filter(inWindow).filter(meeting=>profileByLead.has(String(meeting.lead_ref||'')))
      const campaigns=new Map()
      const ensure=lead=>{
        const name=String(lead.campaign||lead.source||'Unattributed')
        const account=accountFor(lead)
        const channel=String(lead.source||'First-party')
        const key=channel+'::'+account+'::'+name
        const row=campaigns.get(key)||{key,name,account,channel,leads:0,qualified:0,appointments:0,consultations:0,bookings:0}
        campaigns.set(key,row)
        return row
      }
      for(const lead of profiles){
        const row=ensure(lead)
        row.leads++
        const stage=String(lead.crm_stage||'').toLowerCase()
        if(['A','B'].includes(String(lead.grade))||qualifiedStages.has(stage))row.qualified++
        if(consultationStages.has(stage))row.consultations++
        if(bookingStages.has(stage))row.bookings++
      }
      for(const meeting of meetings){
        const lead=profileByLead.get(String(meeting.lead_ref||''))
        if(lead)ensure(lead).appointments++
      }
      const rate=(part,total)=>total?Number((Number(part||0)/Number(total)*100).toFixed(1)):0
      const enrichRates=row=>({
        ...row,
        leadToQualifiedRate:rate(row.qualified,row.leads),
        qualifiedToAppointmentRate:rate(row.appointments,row.qualified),
        appointmentToConsultationRate:rate(row.consultations,row.appointments),
        consultationToBookingRate:rate(row.bookings,row.consultations),
        leadToBookingRate:rate(row.bookings,row.leads)
      })
      const dispositionKey={
        Qualified:'qualified',
        Appointments:'appointments',
        Consultations:'consultations',
        Bookings:'bookings'
      }[requestedDisposition]||''
      let campaignRows=[...campaigns.values()].map(enrichRates).sort((a,b)=>b.leads-a.leads||b.bookings-a.bookings)
      if(dispositionKey)campaignRows=campaignRows.filter(row=>Number(row[dispositionKey]||0)>0)
      const stages={
        leads:profiles.length,
        qualified:profiles.filter(lead=>['A','B'].includes(String(lead.grade))||qualifiedStages.has(String(lead.crm_stage||'').toLowerCase())).length,
        appointments:meetings.length,
        consultations:profiles.filter(lead=>consultationStages.has(String(lead.crm_stage||'').toLowerCase())).length,
        bookings:profiles.filter(lead=>bookingStages.has(String(lead.crm_stage||'').toLowerCase())).length
      }
      const stageRates={
        leadToQualified:rate(stages.qualified,stages.leads),
        qualifiedToAppointment:rate(stages.appointments,stages.qualified),
        appointmentToConsultation:rate(stages.consultations,stages.appointments),
        consultationToBooking:rate(stages.bookings,stages.consultations),
        leadToBooking:rate(stages.bookings,stages.leads)
      }
      return send(req,res,200,{
        available:true,
        stages,
        stageRates,
        campaigns:campaignRows,
        filters:{
          channel:requestedChannel||'All channels',
          account:requestedAccount||'All accounts',
          disposition:requestedDisposition||'All dispositions',
          periodDays,
          channels,
          accounts
        },
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/data-hub') {
      const [state,leadStats,attr,providerData]=await Promise.all([getState(),leadOpsStats(workspaceId),attributionStats(workspaceId),connectorDataSummary(workspaceId).catch(()=>({available:false,raw:[],campaigns:[],crm:[]}))])
      const now=Date.now()
      const sourceMap=new Map()
      const touch=(name,type,eventTime,count=1,status='healthy',fields=[])=>{
        const key=String(name||'Unknown')
        const current=sourceMap.get(key)||{name:key,type,records:0,lastEventAt:null,status,fields:new Set()}
        current.records+=Number(count||0)
        if(eventTime&&(!current.lastEventAt||Date.parse(eventTime)>Date.parse(current.lastEventAt)))current.lastEventAt=eventTime
        if(status!=='healthy')current.status=status
        for(const field of fields)current.fields.add(field)
        sourceMap.set(key,current)
      }
      for(const event of trackedEvents){
        const source=event.source||event.channel||event.utm_source||'First-party web/app'
        touch(source,'first_party',event.receivedAt||event.occurredAt||event.timestamp,1,'healthy',Object.keys(event).filter(k=>!['id','receivedAt'].includes(k)).slice(0,12))
      }
      const waEvents=(state.whatsappEvents||[])
      const waLatest=waEvents.map(x=>x.timestamp||x.receivedAt).filter(Boolean).sort().at(-1)||null
      if(waEvents.length)touch('WhatsApp','messaging',waLatest,waEvents.length,'healthy',['phone','message','status','timestamp'])
      const callEvents=(state.callEvents||[])
      const callLatest=callEvents.map(x=>x.endedAt||x.startedAt||x.receivedAt).filter(Boolean).sort().at(-1)||null
      if(callEvents.length)touch('Telephony','calling',callLatest,callEvents.length,'healthy',['phone','duration','status','campaign'])
      if(leadStats?.available)touch('Lead profiles','crm_identity',new Date().toISOString(),Number(leadStats.total||0),'healthy',['customer_id','email_hash','phone_hash','stage','grade','device_id'])
      if(attr?.available)touch('Attribution store','measurement',new Date().toISOString(),Number(attr.assistedEvents||0)+Number(attr.activeClickSessions||0),'healthy',['click_id','session','event','match_method','value'])
      const deliveries=(state.signalDeliveries||[])
      if(deliveries.length)touch('Activation deliveries','activation',deliveries[0]?.updatedAt||deliveries[0]?.createdAt||null,deliveries.length,deliveries.some(x=>['failed','dead_letter'].includes(String(x.status||'').toLowerCase()))?'review':'healthy',['event','destination','status','attempts'])
      for(const item of providerData.raw||[]){
        touch(item.connector,'provider_sync',item.last_ingested_at,Number(item.rows||0),'healthy',[item.stream,'raw_record'])
      }
      for(const item of providerData.campaigns||[]){
        if(!sourceMap.has(item.connector))touch(item.connector,'provider_campaigns',item.max_day,Number(item.rows||0),'healthy',['campaign','spend','impressions','clicks','conversions','conversion_value'])
      }
      for(const health of state.connectorHealth||[]){
        if(!sourceMap.has(health.name))touch(health.name,'connector',health.checkedAt||health.updatedAt||null,0,['healthy','connected','active'].includes(String(health.status||'').toLowerCase())?'healthy':'review',['connection_state'])
      }
      const sources=[...sourceMap.values()].map(x=>({
        name:x.name,
        type:x.type,
        records:x.records,
        lastEventAt:x.lastEventAt,
        freshnessSeconds:x.lastEventAt?Math.max(0,Math.floor((now-Date.parse(x.lastEventAt))/1000)):null,
        status:x.status,
        fields:[...x.fields]
      })).sort((a,b)=>b.records-a.records)
      const records=sources.reduce((sum,x)=>sum+x.records,0)
      const quarantined=Number((state.quarantinedEvents||[]).length)
      const schemaHealth=records?Number((Math.max(0,records-quarantined)/records*100).toFixed(2)):100
      const recent=[
        ...trackedEvents.slice(-40).map(x=>({id:x.id||randomUUID(),time:x.receivedAt||x.occurredAt||x.timestamp,source:x.source||x.channel||x.utm_source||'First-party',kind:'event',operation:'append',status:'healthy'})),
        ...waEvents.slice(0,20).map(x=>({id:'wa:'+x.id,time:x.timestamp||x.receivedAt,source:'WhatsApp',kind:x.kind||'message',operation:'append',status:x.error?'review':'healthy'})),
        ...callEvents.slice(0,20).map(x=>({id:'call:'+x.id,time:x.endedAt||x.startedAt||x.receivedAt,source:'Telephony',kind:'call',operation:'append',status:'healthy'})),
        ...deliveries.slice(0,20).map(x=>({id:'delivery:'+x.id,time:x.updatedAt||x.createdAt,source:x.destination||'Activation',kind:x.event||'signal',operation:'deliver',status:['failed','dead_letter'].includes(String(x.status||'').toLowerCase())?'review':'healthy'}))
      ].filter(x=>x.time).sort((a,b)=>Date.parse(b.time)-Date.parse(a.time)).slice(0,50)
      return send(req,res,200,{available:true,records,knownIdentities:Number(leadStats?.total||0),schemaHealth,quarantined,matchedEvents:Number(attr?.matchedEvents||0),sources,recent,providerData,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/data-hub/rebuild') {
      const [state,leadStats,attr,eventStats]=await Promise.all([getState(),leadOpsStats(workspaceId),attributionStats(workspaceId),trackedEventStats(workspaceId).catch(()=>({total:trackedEvents.length}))])
      const snapshot={
        id:'dh_'+randomUUID(),
        scope:'canonical_view',
        status:'completed',
        trackedEvents:trackedEvents.length,
        leadProfiles:Number(leadStats?.total||0),
        assistedEvents:Number(attr?.assistedEvents||0),
        clickSessions:Number(attr?.activeClickSessions||0),
        whatsappEvents:Number((state.whatsappEvents||[]).length),
        callEvents:Number((state.callEvents||[]).length),
        signalDeliveries:Number((state.signalDeliveries||[]).length),
        quarantinedEvents:Number((state.quarantinedEvents||[]).length),
        completedAt:new Date().toISOString()
      }
      await mutateState(s=>{
        s.dataHubRebuilds=s.dataHubRebuilds||[]
        s.dataHubRebuilds.unshift(snapshot)
        s.dataHubRebuilds=s.dataHubRebuilds.slice(0,100)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'data_hub.canonical_snapshot_rebuilt',entityId:snapshot.id,at:snapshot.completedAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,snapshot)
    }
    if (req.method === 'GET' && url.pathname === '/api/live-sync') {
      const state=await getState()
      const [recentTracked,eventStats]=await Promise.all([
        listTrackedEvents(workspaceId,{limit:250}).catch(()=>trackedEvents.slice(-250)),
        trackedEventStats(workspaceId).catch(()=>({lastMinute:0}))
      ])
      const lastMinuteCount=Number(eventStats?.lastMinute||0)
      const deliveries=(state.signalDeliveries||[]).slice(0,1000)
      const delivered=deliveries.filter(x=>x.status==='delivered')
      const successful=deliveries.filter(x=>['delivered','succeeded'].includes(String(x.status||'').toLowerCase())).length
      const terminal=deliveries.filter(x=>['delivered','succeeded','dead_letter','failed'].includes(String(x.status||'').toLowerCase())).length
      const latencies=delivered.map(x=>Number(x.latencyMs||x.providerResponse?.latencyMs||0)).filter(x=>Number.isFinite(x)&&x>=0).sort((a,b)=>a-b)
      const medianLatencyMs=latencies.length?latencies[Math.floor(latencies.length/2)]:null
      const byDestination={}
      for(const item of deliveries){
        const key=String(item.destination||'Unknown')
        byDestination[key]=byDestination[key]||{destination:key,total:0,delivered:0,failed:0}
        byDestination[key].total++
        if(['delivered','succeeded'].includes(String(item.status||'').toLowerCase()))byDestination[key].delivered++
        if(['dead_letter','failed'].includes(String(item.status||'').toLowerCase()))byDestination[key].failed++
      }
      const destinationThroughput=Object.values(byDestination).map(x=>({...x,deliveryRate:x.total?Number((x.delivered/x.total*100).toFixed(2)):0}))
      const recent=[
        ...recentTracked.slice(-50).map(x=>({
          id:x.id||x.eventId||randomUUID(),
          time:x.receivedAt||x.occurredAt||x.timestamp||null,
          source:x.source||x.channel||'First-party',
          event:x.event||x.eventType||x.name||'event',
          destination:'Ingestion',
          status:'accepted',
          matchKey:x.customerId?'customer_id':x.deviceId||x.device_id?'device_id':x.gclid?'gclid':x.fbclid?'fbclid':x.visitorId?'visitor_id':'event_id'
        })),
        ...deliveries.slice(0,50).map(x=>({
          id:x.id,
          time:x.updatedAt||x.createdAt||null,
          source:'Activation queue',
          event:x.event||'signal',
          destination:x.destination||'Unknown',
          status:x.status||'queued',
          matchKey:x.customerId?'customer_id':x.replayPayload?.gclid?'gclid':x.replayPayload?.emailSha256?'email_sha256':x.replayPayload?.phoneSha256?'phone_sha256':'event_id'
        }))
      ].sort((a,b)=>Date.parse(b.time||0)-Date.parse(a.time||0)).slice(0,50)
      return send(req,res,200,{
        available:true,
        status:recentTracked.length||deliveries.length?'active':'idle',
        medianLatencyMs,
        deliveryRate:terminal?Number((successful/terminal*100).toFixed(2)):null,
        eventsPerMinute:lastMinuteCount,
        recent,
        destinations:destinationThroughput,
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/matchback') {
      const [live,state]=await Promise.all([attributionStats(workspaceId),getState()])
      return send(req,res,200,{
        live,
        rules:state.matchbackRules||[],
        unmatched:live.available?Number(live.unmatchedEvents||0):0,
        templates:[
          {name:'Closed-won revenue',source:'crm_billing',eventType:'closed_won',destination:'Google Ads',identityMethod:'customer_id + click ID'},
          {name:'Enrolment conversion',source:'crm',eventType:'enrolment',destination:'Meta Ads',identityMethod:'customer_id + hashed contact'},
          {name:'WhatsApp consultation sale',source:'crm_whatsapp',eventType:'closed_won',destination:'Google Ads + Meta Ads',identityMethod:'phone + click history'},
          {name:'Offline store sale',source:'pos_crm',eventType:'store_sale',destination:'Google Ads + Meta Ads',identityMethod:'customer_id / hashed contact / click ID'}
        ]
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/matchback/rules') {
      const body=await readBody(req)
      const name=String(body.name||'').trim()
      const source=String(body.source||'').trim()
      const eventType=String(body.eventType||'').trim()
      const destination=String(body.destination||'').trim()
      const identityMethod=String(body.identityMethod||'').trim()
      if(!name||!source||!eventType||!destination||!identityMethod) return send(req,res,400,{error:'name, source, eventType, destination and identityMethod are required'})
      const now=new Date().toISOString()
      const item={id:'mb_'+randomUUID(),name:name.slice(0,160),source:source.slice(0,120),eventType:eventType.slice(0,120),destination:destination.slice(0,160),identityMethod:identityMethod.slice(0,240),status:'active',createdAt:now}
      await mutateState(s=>{
        s.matchbackRules=s.matchbackRules||[]
        s.matchbackRules.unshift(item)
        s.matchbackRules=s.matchbackRules.slice(0,200)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'matchback.rule_created',entityId:item.id,name:item.name,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/matchback/rules/toggle') {
      const body=await readBody(req)
      if(!body.id||typeof body.enabled!=='boolean') return send(req,res,400,{error:'id and enabled are required'})
      let updated=null
      await mutateState(s=>{
        const item=(s.matchbackRules||[]).find(x=>x.id===body.id)
        if(item){item.status=body.enabled?'active':'paused';item.updatedAt=new Date().toISOString();updated={...item}}
      })
      return updated?send(req,res,200,{item:updated}):send(req,res,404,{error:'matchback rule not found'})
    }
    if (req.method === 'GET' && url.pathname === '/api/matchback/unmatched') {
      const live=await attributionStats(workspaceId)
      return send(req,res,200,{items:(live?.recent||[]).filter(x=>x.status==='unmatched'),total:Number(live?.unmatchedEvents||0)})
    }
    if (req.method === 'POST' && url.pathname === '/api/matchback/reconcile') {
      const body=await readBody(req)
      if(!body.ruleId) return send(req,res,400,{error:'ruleId required'})
      const state=await getState()
      const rule=(state.matchbackRules||[]).find(x=>x.id===body.ruleId)
      if(!rule) return send(req,res,404,{error:'matchback rule not found'})
      if(rule.status==='paused') return send(req,res,409,{error:'matchback rule is paused'})
      const result=await reconcileAttribution(workspaceId,body.limit||250)
      const completedAt=new Date().toISOString()
      await mutateState(s=>{
        const item=(s.matchbackRules||[]).find(x=>x.id===body.ruleId)
        if(item){item.lastRunAt=completedAt;item.lastRunStatus='reconciled';item.lastRunMatched=Number(result?.matched||0);item.lastRunUnmatched=Number(result?.unmatched||0)}
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'matchback.reconciled',entityId:body.ruleId,name:rule.name,matched:Number(result?.matched||0),unmatched:Number(result?.unmatched||0),at:completedAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,{ruleId:body.ruleId,rule:rule.name,status:'reconciled',...result,completedAt})
    }
    if (req.method === 'GET' && url.pathname === '/api/pos-stores') {
      const state=await getState()
      const batches=state.posBatches||[]
      const locations=new Map()
      for(const batch of batches){
        const key=String(batch.location)
        const row=locations.get(key)||{name:batch.locationName||key,id:key,transactions:0,revenue:0,matched:0,imports:0,lastImportAt:null}
        row.transactions+=Number(batch.records||0);row.revenue+=Number(batch.revenue||0);row.matched+=Number(batch.matched||0);row.imports++;row.lastImportAt=batch.createdAt
        locations.set(key,row)
      }
      const items=[...locations.values()].map(x=>({...x,matchRate:x.transactions?Number((x.matched/x.transactions*100).toFixed(1)):0,status:x.transactions&&x.matched<x.transactions?'review':'healthy'}))
      return send(req,res,200,{locations:items,totals:{transactions:items.reduce((n,x)=>n+x.transactions,0),revenue:items.reduce((n,x)=>n+x.revenue,0),matched:items.reduce((n,x)=>n+x.matched,0),imports:batches.length},recent:batches.slice(0,50),generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/pos-stores/import') {
      const body=await readBody(req)
      const location=String(body.location||'').trim()
      const rows=Array.isArray(body.transactions)?body.transactions.slice(0,500):[]
      if(!location||!rows.length) return send(req,res,400,{error:'location and at least one transaction row are required'})
      const createdAt=new Date().toISOString()
      const normalized=[]
      let matched=0
      let revenue=0
      for(let index=0;index<rows.length;index++){
        const row=rows[index]||{}
        const transactionId=String(row.transactionId||row.transaction_id||'').trim()||('row_'+(index+1))
        const value=Math.max(0,Number(row.netRevenue??row.net_revenue??row.value??0)||0)
        const occurredAt=row.occurredAt||row.occurred_at||createdAt
        const currency=String(row.currency||body.currency||'INR').slice(0,12)
        const event=await recordAssistedEvent(workspaceId,{
          event:'store_sale',
          eventType:'store_sale',
          eventId:'pos_'+location+'_'+transactionId,
          customerId:row.customerId||row.customer_id||null,
          email:row.email||null,
          phone:row.phone||null,
          gclid:row.gclid||null,
          fbclid:row.fbclid||null,
          msclkid:row.msclkid||null,
          ttclid:row.ttclid||null,
          twclid:row.twclid||null,
          source:'pos',
          occurredAt,
          value,
          currency,
          data:{location,transactionId,batchImport:true}
        }).catch(()=>null)
        if(event?.status==='matched')matched++
        revenue+=value
        normalized.push({
          transactionId,
          status:event?.status||'unavailable',
          matchMethod:event?.match_method||null,
          value,
          currency,
          occurredAt
        })
      }
      const records=normalized.length
      const batch={
        batchId:'pos_'+randomUUID(),
        location,
        locationName:String(body.locationName||location),
        records,
        revenue:Number(revenue.toFixed(2)),
        matched,
        unmatched:records-matched,
        matchRate:records?Number((matched/records*100).toFixed(1)):0,
        status:'processed',
        createdAt,
        sample:normalized.slice(0,25)
      }
      await mutateState(s=>{
        s.posBatches=s.posBatches||[]
        s.posBatches.unshift(batch)
        s.posBatches=s.posBatches.slice(0,2000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'pos.import_processed',entityId:batch.batchId,location:batch.location,records,matched,revenue:batch.revenue,at:batch.createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,batch)
    }
    if (req.method === 'GET' && url.pathname === '/api/offline-attribution') {
      const [state,stats]=await Promise.all([getState(),attributionStats(workspaceId)])
      const calls=(state.callEvents||[])
      const whatsapp=(state.whatsappEvents||[]).filter(x=>x.kind==='message')
      const connectedCalls=calls.filter(x=>['answered','completed','connected','qualified'].includes(String(x.status||'').toLowerCase()))
      const waWithIdentity=whatsapp.filter(x=>x.from)
      return send(req,res,200,{
        generatedAt:new Date().toISOString(),
        callAttribution:{
          events:calls.length,
          connected:connectedCalls.length,
          providers:[...new Set(calls.map(x=>x.provider).filter(Boolean))],
          method:'first-party identity + click/session reconciliation'
        },
        whatsapp:{
          messages:whatsapp.length,
          identifiable:waWithIdentity.length,
          identifiers:['phone','gclid','fbclid','customer_id']
        },
        attribution:{
          available:Boolean(stats?.available),
          matchedEvents:Number(stats?.matchedEvents||0),
          unmatchedEvents:Number(stats?.unmatchedEvents||0),
          matchRate:Number(stats?.matchRate||0),
          matchedValue:Number(stats?.matchedValue||0)
        },
        rules:state.offlineAttributionRules||[],
        templates:[
          {conversion:'Inbound Call',source:'Telephony',match:'first-party identity + session/click reconciliation',identifier:'Phone / click ID',destination:['Google Ads','Meta Ads']},
          {conversion:'WhatsApp Enquiry',source:'WhatsApp',match:'persisted click/customer identity + phone',identifier:'Phone / GCLID / FBCLID',destination:['Google Ads','Meta Ads']},
          {conversion:'Partial Payment',source:'Custom Backend',match:'customer_id + order mapping',identifier:'Customer ID / order ID',destination:['Google Ads']},
          {conversion:'Walk-in / Offline Sale',source:'CRM / POS',match:'hashed phone/email + click history',identifier:'Hashed contact / click ID',destination:['Google Ads','Meta Ads']}
        ]
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/offline-attribution/rules') {
      const body=await readBody(req)
      const conversion=String(body.conversion||'').trim()
      const source=String(body.source||'').trim()
      const match=String(body.match||'').trim()
      const identifier=String(body.identifier||'').trim()
      const destination=Array.isArray(body.destination)?body.destination.map(String).filter(Boolean):[String(body.destination||'').trim()].filter(Boolean)
      if(!conversion||!source||!match||!identifier||!destination.length) return send(req,res,400,{error:'conversion, source, match, identifier and destination are required'})
      const now=new Date().toISOString()
      const item={id:'off_'+randomUUID(),conversion:conversion.slice(0,160),source:source.slice(0,160),match:match.slice(0,300),identifier:identifier.slice(0,200),destination:destination.slice(0,5),status:'active',createdAt:now}
      await mutateState(s=>{
        s.offlineAttributionRules=s.offlineAttributionRules||[]
        s.offlineAttributionRules.unshift(item)
        s.offlineAttributionRules=s.offlineAttributionRules.slice(0,200)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'offline_attribution.rule_created',entityId:item.id,conversion:item.conversion,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/offline-attribution/rules/toggle') {
      const body=await readBody(req)
      if(!body.id||typeof body.enabled!=='boolean') return send(req,res,400,{error:'id and enabled are required'})
      let updated=null
      await mutateState(s=>{
        const item=(s.offlineAttributionRules||[]).find(x=>x.id===body.id)
        if(item){item.status=body.enabled?'active':'paused';item.updatedAt=new Date().toISOString();updated={...item}}
      })
      return updated?send(req,res,200,{item:updated}):send(req,res,404,{error:'offline attribution rule not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/offline-attribution/test') {
      const body=await readBody(req)
      const state=await getState()
      const rule=(state.offlineAttributionRules||[]).find(x=>x.id===body.ruleId)
      if(!rule) return send(req,res,404,{error:'offline attribution rule not found'})
      if(rule.status==='paused') return send(req,res,409,{error:'offline attribution rule is paused'})
      const eventId='offtest_'+randomUUID()
      const item=await recordAssistedEvent(workspaceId,{
        event:body.event||rule.conversion.toLowerCase().replace(/[^a-z0-9]+/g,'_'),
        eventType:body.eventType||rule.conversion.toLowerCase().replace(/[^a-z0-9]+/g,'_'),
        eventId,
        customerId:body.customerId||null,
        email:body.email||null,
        phone:body.phone||null,
        gclid:body.gclid||null,
        fbclid:body.fbclid||null,
        source:rule.source,
        occurredAt:new Date().toISOString(),
        value:Number(body.value||0),
        currency:String(body.currency||'INR'),
        data:{offlineRuleId:rule.id,test:true}
      })
      if(!item) return send(req,res,503,{error:'attribution store unavailable'})
      const now=new Date().toISOString()
      await mutateState(s=>{
        const saved=(s.offlineAttributionRules||[]).find(x=>x.id===rule.id)
        if(saved){saved.lastTestAt=now;saved.lastTestStatus=item.status;saved.lastTestMethod=item.match_method||null}
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'offline_attribution.rule_tested',entityId:rule.id,eventId,status:item.status,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{id:item.id,status:item.status,matchMethod:item.match_method,matchConfidence:item.match_confidence,matchedSessionId:item.matched_session_id})
    }
    if (req.method === 'GET' && url.pathname === '/api/personalization-rules') {
      const state=await getState()
      const items=(state.personalizationRules||[]).slice().sort((a,b)=>Number(b.priority||0)-Number(a.priority||0)||Date.parse(b.updatedAt||b.createdAt||0)-Date.parse(a.updatedAt||a.createdAt||0))
      const decisions=state.personalizationDecisions||[]
      const feedback=state.personalizationFeedback||[]
      const performance=items.map(rule=>{
        const ruleDecisions=decisions.filter(x=>x.ruleId===rule.id)
        const ruleFeedback=feedback.filter(x=>x.ruleId===rule.id)
        const impressions=ruleFeedback.filter(x=>x.kind==='impression').length
        const clicks=ruleFeedback.filter(x=>x.kind==='click').length
        const conversions=ruleFeedback.filter(x=>x.kind==='conversion').length
        return {ruleId:rule.id,decisions:ruleDecisions.length,impressions,clicks,conversions,ctr:impressions?Number((clicks/impressions*100).toFixed(1)):0,conversionRate:impressions?Number((conversions/impressions*100).toFixed(1)):0}
      })
      return send(req,res,200,{items,performance,recentDecisions:decisions.slice(0,100),recentFeedback:feedback.slice(0,100),stats:{total:items.length,active:items.filter(x=>x.status==='active').length,decisions:decisions.length,impressions:feedback.filter(x=>x.kind==='impression').length,clicks:feedback.filter(x=>x.kind==='click').length,conversions:feedback.filter(x=>x.kind==='conversion').length}})
    }
    if (req.method === 'POST' && url.pathname === '/api/personalization-rules') {
      const body=await readBody(req)
      const name=String(body.name||'').trim()
      const surface=String(body.surface||'website').trim()
      const variant=String(body.variant||'').trim()
      if(name.length<3||name.length>120) return send(req,res,400,{error:'name must be 3-120 characters'})
      if(!variant) return send(req,res,400,{error:'variant required'})
      const conditions=(Array.isArray(body.conditions)?body.conditions:[]).slice(0,8).map(x=>({field:String(x.field||'').trim(),operator:String(x.operator||'equals'),value:x.value??''})).filter(x=>x.field)
      const now=new Date().toISOString()
      const item={id:'pers_'+randomUUID(),name,surface,variant,message:String(body.message||'').trim(),cta:String(body.cta||'').trim(),destination:String(body.destination||'').trim(),conditions,priority:Math.max(0,Math.min(1000,Number(body.priority||100))),status:body.enabled===false?'paused':'active',requiresPersonalizationConsent:body.requiresPersonalizationConsent!==false,createdAt:now,updatedAt:now,createdBy:req.user?.email||req.user?.userId||'workspace'}
      await mutateState(s=>{
        s.personalizationRules=s.personalizationRules||[]
        s.personalizationRules.unshift(item)
        s.personalizationRules=s.personalizationRules.slice(0,500)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'personalization_rule.created',entityId:item.id,surface:item.surface,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/personalization-rules/toggle') {
      const body=await readBody(req)
      const id=String(body.id||'')
      let updated=null
      await mutateState(s=>{
        const item=(s.personalizationRules||[]).find(x=>x.id===id)
        if(item){item.status=body.enabled?'active':'paused';item.updatedAt=new Date().toISOString();updated={...item}}
      })
      return updated?send(req,res,200,{item:updated}):send(req,res,404,{error:'personalization rule not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/personalization/decide') {
      const body=await readBody(req)
      const customerRef=String(body.customerId||body.leadId||body.visitorId||body.deviceId||'').trim()
      if(!customerRef) return send(req,res,400,{error:'customerId, leadId, visitorId, or deviceId required'})
      const consent=await consentAllows(workspaceId,{subjectType:body.customerId?'customer':'visitor',subjectId:customerRef,category:'personalization'})
      const profile=await getLeadProfile(workspaceId,customerRef).catch(()=>null)
      const state=await getState()
      const context={
        ...body,
        ...(profile?.attributes||{}),
        ...(profile?.journey||{}),
        grade:profile?.grade??body.grade,
        score:profile?.score??body.score,
        stage:profile?.crm_stage??body.stage,
        source:profile?.source??body.source,
        campaign:profile?.campaign??body.campaign,
        devicePlatform:profile?.device_platform??body.devicePlatform,
        ltvTier:profile?.journey?.ltvTier??body.ltvTier,
        conversionPropensity:profile?.journey?.conversionPropensity??body.conversionPropensity
      }
      const rules=(state.personalizationRules||[]).filter(x=>x.status==='active'&&(!body.surface||String(x.surface)===String(body.surface))).sort((a,b)=>Number(b.priority||0)-Number(a.priority||0))
      const matched=rules.find(rule=>(rule.conditions||[]).every(condition=>activationConditionMatches(condition,context)))
      const blocked=matched?.requiresPersonalizationConsent&&!consent.allowed
      const decision={id:'pdec_'+randomUUID(),customerRef,surface:String(body.surface||matched?.surface||'website'),ruleId:matched?.id||null,ruleName:matched?.name||null,variant:blocked?null:(matched?.variant||null),message:blocked?null:(matched?.message||null),cta:blocked?null:(matched?.cta||null),destination:blocked?null:(matched?.destination||null),matched:Boolean(matched),status:blocked?'consent_blocked':matched?'decided':'no_match',createdAt:new Date().toISOString()}
      await mutateState(s=>{
        s.personalizationDecisions=s.personalizationDecisions||[]
        s.personalizationDecisions.unshift(decision)
        s.personalizationDecisions=s.personalizationDecisions.slice(0,5000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'personalization.decided',entityId:decision.id,ruleId:decision.ruleId,status:decision.status,at:decision.createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,{decision,consent:{allowed:consent.allowed,reason:consent.reason},profileFound:Boolean(profile)})
    }
    if (req.method === 'POST' && url.pathname === '/api/personalization/feedback') {
      const body=await readBody(req)
      if(!body.decisionId||!['impression','click','conversion'].includes(String(body.kind))) return send(req,res,400,{error:'decisionId and kind impression/click/conversion required'})
      const state=await getState()
      const decision=(state.personalizationDecisions||[]).find(x=>x.id===String(body.decisionId))
      if(!decision) return send(req,res,404,{error:'personalization decision not found'})
      const item={id:'pfb_'+randomUUID(),decisionId:decision.id,ruleId:decision.ruleId,customerRef:decision.customerRef,kind:String(body.kind),value:body.value==null?null:Number(body.value),currency:body.currency||null,createdAt:new Date().toISOString()}
      await mutateState(s=>{
        s.personalizationFeedback=s.personalizationFeedback||[]
        s.personalizationFeedback.unshift(item)
        s.personalizationFeedback=s.personalizationFeedback.slice(0,10000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'personalization.feedback',entityId:item.id,decisionId:item.decisionId,kind:item.kind,at:item.createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'GET' && url.pathname === '/api/activation-rules') {
      const state=await getState()
      const items=(state.activationRules||[]).slice().sort((a,b)=>Date.parse(b.updatedAt||b.createdAt||0)-Date.parse(a.updatedAt||a.createdAt||0))
      const runs=(state.activationRuleRuns||[]).slice(0,100)
      const active=items.filter(x=>x.status==='active').length
      return send(req,res,200,{items,runs,stats:{total:items.length,active,paused:items.length-active,runs:runs.length,succeeded:runs.filter(x=>x.status==='succeeded').length,skipped:runs.filter(x=>x.status==='skipped').length}})
    }
    if (req.method === 'POST' && url.pathname === '/api/activation-rules') {
      const body=await readBody(req)
      const name=String(body.name||'').trim()
      const triggerEvent=String(body.triggerEvent||'').trim()
      const actionType=String(body.actionType||'').trim()
      if(name.length<3||name.length>120) return send(req,res,400,{error:'name must be 3-120 characters'})
      if(!triggerEvent) return send(req,res,400,{error:'triggerEvent required'})
      if(!['signal','follow_up','route'].includes(actionType)) return send(req,res,400,{error:'actionType must be signal, follow_up, or route'})
      if(actionType==='signal'&&!String(body.destination||'').trim()) return send(req,res,400,{error:'signal destination required'})
      if(actionType==='route'&&!String(body.destination||'').trim()) return send(req,res,400,{error:'routing destination required'})
      const conditions=(Array.isArray(body.conditions)?body.conditions:[]).slice(0,5).map(x=>({field:String(x.field||'').trim(),operator:String(x.operator||'equals'),value:x.value??''})).filter(x=>x.field)
      const now=new Date().toISOString()
      const item={
        id:'actrule_'+randomUUID(),
        name,
        triggerEvent,
        conditions,
        actionType,
        destination:String(body.destination||'').trim()||null,
        outputEvent:String(body.outputEvent||triggerEvent).trim()||triggerEvent,
        channel:String(body.channel||'whatsapp').trim(),
        owner:String(body.owner||'Marketing automation').trim(),
        priority:String(body.priority||'medium').trim(),
        delayMinutes:Math.max(0,Math.min(10080,Number(body.delayMinutes||0))),
        reason:String(body.reason||name).trim(),
        status:body.enabled===false?'paused':'active',
        requiresMarketingConsent:body.requiresMarketingConsent!==false,
        createdAt:now,
        updatedAt:now,
        createdBy:req.user?.email||req.user?.userId||'workspace'
      }
      await mutateState(s=>{
        s.activationRules=s.activationRules||[]
        s.activationRules.unshift(item)
        s.activationRules=s.activationRules.slice(0,500)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'activation_rule.created',entityId:item.id,triggerEvent:item.triggerEvent,actionType:item.actionType,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/activation-rules/toggle') {
      const body=await readBody(req)
      const id=String(body.id||'')
      let updated=null
      await mutateState(s=>{
        const item=(s.activationRules||[]).find(x=>x.id===id)
        if(item){item.status=body.enabled?'active':'paused';item.updatedAt=new Date().toISOString();updated={...item}}
      })
      return updated?send(req,res,200,{item:updated}):send(req,res,404,{error:'activation rule not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/activation-rules/test') {
      const body=await readBody(req)
      const state=await getState()
      const rule=(state.activationRules||[]).find(x=>x.id===String(body.id||''))
      if(!rule) return send(req,res,404,{error:'activation rule not found'})
      const sample=body.event&&typeof body.event==='object'?body.event:{event:rule.triggerEvent,customerId:'activation_test_customer',value:100}
      return send(req,res,200,{matched:activationRuleMatches({...rule,status:'active'},sample),ruleId:rule.id,sample,evaluatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/track') {
      const body=await readBody(req)
      const inputError=trackingInputError(body)
      if(inputError)return send(req,res,400,{accepted:false,error:inputError})
      const authorization=String(req.headers.authorization||'')
      const suppliedKey=authorization.replace(/^Bearer\s+/i,'')
      if(suppliedKey.startsWith('ace_')){
        const fingerprint=createHash('sha256').update(suppliedKey).digest('hex')
        const keyState=await getState()
        const apiKey=(keyState.apiKeys||[]).find(x=>x.fingerprint===fingerprint&&x.status!=='revoked')
        if(!apiKey) return send(req,res,401,{accepted:false,error:'invalid or revoked api key'})
        const usedAt=new Date().toISOString()
        await mutateState(s=>{
          const key=(s.apiKeys||[]).find(x=>x.id===apiKey.id)
          if(key) key.lastUsedAt=usedAt
        })
      }
      const category=['essential','analytics','marketing','personalization'].includes(String(body.eventCategory))?String(body.eventCategory):'analytics'
      const trackingSubjectId=body.customerId||body.visitorId||body.deviceId||body.device_id
      if(!trackingSubjectId) return send(req,res,400,{accepted:false,error:'customerId, visitorId, or deviceId required'})
      const consent=await consentAllows(workspaceId,{subjectType:body.customerId?'customer':'visitor',subjectId:trackingSubjectId,category})
      if(!consent.allowed) return send(req,res,403,{accepted:false,error:'consent required',reason:consent.reason,category})
      const event={...body,id:body.id||randomUUID(),receivedAt:new Date().toISOString(),consentCategory:category}
      trackedEvents.push(event)
      if(trackedEvents.length>5000) trackedEvents.splice(0,trackedEvents.length-5000)
      const persistedEvent={...event}
      if(persistedEvent.email){
        persistedEvent.emailSha256=persistedEvent.emailSha256||persistedEvent.email_sha256||sha256Normalized(persistedEvent.email)
        delete persistedEvent.email
      }
      if(persistedEvent.phone){
        persistedEvent.phoneSha256=persistedEvent.phoneSha256||persistedEvent.phone_sha256||sha256Phone(persistedEvent.phone)
        delete persistedEvent.phone
      }
      await mutateState(s=>{
        s.recentEvents=s.recentEvents||[]
        s.recentEvents.unshift(persistedEvent)
        s.recentEvents=s.recentEvents.slice(0,5000)
      })
      await appendTrackedEvent(workspaceId,persistedEvent)
      let leadProfile=null
      if(body.customerId||body.email||body.phone||body.emailSha256||body.email_sha256||body.phoneSha256||body.phone_sha256||body.deviceId||body.device_id){
        leadProfile=await upsertLeadProfile(workspaceId,{
          externalLeadId:body.customerId||body.leadId||body.visitorId||body.deviceId||body.device_id,
          customerId:body.customerId,
          leadId:body.leadId,
          email:body.email,
          phone:body.phone,
          emailSha256:body.emailSha256||body.email_sha256,
          phoneSha256:body.phoneSha256||body.phone_sha256,
          deviceId:body.deviceId||body.device_id,
          devicePlatform:body.devicePlatform||body.device_platform,
          appId:body.appId||body.app_id,
          source:body.source||body.utm_source||'first_party',
          campaign:body.campaign||body.utm_campaign||null,
          crmStage:body.crmStage||body.stage||null,
          journeyDepth:body.journeyDepth||body.pagesViewed||0,
          pricingPageViews:body.pricingPageViews||0,
          conversionPropensity:body.conversionPropensity||0,
          ltvTier:body.ltvTier||null,
          lastActivity:body.occurredAt||event.receivedAt,
          attributes:{channel:body.channel||null,event:body.event||body.name||null,platform:body.platform||null,consentSubjectType:body.customerId?'customer':'visitor',consentSubjectId:trackingSubjectId}
        }).catch(()=>null)
      }
      let clickSession=null
      let assisted=null
      if(body.gclid||body.gbraid||body.wbraid||body.fbclid||body.msclkid||body.utm_source||body.utm_campaign||body.visitorId||body.deviceId||body.device_id){
        clickSession=await captureClickSession(workspaceId,{...body,eventId:event.id,userAgent:req.headers['user-agent']}).catch(()=>null)
      }
      if(body.assisted===true||['call','whatsapp','crm','pos','billing','offline'].includes(String(body.source||'').toLowerCase())){
        assisted=await recordAssistedEvent(workspaceId,{...body,eventId:body.eventId||event.id}).catch(()=>null)
      }
      const derived=await evaluateEventRules(workspaceId,{...body,eventId:body.eventId||event.id},{sourceEventId:event.id}).catch(()=>[])
      const derivedDeliveries=[]
      const activationRuns=[]
      if(derived.length){
        const marketingConsent=await consentAllows(workspaceId,{subjectType:body.customerId?'customer':'visitor',subjectId:trackingSubjectId,category:'marketing'})
        for(const match of derived){
          let queued=0
          if(marketingConsent.allowed){
            for(const destination of match.destinations){
              const deliveryId='sig_'+randomUUID()
              const idempotencyKey=createHash('sha256').update('event-rule:'+match.runId+':'+destination).digest('hex')
              const now=new Date().toISOString()
              const item={id:deliveryId,event:match.outputEvent,destination,customerId:body.customerId?String(body.customerId):null,externalEventId:match.assistedEvent?.id||match.runId,status:'queued',attempts:0,idempotencyKey,createdAt:now,updatedAt:now,nextAttemptAt:now}
              item.replayPayload=buildSignalReplayPayload({...body,event:match.outputEvent,destination,value:match.assistedEvent?.value??body.value??null,currency:match.assistedEvent?.currency||body.currency||null},{...item,idempotencyKey})
              await mutateState(s=>{s.signalDeliveries=s.signalDeliveries||[];s.signalDeliveries.unshift(item);s.signalDeliveries=s.signalDeliveries.slice(0,10000);s.audit.unshift({id:randomUUID(),action:'event-rule.signal.queued',entityId:deliveryId,ruleId:match.ruleId,destination,event:match.outputEvent,at:now});s.audit=s.audit.slice(0,1000)})
              const job=await handleSubmitJob({workspaceId,kind:'signal_delivery',idempotencyKey:'rule-signal:'+idempotencyKey,payload:item.replayPayload})
              derivedDeliveries.push({ruleId:match.ruleId,outputEvent:match.outputEvent,destination,deliveryId,jobId:job?.id||null})
              queued++
            }
          }
          await markEventRuleActivation(workspaceId,match.runId,queued).catch(()=>{})
        }
      }
      const activationState=await getState()
      const activationRules=(activationState.activationRules||[]).filter(rule=>activationRuleMatches(rule,body))
      if(activationRules.length){
        const marketingConsent=await consentAllows(workspaceId,{subjectType:body.customerId?'customer':'visitor',subjectId:trackingSubjectId,category:'marketing'})
        for(const rule of activationRules){
          const run={id:'actrun_'+randomUUID(),ruleId:rule.id,ruleName:rule.name,eventId:event.id,customerRef:String(body.customerId||body.leadId||body.visitorId||body.deviceId||body.device_id||''),actionType:rule.actionType,status:'queued',detail:'',createdAt:new Date().toISOString()}
          if(rule.requiresMarketingConsent&& !marketingConsent.allowed){
            run.status='skipped'
            run.detail='Marketing consent unavailable'
          }else{
            try{
              if(rule.actionType==='follow_up'){
                const task=await createFollowUp(workspaceId,{leadRef:run.customerRef,reason:rule.reason||rule.name,channel:rule.channel||'whatsapp',priority:rule.priority||'medium',delayMinutes:Number(rule.delayMinutes||0),owner:rule.owner||'Marketing automation'})
                run.status=task?'succeeded':'failed'
                run.detail=task?'Follow-up '+task.id+' created':'Follow-up store unavailable'
                run.operationId=task?.id||null
              }else if(rule.actionType==='route'){
                const routed=await routeLead(workspaceId,{leadRef:run.customerRef,score:Number(leadProfile?.score||body.score||0),source:body.source||'Real-time activation',routingRule:{name:rule.name,destination:rule.destination,reason:rule.reason||rule.name,slaSeconds:Math.max(60,Number(rule.slaSeconds||300))}})
                run.status=routed?'succeeded':'failed'
                run.detail=routed?'Routed to '+rule.destination:'Routing store unavailable'
                run.operationId=routed?.id||null
              }else if(rule.actionType==='signal'){
                const deliveryId='sig_'+randomUUID()
                const idempotencyKey=createHash('sha256').update('activation-rule:'+rule.id+':'+event.id+':'+rule.destination).digest('hex')
                const now=new Date().toISOString()
                const item={id:deliveryId,event:rule.outputEvent||body.event||body.eventType||'activation_event',destination:rule.destination,customerId:body.customerId?String(body.customerId):null,externalEventId:event.id,status:'queued',attempts:0,idempotencyKey,createdAt:now,updatedAt:now,nextAttemptAt:now}
                item.replayPayload=buildSignalReplayPayload({...body,event:item.event,destination:item.destination},{...item,idempotencyKey})
                const validationError=validateSignalDispatch(item.replayPayload)
                if(validationError){
                  run.status='failed';run.detail=validationError
                }else{
                  await mutateState(s=>{s.signalDeliveries=s.signalDeliveries||[];s.signalDeliveries.unshift(item);s.signalDeliveries=s.signalDeliveries.slice(0,10000)})
                  const job=await handleSubmitJob({workspaceId,kind:'signal_delivery',idempotencyKey:'activation:'+idempotencyKey,payload:item.replayPayload})
                  run.status='succeeded';run.detail='Signal queued for '+rule.destination;run.operationId=deliveryId;run.jobId=job?.id||null
                }
              }
            }catch(error){
              run.status='failed'
              run.detail=error instanceof Error?error.message:'Activation execution failed'
            }
          }
          activationRuns.push(run)
          await mutateState(s=>{
            s.activationRuleRuns=s.activationRuleRuns||[]
            s.activationRuleRuns.unshift(run)
            s.activationRuleRuns=s.activationRuleRuns.slice(0,2000)
            s.audit=s.audit||[]
            s.audit.unshift({id:randomUUID(),action:'activation_rule.executed',entityId:run.id,ruleId:rule.id,status:run.status,eventId:event.id,at:new Date().toISOString()})
            s.audit=s.audit.slice(0,1000)
          })
        }
      }
      return send(req,res,202,{accepted:true,eventId:event.id,leadProfileId:leadProfile?.id||null,clickSessionId:clickSession?.id||null,assistedEventId:assisted?.id||null,derivedEvents:derived.map(x=>({runId:x.runId,ruleId:x.ruleId,outputEvent:x.outputEvent,assistedEventId:x.assistedEvent?.id||null,destinations:x.destinations})),derivedDeliveries,activationRuns,match:assisted?{status:assisted.status,method:assisted.match_method,confidence:assisted.match_confidence}:null})
    }
    if (req.method === 'POST' && url.pathname === '/api/assisted-events') {
      const body=await readBody(req)
      if(!body.event&&!body.eventType) return send(req,res,400,{error:'event or eventType required'})
      const item=await recordAssistedEvent(workspaceId,body)
      if(!item) return send(req,res,503,{error:'attribution store unavailable'})
      return send(req,res,201,{id:item.id,status:item.status,matchMethod:item.match_method,matchConfidence:item.match_confidence,matchedSessionId:item.matched_session_id})
    }
    if (req.method === 'GET' && url.pathname === '/api/attribution-identity/stats') {
      const periodDays=Number(url.searchParams.get('periodDays')||0)||null
      const stats=await attributionStats(workspaceId,{periodDays})
      return send(req,res,200,stats)
    }
    if (req.method === 'GET' && url.pathname === '/api/journeys') {
      const [profiles,meetings,followUps,feedbackResult,routingDecisions,state]=await Promise.all([
        listLeadProfiles(workspaceId,500),
        listPersistedMeetings(workspaceId),
        listPersistedFollowUps(workspaceId),
        listPersistedFeedback(workspaceId),
        listRoutingDecisions(workspaceId,500),
        getState()
      ])
      const feedback=feedbackResult?.items||[]
      const humanDuration=(from,to)=>{
        const ms=Math.max(0,Date.parse(to||'')-Date.parse(from||''))
        if(!Number.isFinite(ms)||ms<=0)return '—'
        const minutes=Math.round(ms/60000)
        if(minutes<60)return minutes+'m'
        const hours=Math.round(minutes/60)
        if(hours<48)return hours+'h'
        return Math.round(hours/24)+'d'
      }
      const sameLead=(lead,ref)=>{
        const value=String(ref||'').toLowerCase()
        if(!value)return false
        return [lead.id,lead.external_lead_id,lead.name].filter(Boolean).some(x=>String(x).toLowerCase()===value)
      }
      const trackedForLead=lead=>trackedEvents.filter(event=>{
        const refs=[event.customerId,event.leadId,event.externalLeadId,event.visitorId,event.deviceId,event.device_id]
        return refs.some(ref=>sameLead(lead,ref))||(lead.device_id&&refs.some(ref=>String(ref||'')===String(lead.device_id)))
      })
      const items=profiles.map(lead=>{
        const journey=lead.journey||{}
        const timeline=[]
        const push=(type,source,title,detail,at,meta={})=>{
          if(!at)return
          timeline.push({id:type+'_'+randomUUID(),type,source,title,detail,at,...meta})
        }
        push('lead','CRM / identity','Lead profile created','First persisted lead profile',lead.created_at,{stage:lead.crm_stage||lead.grade||'Lead'})
        for(const event of trackedForLead(lead)){
          push('event',event.source||event.channel||'First-party',String(event.event||event.eventType||event.name||'Tracked event').replaceAll('_',' '),'First-party tracked activity',event.occurredAt||event.receivedAt||event.timestamp,{event:event.event||event.eventType||event.name||null})
        }
        for(const item of routingDecisions.filter(x=>sameLead(lead,x.lead_ref))){
          push('routing','Routing',item.rule_name||'Lead routed',item.destination||item.reason||'Routing decision',item.created_at,{destination:item.destination||null})
        }
        for(const item of followUps.filter(x=>sameLead(lead,x.lead_ref))){
          push('follow_up','Follow-up',item.reason||'Follow-up created',(item.channel||'channel')+' · '+(item.status||'open'),item.created_at,{status:item.status||null,dueAt:item.due_at||null})
          if(item.completed_at)push('follow_up_completed','Follow-up','Follow-up completed',item.reason||'',item.completed_at,{status:'completed'})
        }
        for(const item of meetings.filter(x=>sameLead(lead,x.lead_ref))){
          push('meeting','Meetings','Consultation scheduled',(item.owner||'Counsellor')+' · '+(item.status||'confirmed'),item.created_at||item.starts_at,{startsAt:item.starts_at,status:item.status||null,meetingLink:item.meeting_link||null})
          if(item.last_reminder_at)push('reminder','Meetings','Meeting reminder sent',String(item.reminders_sent||1)+' reminder(s) sent',item.last_reminder_at)
        }
        for(const item of feedback.filter(x=>sameLead(lead,x.lead_ref))){
          push('feedback','Feedback','Feedback recorded',(item.theme||'Uncategorized')+(item.score!=null?' · '+item.score+'/5':''),item.created_at,{score:item.score,theme:item.theme||null})
        }
        const callSummary=lead.call_summary||journey.callOutcome
        if(callSummary)push('call','Calls','Call context updated',String(callSummary),lead.updated_at)
        const whatsappSummary=lead.whatsapp_summary||(journey.whatsappEngaged?'WhatsApp engagement recorded':null)
        if(whatsappSummary)push('whatsapp','WhatsApp','WhatsApp context updated',String(whatsappSummary),lead.updated_at)
        if(lead.crm_stage)push('stage','CRM','Current CRM stage',String(lead.crm_stage),lead.updated_at,{stage:lead.crm_stage})
        timeline.sort((a,b)=>Date.parse(a.at||0)-Date.parse(b.at||0))
        const lastAt=timeline[timeline.length-1]?.at||journey.lastActivity||lead.updated_at
        return {
          id:lead.id,
          lead:lead.name||lead.external_lead_id,
          externalLeadId:lead.external_lead_id,
          source:lead.source||'First-party',
          campaign:lead.campaign||null,
          stage:lead.crm_stage||lead.grade||'Lead',
          grade:lead.grade,
          score:lead.score,
          touchpoints:timeline.length,
          duration:humanDuration(lead.created_at,lastAt),
          lastActivity:lastAt,
          devicePlatform:lead.device_platform||null,
          timeline
        }
      })
      return send(req,res,200,{available:true,items,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/customer-360') {
      const [profiles,meetings,followUps,feedbackResult,routingDecisions,agentRuns,audiences]=await Promise.all([
        listLeadProfiles(workspaceId,500),
        listPersistedMeetings(workspaceId),
        listPersistedFollowUps(workspaceId),
        listPersistedFeedback(workspaceId),
        listRoutingDecisions(workspaceId,500),
        listAgentRuns(workspaceId,500),
        listLeadAudiences(workspaceId)
      ])
      const feedback=feedbackResult?.items||[]
      const sameLead=(lead,ref)=>{
        const value=String(ref||'').trim().toLowerCase()
        if(!value)return false
        return [lead.id,lead.external_lead_id,lead.name].filter(Boolean).some(x=>String(x).trim().toLowerCase()===value)
      }
      const trackedForLead=lead=>trackedEvents.filter(event=>{
        const refs=[event.customerId,event.leadId,event.externalLeadId,event.visitorId,event.deviceId,event.device_id]
        return refs.some(ref=>sameLead(lead,ref))||(lead.device_id&&refs.some(ref=>String(ref||'')===String(lead.device_id)))
      })
      const summaries=profiles.map(lead=>{
        const events=trackedForLead(lead)
        const leadMeetings=meetings.filter(x=>sameLead(lead,x.lead_ref))
        const leadFollowUps=followUps.filter(x=>sameLead(lead,x.lead_ref))
        const leadFeedback=feedback.filter(x=>sameLead(lead,x.lead_ref))
        const leadRoutes=routingDecisions.filter(x=>sameLead(lead,x.lead_ref))
        const leadRuns=agentRuns.filter(x=>sameLead(lead,x.entity_id)||sameLead(lead,x.input?.lead)||sameLead(lead,x.input?.leadRef))
        return {
          id:lead.id,
          externalLeadId:lead.external_lead_id,
          name:lead.name||lead.external_lead_id,
          source:lead.source||'First-party',
          campaign:lead.campaign||null,
          stage:lead.crm_stage||'Lead',
          grade:lead.grade||null,
          score:Number(lead.score||0),
          intent:Number(lead.intent||0),
          updatedAt:lead.updated_at,
          activityCount:events.length+leadMeetings.length+leadFollowUps.length+leadFeedback.length+leadRoutes.length+leadRuns.length,
          meetings:leadMeetings.length,
          followUps:leadFollowUps.length,
          feedback:leadFeedback.length
        }
      })
      const requested=String(url.searchParams.get('id')||'').trim()
      const selected=requested
        ?profiles.find(x=>[x.id,x.external_lead_id,x.name].filter(Boolean).some(v=>String(v)===requested))
        :profiles[0]
      if(!selected) return send(req,res,200,{available:true,total:summaries.length,items:summaries,customer:null,generatedAt:new Date().toISOString()})

      const events=trackedForLead(selected)
      const leadMeetings=meetings.filter(x=>sameLead(selected,x.lead_ref))
      const leadFollowUps=followUps.filter(x=>sameLead(selected,x.lead_ref))
      const leadFeedback=feedback.filter(x=>sameLead(selected,x.lead_ref))
      const leadRoutes=routingDecisions.filter(x=>sameLead(selected,x.lead_ref))
      const leadRuns=agentRuns.filter(x=>sameLead(selected,x.entity_id)||sameLead(selected,x.input?.lead)||sameLead(selected,x.input?.leadRef))
      const audienceBundles=await Promise.all(audiences.slice(0,50).map(async audience=>{
        const bundle=await getAudienceBundle(workspaceId,audience.id).catch(()=>null)
        const member=(bundle?.members||[]).find(x=>sameLead(selected,x.external_lead_id)||String(x.device_id||'')===String(selected.device_id||'__none__'))
        return member?{id:audience.id,name:audience.name,mode:audience.mode,destination:audience.destination,status:audience.status,action:member.action||audience.mode}:null
      }))
      const timeline=[]
      const push=(type,title,detail,at,source,meta={})=>{if(at)timeline.push({id:type+'_'+randomUUID(),type,title,detail,at,source,...meta})}
      push('profile','Customer profile created','Canonical lead/customer profile entered the workspace.',selected.created_at,'CRM / identity')
      for(const event of events)push('event',String(event.event||event.eventType||event.name||'Tracked event').replaceAll('_',' '),'First-party activity captured.',event.occurredAt||event.receivedAt||event.timestamp,event.source||event.channel||'Tracking',{value:event.value||null})
      for(const item of leadRoutes)push('routing',item.rule_name||'Lead routed',item.destination||item.reason||'Routing decision',item.created_at,'Routing',{destination:item.destination||null})
      for(const item of leadFollowUps){
        push('follow_up',item.reason||'Follow-up created',(item.channel||'channel')+' · '+(item.status||'open'),item.created_at,'Follow-up',{status:item.status||null})
        if(item.completed_at)push('follow_up_completed','Follow-up completed',item.reason||'',item.completed_at,'Follow-up',{status:'completed'})
      }
      for(const item of leadMeetings){
        push('meeting','Meeting scheduled',(item.owner||'Owner')+' · '+(item.status||'confirmed'),item.starts_at||item.created_at,'Meetings',{meetingLink:item.meeting_link||null})
        if(item.last_reminder_at)push('reminder','Meeting reminder sent',String(item.reminders_sent||1)+' reminder(s)',item.last_reminder_at,'Meetings')
      }
      for(const item of leadFeedback)push('feedback','Feedback recorded',(item.theme||'Uncategorized')+(item.score!=null?' · '+item.score+'/5':''),item.created_at,'Feedback',{score:item.score,theme:item.theme||null})
      for(const item of leadRuns)push('agent',String(item.agent_type||item.action_type||'Agent run').replaceAll('_',' '),String(item.status||'queued'),item.created_at,'Agents',{status:item.status||null})
      if(selected.call_summary)push('call','Call context',String(selected.call_summary),selected.updated_at,'Calls')
      if(selected.whatsapp_summary)push('whatsapp','WhatsApp context',String(selected.whatsapp_summary),selected.updated_at,'WhatsApp')
      timeline.sort((a,b)=>Date.parse(b.at||0)-Date.parse(a.at||0))

      const journey=selected.journey||{}
      const customer={
        id:selected.id,
        externalLeadId:selected.external_lead_id,
        name:selected.name||selected.external_lead_id,
        source:selected.source||'First-party',
        campaign:selected.campaign||null,
        stage:selected.crm_stage||'Lead',
        grade:selected.grade||null,
        score:Number(selected.score||0),
        intent:Number(selected.intent||0),
        createdAt:selected.created_at,
        updatedAt:selected.updated_at,
        identity:{
          deviceId:selected.device_id||null,
          platform:selected.device_platform||null,
          appId:selected.app_id||null,
          hasEmailHash:Boolean(selected.email_sha256),
          hasPhoneHash:Boolean(selected.phone_sha256)
        },
        attributes:selected.attributes||{},
        journey,
        callSummary:selected.call_summary||null,
        whatsappSummary:selected.whatsapp_summary||null,
        audiences:audienceBundles.filter(Boolean),
        operations:{
          meetings:leadMeetings.length,
          followUps:leadFollowUps.length,
          feedback:leadFeedback.length,
          routes:leadRoutes.length,
          agentRuns:leadRuns.length,
          trackedEvents:events.length
        },
        timeline
      }
      return send(req,res,200,{available:true,total:summaries.length,items:summaries,customer,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/planner') {
      const analytics=await cohortAnalytics(workspaceId,{months:6})
      const sources=analytics?.sources||[]
      const totalRevenue=sources.reduce((n,x)=>n+Number(x.revenue||0),0)
      const totalAcquired=sources.reduce((n,x)=>n+Number(x.acquired||0),0)
      const channels=sources.map(x=>{
        const revenue=Number(x.revenue||0),acquired=Number(x.acquired||0),conversions=Number(x.conversions||0)
        const shareBase=totalRevenue>0?revenue:acquired
        const shareTotal=totalRevenue>0?totalRevenue:totalAcquired
        const share=shareTotal?Number((shareBase/shareTotal*100).toFixed(1)):0
        return {
          name:x.source,
          share,
          acquired,
          conversions,
          conversionRate:Number(x.conversionRate||0),
          revenue,
          revenuePerAcquired:Number(x.revenuePerAcquired||0),
          evidence:totalRevenue>0?'revenue_contribution':'acquisition_volume'
        }
      }).sort((a,b)=>b.share-a.share)
      const state=await getState()
      return send(req,res,200,{
        available:Boolean(analytics?.available&&channels.length),
        channels,
        evidence:{months:analytics?.lookbackMonths||6,totalRevenue,totalAcquired,eventDefinitions:analytics?.eventDefinitions||null},
        savedScenarios:(state.plannerScenarios||[]).slice(0,20),
        notice:channels.length?'Allocation weights are derived from observed '+(totalRevenue>0?'attributed revenue':'acquisition volume')+'. Spend/CAC is not inferred when spend data is unavailable.':'Not enough source-level cohort evidence to recommend an allocation.'
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/planner/scenarios') {
      const body=await readBody(req)
      const budget=Number(body.budget)
      if(!Number.isFinite(budget)||budget<=0) return send(req,res,400,{error:'positive budget required'})
      const allocations=Array.isArray(body.allocations)?body.allocations:[]
      if(!allocations.length) return send(req,res,400,{error:'allocations required'})
      const totalShare=allocations.reduce((n,x)=>n+Number(x.share||0),0)
      if(Math.abs(totalShare-100)>0.5) return send(req,res,400,{error:'allocation shares must total 100%'})
      const item={id:'plan_'+randomUUID(),name:String(body.name||'Media scenario'),budget,allocations,createdAt:new Date().toISOString(),createdBy:req.user?.email||req.user?.userId||null}
      await mutateState(s=>{
        s.plannerScenarios=s.plannerScenarios||[]
        s.plannerScenarios.unshift(item)
        s.plannerScenarios=s.plannerScenarios.slice(0,100)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'planner.scenario_saved',entityId:item.id,budget,at:item.createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,item)
    }
    if (req.method === 'GET' && url.pathname === '/api/grouped-performance') {
      const state=await getState()
      const dimension=String(url.searchParams.get('dimension')||'category')
      const allowed=new Set(['category','productCategory','product','brand','source','campaign'])
      if(!allowed.has(dimension)) return send(req,res,400,{error:'unsupported grouping dimension'})
      const analytics=await cohortAnalytics(workspaceId,{months:Number(url.searchParams.get('months')||6)}).catch(()=>({available:false,eventDefinitions:{conversion:[]}}))
      const conversionContract=(analytics.eventDefinitions?.conversion?.length?analytics.eventDefinitions.conversion:String(process.env.COHORT_CONVERSION_EVENTS||'purchase,enrolment,enrollment,booking,revenue.closed,closed_won,sale').split(',').map(x=>x.trim()).filter(Boolean))
      const conversionEvents=new Set(conversionContract.map(x=>String(x).toLowerCase()))
      const events=(state.recentEvents||[]).slice(0,5000)
      const costs=state.groupingCosts?.[dimension]||{}
      const rows=new Map()
      const pick=(event,key)=>{
        const aliases={
          category:['category','productCategory','product_category'],
          productCategory:['productCategory','product_category','category'],
          product:['product','productName','product_name','sku'],
          brand:['brand'],
          source:['source','utm_source'],
          campaign:['campaign','utm_campaign']
        }[key]||[key]
        for(const name of aliases){
          if(event[name]!=null&&String(event[name]).trim())return String(event[name]).trim()
          if(event.data&&event.data[name]!=null&&String(event.data[name]).trim())return String(event.data[name]).trim()
          if(event.properties&&event.properties[name]!=null&&String(event.properties[name]).trim())return String(event.properties[name]).trim()
        }
        return 'Unassigned'
      }
      const subject=e=>String(e.customerId||e.leadId||e.visitorId||e.deviceId||e.device_id||e.emailSha256||e.phoneSha256||e.id||'')
      for(const event of events){
        const key=pick(event,dimension)
        const row=rows.get(key)||{key,events:0,subjects:new Set(),conversions:new Set(),revenue:0}
        row.events++
        row.subjects.add(subject(event))
        const eventName=String(event.event||event.eventType||event.name||'').toLowerCase()
        if(conversionEvents.has(eventName)){
          row.conversions.add(subject(event))
          const value=Number(event.value??event.revenue??event.amount??event.data?.value??0)
          if(Number.isFinite(value))row.revenue+=value
        }
        rows.set(key,row)
      }
      const items=[...rows.values()].map(row=>{
        const costRaw=costs[row.key]
        const cost=costRaw==null?null:Number(costRaw)
        const contribution=cost==null?null:Number((row.revenue-cost).toFixed(2))
        const marginRate=cost==null||row.revenue<=0?null:Number(((row.revenue-cost)/row.revenue*100).toFixed(1))
        return {
          key:row.key,
          events:row.events,
          subjects:row.subjects.size,
          conversions:row.conversions.size,
          conversionRate:row.subjects.size?Number((row.conversions.size/row.subjects.size*100).toFixed(1)):0,
          revenue:Number(row.revenue.toFixed(2)),
          cost,
          contribution,
          marginRate
        }
      }).sort((a,b)=>b.revenue-a.revenue||b.conversions-a.conversions||b.subjects-a.subjects)
      const totals=items.reduce((a,x)=>({events:a.events+x.events,subjects:a.subjects+x.subjects,conversions:a.conversions+x.conversions,revenue:a.revenue+x.revenue,cost:a.cost+(x.cost||0),costedGroups:a.costedGroups+(x.cost!=null?1:0)}),{events:0,subjects:0,conversions:0,revenue:0,cost:0,costedGroups:0})
      return send(req,res,200,{
        dimension,
        available:events.length>0,
        conversionEvents:[...conversionEvents],
        totals:{...totals,conversionRate:totals.subjects?Number((totals.conversions/totals.subjects*100).toFixed(1)):0,contribution:totals.costedGroups?Number((totals.revenue-totals.cost).toFixed(2)):null,marginRate:totals.costedGroups&&totals.revenue>0?Number(((totals.revenue-totals.cost)/totals.revenue*100).toFixed(1)):null},
        items,
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/grouped-performance/costs') {
      const body=await readBody(req)
      const dimension=String(body.dimension||'')
      const key=String(body.key||'').trim()
      const allowed=new Set(['category','productCategory','product','brand','source','campaign'])
      if(!allowed.has(dimension)) return send(req,res,400,{error:'unsupported grouping dimension'})
      if(!key) return send(req,res,400,{error:'group key required'})
      if(body.cost===null||body.cost===''){
        await mutateState(s=>{s.groupingCosts=s.groupingCosts||{};s.groupingCosts[dimension]=s.groupingCosts[dimension]||{};delete s.groupingCosts[dimension][key]})
        return send(req,res,200,{dimension,key,cost:null})
      }
      const cost=Number(body.cost)
      if(!Number.isFinite(cost)||cost<0) return send(req,res,400,{error:'cost must be a non-negative number'})
      await mutateState(s=>{
        s.groupingCosts=s.groupingCosts||{}
        s.groupingCosts[dimension]=s.groupingCosts[dimension]||{}
        s.groupingCosts[dimension][key]=Number(cost.toFixed(2))
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'grouped_performance.cost_saved',dimension,group:key,cost:Number(cost.toFixed(2)),at:new Date().toISOString()})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,{dimension,key,cost:Number(cost.toFixed(2))})
    }
    if (req.method === 'GET' && url.pathname === '/api/cohorts') {
      const months=Number(url.searchParams.get('months')||6)
      return send(req,res,200,await cohortAnalytics(workspaceId,{months}))
    }
    if (req.method === 'GET' && url.pathname === '/api/report-schedules') return send(req,res,200,{configured:reportMailConfigured(),items:await listReportSchedules(workspaceId),deliveries:await listReportDeliveries(workspaceId,30)})
    if (req.method === 'POST' && url.pathname === '/api/report-schedules') {
      const body=await readBody(req)
      try{return send(req,res,200,await saveReportSchedule(workspaceId,body,req.user?.email||req.user?.userId||null))}
      catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'invalid report schedule'})}
    }
    if (req.method === 'POST' && url.pathname === '/api/report-schedules/run-now') {
      const body=await readBody(req)
      if(!body.id)return send(req,res,400,{error:'id required'})
      try{return send(req,res,202,await handleRunReport({workspaceId,scheduleId:String(body.id)}))}
      catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'report queue failed'})}
    }
    if (req.method === 'GET' && url.pathname === '/api/reports') {
      const [analytics,schedules,deliveries]=await Promise.all([cohortAnalytics(workspaceId,{months:6}),listReportSchedules(workspaceId),listReportDeliveries(workspaceId,30)])
      return send(req,res,200,{analytics,schedules,deliveries,configured:reportMailConfigured()})
    }
    if (req.method === 'POST' && url.pathname === '/api/reports/send-test') {
      const body=await readBody(req)
      if(!body.report) return send(req,res,400,{error:'report required'})
      return send(req,res,200,{sent:true,report:body.report,delivery:'email',at:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/attribution') return send(req,res,200,await attributionStats(workspaceId))
    if (req.method === 'GET' && url.pathname === '/api/agents') {
      const [state,profiles,runs,customIntegrations,eventRules,audiences,attribution]=await Promise.all([
        getState(),
        listLeadProfiles(workspaceId,1),
        listAgentRuns(workspaceId),
        listCustomIntegrations(workspaceId),
        listEventRules(workspaceId).catch(()=>[]),
        listLeadAudiences(workspaceId).catch(()=>[]),
        attributionStats(workspaceId).catch(()=>({available:false}))
      ])
      const connected=new Set((state.connectorConnections||[]).filter(x=>String(x.status||'').toLowerCase()==='connected').map(x=>x.connector))
      const hasProfiles=profiles.length>0
      const builtIn=agents.map((name,i)=>{
        let status='available'
        if(name==='Meta Advanced CAPI'&&connected.has('Meta Ads'))status='configured'
        else if(name==='Google ECL / OCI'&&connected.has('Google Ads'))status='configured'
        else if(name==='Call Tracking Events'&&(state.callEvents||[]).length)status='configured'
        else if(name==='Custom Integration'&&customIntegrations.length)status='configured'
        else if((name==='Lead Grading'||name==='CRM Enrichment')&&hasProfiles)status='configured'
        else if(name==='Voice Lead Qualification'&&(process.env.VOICE_QUALIFICATION_WEBHOOK_URL||process.env.VOICE_AGENT_WEBHOOK_URL))status='configured'
        else if(name==='Voice Scheduler'&&(process.env.VOICE_SCHEDULER_WEBHOOK_URL||process.env.VOICE_AGENT_WEBHOOK_URL))status='configured'
        else if(name==='Meeting Reminder'&&process.env.MEETING_REMINDER_WEBHOOK_URL)status='configured'
        else if(name==='Feedback Agent'&&process.env.FEEDBACK_WEBHOOK_URL)status='configured'
        else if(name==='Lead Reactivation'&&hasProfiles)status='configured'
        else if(name==='Attribution Agent'&&Boolean(attribution?.available)&&(Number(attribution?.matchedEvents||0)>0||Number(attribution?.activeClickSessions||0)>0))status='configured'
        else if(name==='Deep Linking Agent'&&(state.deepLinks||[]).length)status='configured'
        else if(name==='Fraud Detection Agent'&&(state.fraudPatterns||[]).length)status='configured'
        else if(name==='Customer Journey Agent'&&hasProfiles)status='configured'
        else if(name==='Audiences Agent'&&audiences.length)status='configured'
        else if(name==='Event Agent'&&eventRules.length)status='configured'
        else if(name==='Ask Ace')status='available'
        const meta=agentCatalog[name]||{}
        return {id:'builtin_'+i,name,status,type:'built_in',...meta}
      })
      return send(req,res,200,{items:[...builtIn,...(state.customAgents||[])],runs:runs.slice(0,50),configured:builtIn.filter(x=>x.status==='configured').length,custom:(state.customAgents||[]).length})
    }
    if (req.method === 'GET' && url.pathname === '/api/enrich') {
      const [items,stats,runs]=await Promise.all([listLeadProfiles(workspaceId,100),leadOpsStats(workspaceId),listActivationRuns(workspaceId,50)])
      return send(req,res,200,{stats,writebacks:runs.filter(x=>x.kind==='crm_writeback'),items:items.map(x=>({id:x.id,leadId:x.external_lead_id,name:x.name,source:x.source,campaign:x.campaign,stage:x.crm_stage,intent:x.intent,score:x.score,grade:x.grade,drivers:x.score_drivers,attributes:x.attributes,journey:x.journey,callSummary:x.call_summary,whatsappSummary:x.whatsapp_summary,updatedAt:x.updated_at}))})
    }
    if (req.method === 'POST' && url.pathname === '/api/enrich/upsert') {
      const body=await readBody(req)
      const item=await upsertLeadProfile(workspaceId,body)
      if(!item) return send(req,res,503,{error:'lead operations store unavailable'})
      return send(req,res,201,{id:item.id,leadId:item.external_lead_id,name:item.name,score:item.score,grade:item.grade,drivers:item.score_drivers,updatedAt:item.updated_at})
    }
    if (req.method === 'POST' && url.pathname === '/api/enrich/writeback') {
      const body=await readBody(req)
      if(!body.lead || !body.provider) return send(req,res,400,{error:'lead and provider required'})
      const lead=await getLeadProfile(workspaceId,String(body.lead))
      if(!lead) return send(req,res,404,{error:'lead not found'})
      const run=await createActivationRun(workspaceId,{kind:'crm_writeback',entityId:lead.id,provider:String(body.provider),requestSummary:{lead:lead.external_lead_id,grade:lead.grade,score:lead.score}})
      const job=await handleSubmitJob({workspaceId,kind:'crm_writeback',idempotencyKey:'crm:'+run.id,payload:{leadRef:lead.id,provider:String(body.provider),fields:body.fields||{},activationRunId:run.id}})
      return send(req,res,202,{runId:run.id,jobId:job?.id||null,status:'queued',provider:body.provider})
    }
    if (req.method === 'POST' && url.pathname === '/api/lead-grading/score') {
      const body=await readBody(req)
      return send(req,res,200,scoreLead(body))
    }
    if (req.method === 'GET' && url.pathname === '/api/lead-grading') {
      const [items,stats]=await Promise.all([listLeadProfiles(workspaceId,100),leadOpsStats(workspaceId)])
      return send(req,res,200,{version:'v2.0',stats,items:items.map(x=>({id:x.id,lead:x.name||x.external_lead_id,leadId:x.external_lead_id,score:x.score,grade:x.grade,source:x.source,stage:x.crm_stage||'lead',reason:(x.score_drivers||[]).slice(0,3).map(d=>d.label).join(' · '),drivers:x.score_drivers,updatedAt:x.updated_at}))})
    }
    if (req.method === 'POST' && url.pathname === '/api/lead-grading/override') {
      const body=await readBody(req)
      if(!body.lead || !['A','B','C','D'].includes(body.grade)) return send(req,res,400,{error:'lead and grade A-D required'})
      const item=await persistLeadGrade(workspaceId,String(body.lead),String(body.grade))
      return item?send(req,res,200,{lead:item.name||item.external_lead_id,grade:item.grade,score:item.score,overridden:true,auditId:randomUUID(),updatedAt:item.updated_at}):send(req,res,404,{error:'lead not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/lead-grading/activate') {
      const body=await readBody(req)
      if(!body.lead) return send(req,res,400,{error:'lead required'})
      const profiles=await listLeadProfiles(workspaceId,500)
      const lead=profiles.find(x=>x.external_lead_id===body.lead||x.name===body.lead)
      if(!lead) return send(req,res,404,{error:'lead not found'})
      const grade=String(lead.grade||'D').toUpperCase()
      let operation=null
      let nextTab='Audiences'
      let action='suppression_review'
      if(grade==='A'||grade==='B'){
        const destination=grade==='A'?'Priority sales queue':'Sales queue'
        operation=await routeLead(workspaceId,{
          leadRef:lead.external_lead_id,
          score:lead.score,
          source:lead.source||'Lead grading',
          routingRule:{
            name:'Grade '+grade+' activation',
            destination,
            reason:'Lead grading activation · grade '+grade+' · score '+Number(lead.score||0),
            slaSeconds:grade==='A'?120:300
          }
        })
        nextTab='Routing'
        action='routing'
      }else if(grade==='C'){
        operation=await createFollowUp(workspaceId,{
          leadRef:lead.external_lead_id,
          reason:'Lead grading nurture · grade C · score '+Number(lead.score||0),
          channel:'whatsapp',
          priority:'medium',
          delayMinutes:60,
          owner:'Nurture queue'
        })
        nextTab='Follow-ups'
        action='nurture_followup'
      }else{
        operation=await createFollowUp(workspaceId,{
          leadRef:lead.external_lead_id,
          reason:'Review Grade D lead for acquisition suppression',
          channel:'review',
          priority:'low',
          delayMinutes:15,
          owner:'Marketing operations'
        })
        nextTab='Audiences'
        action='suppression_review'
      }
      const now=new Date().toISOString()
      await mutateState(s=>{
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'lead_grade.activated',entityId:lead.id,leadRef:lead.external_lead_id,grade,operationType:action,operationId:operation?.id||null,nextTab,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,202,{
        lead:lead.name||lead.external_lead_id,
        leadId:lead.external_lead_id,
        grade,
        status:'activated',
        action,
        nextTab,
        operation:operation?{id:operation.id,status:operation.status||'open',destination:operation.destination||operation.owner||null,dueAt:operation.due_at||null}:null,
        queuedAt:now
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/behavior') {
      const state=await getState()
      const sourceEvents=(state.recentEvents||[]).length?(state.recentEvents||[]):trackedEvents
      const countBy=(selector)=>{
        const map=new Map()
        for(const event of sourceEvents){
          const key=String(selector(event)||'Unknown').trim()||'Unknown'
          map.set(key,(map.get(key)||0)+1)
        }
        return [...map.entries()].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count)
      }
      const eventCounts=new Map()
      let known=0,highIntent=0,deviceIdentified=0
      for(const event of sourceEvents){
        const name=String(event.event||event.eventType||event.name||'event')
        eventCounts.set(name,(eventCounts.get(name)||0)+1)
        if(event.customerId||event.visitorId||event.deviceId||event.device_id||event.emailSha256||event.email_sha256||event.phoneSha256||event.phone_sha256)known++
        if(event.deviceId||event.device_id)deviceIdentified++
        if(/pricing|checkout|book|consult|apply|purchase|revenue|qualified|enrol|closed_won/i.test(name))highIntent++
      }
      const events=[...eventCounts.entries()].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count)
      const sources=countBy(event=>event.utm_source||event.source||event.channel||'Direct / First-party')
      const campaigns=countBy(event=>event.utm_campaign||event.campaign||'Unattributed campaign')
      const devices=countBy(event=>event.devicePlatform||event.device_platform||event.platform||'Unknown device')
      const total=sourceEvents.length
      return send(req,res,200,{
        events,
        sources,
        campaigns,
        devices,
        stats:{
          events:total,
          knownIdentities:known,
          knownIdentityRate:total?Number((known/total*100).toFixed(1)):0,
          deviceIdentifiedEvents:deviceIdentified,
          deviceIdentityRate:total?Number((deviceIdentified/total*100).toFixed(1)):0,
          highIntentEvents:highIntent,
          highIntentRate:total?Number((highIntent/total*100).toFixed(1)):0
        },
        recent:sourceEvents.slice(0,100),
        persistence:(state.recentEvents||[]).length?'workspace_store':'process_window',
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/feed') {
      const [profiles,state]=await Promise.all([listLeadProfiles(workspaceId,200),getState()])
      const attrs=new Map()
      const add=(key,source,value)=>{if(!key)return;const entry=attrs.get(key)||{key,source,count:0,sample:null,status:'mapped'};entry.count++;if(entry.sample==null&&value!=null&&typeof value!=='object')entry.sample=String(value).slice(0,120);attrs.set(key,entry)}
      for(const p of profiles){
        add('lead_score','model',p.score);add('lead_grade','model',p.grade);add('lifecycle_stage','crm',p.crm_stage);add('device_platform','identity',p.device_platform);add('app_id','identity',p.app_id)
        for(const [k,v] of Object.entries(p.attributes||{}))add(k,'profile',v)
        for(const [k,v] of Object.entries(p.journey||{}))add(k,'journey',v)
      }
      for(const x of state.customFeedAttributes||[])attrs.set(x.key,{...x,status:'mapped'})
      const deliveries=state.signalDeliveries||[]
      const destinations=[...new Set(deliveries.map(x=>x.destination).filter(Boolean))].map(destination=>{const list=deliveries.filter(x=>x.destination===destination);const enriched=list.filter(x=>Object.keys(x.replayPayload?.data||{}).length>0).length;return {destination,total:list.length,enriched,enrichedRate:list.length?Number((enriched/list.length*100).toFixed(1)):0}})
      return send(req,res,200,{attributes:[...attrs.values()],mappings:(state.feedMappings||[]),stats:{activeAttributes:attrs.size,profiles:profiles.length,deliveries:deliveries.length,quarantined:Number((state.quarantinedEvents||[]).length)},destinations})
    }
    if (req.method === 'POST' && url.pathname === '/api/feed/attributes') {
      const body=await readBody(req)
      const key=String(body.key||'').trim()
      if(!/^[A-Za-z][A-Za-z0-9_]{1,63}$/.test(key))return send(req,res,400,{error:'attribute key must be 2-64 alphanumeric/underscore characters'})
      const item={key,source:String(body.source||'custom'),sample:body.sample==null?null:String(body.sample).slice(0,120),status:'mapped',createdAt:new Date().toISOString()}
      await mutateState(s=>{s.customFeedAttributes=s.customFeedAttributes||[];const i=s.customFeedAttributes.findIndex(x=>x.key===key);if(i>=0)s.customFeedAttributes[i]=item;else s.customFeedAttributes.unshift(item);s.customFeedAttributes=s.customFeedAttributes.slice(0,500)})
      return send(req,res,201,item)
    }
    if (req.method === 'POST' && url.pathname === '/api/feed/mappings') {
      const body=await readBody(req)
      const sourceKey=String(body.sourceKey||'').trim()
      const destination=String(body.destination||'').trim()
      const targetKey=String(body.targetKey||'').trim()
      if(!/^[A-Za-z][A-Za-z0-9_]{1,63}$/.test(sourceKey))return send(req,res,400,{error:'sourceKey must be 2-64 alphanumeric/underscore characters'})
      if(!destination||!targetKey)return send(req,res,400,{error:'destination and targetKey are required'})
      const now=new Date().toISOString()
      const item={id:'feedmap_'+randomUUID(),sourceKey,destination:destination.slice(0,120),targetKey:targetKey.slice(0,120),transform:String(body.transform||'copy').slice(0,60),enabled:true,createdAt:now}
      await mutateState(s=>{
        s.feedMappings=s.feedMappings||[]
        const i=s.feedMappings.findIndex(x=>x.sourceKey===sourceKey&&x.destination===item.destination&&x.targetKey===item.targetKey)
        if(i>=0)s.feedMappings[i]={...s.feedMappings[i],...item,id:s.feedMappings[i].id,createdAt:s.feedMappings[i].createdAt,updatedAt:now}
        else s.feedMappings.unshift(item)
        s.feedMappings=s.feedMappings.slice(0,500)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'feed.mapping_saved',entityId:item.id,sourceKey,destination:item.destination,targetKey:item.targetKey,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/feed/mappings/toggle') {
      const body=await readBody(req)
      if(!body.id||typeof body.enabled!=='boolean')return send(req,res,400,{error:'id and enabled required'})
      let updated=null
      await mutateState(s=>{
        const item=(s.feedMappings||[]).find(x=>x.id===body.id)
        if(item){item.enabled=body.enabled;item.updatedAt=new Date().toISOString();updated={...item}}
      })
      return updated?send(req,res,200,{item:updated}):send(req,res,404,{error:'feed mapping not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/feed/preview') {
      const body=await readBody(req)
      const state=await getState()
      const profiles=await listLeadProfiles(workspaceId,20)
      const destination=String(body.destination||'').trim()
      const mappings=(state.feedMappings||[]).filter(x=>x.enabled!==false&&(!destination||x.destination===destination))
      const profile=profiles[0]||null
      const lookup=(key)=>{
        if(!profile)return null
        if(key==='lead_score')return profile.score
        if(key==='lead_grade')return profile.grade
        if(key==='lifecycle_stage')return profile.crm_stage
        if(key==='device_platform')return profile.device_platform
        if(key==='app_id')return profile.app_id
        if(Object.prototype.hasOwnProperty.call(profile.attributes||{},key))return profile.attributes[key]
        if(Object.prototype.hasOwnProperty.call(profile.journey||{},key))return profile.journey[key]
        const custom=(state.customFeedAttributes||[]).find(x=>x.key===key)
        return custom?.sample??null
      }
      const payload={}
      for(const mapping of mappings){
        let value=lookup(mapping.sourceKey)
        if(mapping.transform==='string'&&value!=null)value=String(value)
        if(mapping.transform==='number'&&value!=null&&Number.isFinite(Number(value)))value=Number(value)
        payload[mapping.targetKey]=value
      }
      return send(req,res,200,{destination:destination||null,profileId:profile?.id||null,mappings:mappings.length,payload,generatedAt:new Date().toISOString(),notice:profile?'Preview generated from the latest persisted profile plus custom attribute samples.':'No persisted profile available; custom samples may still appear.'})
    }
    if (req.method === 'GET' && url.pathname === '/api/solutions') return send(req,res,200,{items:['Agency','Lead Generation','Enterprise','Mid Market Brand','Attribution Model','Alerts and Monitoring','Server to Server Integration']})
    if (req.method === 'GET' && url.pathname === '/api/exclusions') {
      const [audiences,stats]=await Promise.all([listLeadAudiences(workspaceId),audienceOpsStats(workspaceId)])
      const suppressions=audiences.filter(x=>String(x.mode||'').toLowerCase()==='suppress')
      const presets=[
        {key:'converted_customers',name:'Converted customers',description:'Exclude customers who already reached a converted/customer stage.',condition:'CRM stage',operator:'is one of',value:'converted,enrolled,closed_won,customer',identityMode:'auto'},
        {key:'low_quality_leads',name:'Low-quality leads',description:'Exclude Grade C/D leads from acquisition optimization or prospecting.',condition:'Lead grade',operator:'is one of',value:'C,D',identityMode:'auto'},
        {key:'device_ids',name:'Known device IDs',description:'Exclude known first-party device IDs to reduce repeat prospecting exposure.',condition:'Device ID present',operator:'is',value:'yes',identityMode:'device'}
      ]
      const previews=[]
      for(const preset of presets){
        const preview=await previewLeadAudience(workspaceId,{name:preset.name,condition:preset.condition,operator:preset.operator,value:preset.value,destination:'Meta Ads, Google Ads',mode:'Suppress',identityMode:preset.identityMode}).catch(()=>({available:false,estimatedSize:0,matchedPercent:0}))
        previews.push({...preset,preview})
      }
      return send(req,res,200,{
        items:suppressions.map(x=>({id:x.id,name:x.name,size:x.matched_size,estimatedSize:x.estimated_size,destination:x.destination,identityMode:x.identity_mode,status:x.status,definition:x.definition,providerState:x.provider_state,lastSyncedAt:x.last_synced_at,lastSyncError:x.last_sync_error})),
        presets:previews,
        stats:{
          total:suppressions.length,
          active:suppressions.filter(x=>['active','ready_for_sync','syncing'].includes(String(x.status||'').toLowerCase())).length,
          suppressedIdentities:Number(stats?.audiences?.suppressedIdentities||0),
          converted:Number(stats?.exclusions?.converted||0),
          lowQuality:Number(stats?.exclusions?.lowQuality||0),
          deviceIds:Number(stats?.exclusions?.deviceIds||0)
        }
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/exclusions/create') {
      const body=await readBody(req)
      const presets={
        converted_customers:{name:'Converted customers',condition:'CRM stage',operator:'is one of',value:'converted,enrolled,closed_won,customer',identityMode:'auto'},
        low_quality_leads:{name:'Low-quality leads',condition:'Lead grade',operator:'is one of',value:'C,D',identityMode:'auto'},
        device_ids:{name:'Known device IDs',condition:'Device ID present',operator:'is',value:'yes',identityMode:'device'}
      }
      const preset=presets[String(body.preset||'')]
      if(!preset) return send(req,res,400,{error:'valid exclusion preset required'})
      const destination=String(body.destination||'Meta Ads, Google Ads').trim()
      if(!destination) return send(req,res,400,{error:'destination required'})
      const existing=(await listLeadAudiences(workspaceId)).find(x=>String(x.mode||'').toLowerCase()==='suppress'&&String(x.name||'')===String(body.name||preset.name)&&String(x.destination||'')===destination)
      if(existing) return send(req,res,200,{duplicate:true,item:{id:existing.id,name:existing.name,status:existing.status,size:existing.matched_size,destination:existing.destination}})
      const item=await createLeadAudience(workspaceId,{name:String(body.name||preset.name),destination,mode:'Suppress',condition:preset.condition,operator:preset.operator,value:preset.value,identityMode:preset.identityMode})
      if(!item) return send(req,res,503,{error:'audience store unavailable'})
      const now=new Date().toISOString()
      await mutateState(s=>{
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'exclusion.created',entityId:item.id,preset:String(body.preset),destination,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{duplicate:false,item:{id:item.id,name:item.name,status:item.status,size:item.matched_size,estimatedSize:item.estimated_size,destination:item.destination,identityMode:item.identity_mode}})
    }
    if (req.method === 'POST' && url.pathname === '/api/audiences/preview') {
      const body=await readBody(req)
      if(!body.name || !body.condition) return send(req,res,400,{error:'name and condition required'})
      const preview=await previewLeadAudience(workspaceId,body)
      return send(req,res,200,preview)
    }
    if (req.method === 'POST' && url.pathname === '/api/audiences') {
      const body=await readBody(req)
      if(!body.name || !body.destination || !body.condition) return send(req,res,400,{error:'name, destination and condition required'})
      const item=await createLeadAudience(workspaceId,body)
      if(!item) return send(req,res,503,{error:'audience store unavailable'})
      await mutateState(s=>{s.audit.unshift({id:randomUUID(),action:'audience.materialized',entityId:item.id,at:new Date().toISOString()});s.audit=s.audit.slice(0,1000)})
      return send(req,res,201,{id:item.id,name:item.name,status:item.status,destination:item.destination,mode:item.mode,size:item.matched_size,estimatedSize:item.estimated_size,createdAt:item.created_at})
    }
    if (req.method === 'POST' && url.pathname === '/api/audiences/materialize') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const result=await materializeAudience(workspaceId,String(body.id))
      return result?send(req,res,200,result):send(req,res,404,{error:'audience not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/audiences/sync') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const bundle=await getAudienceBundle(workspaceId,String(body.id))
      if(!bundle) return send(req,res,404,{error:'audience not found'})
      const configured=String(body.provider||bundle.audience.destination||'').split(/·|,/).map(x=>x.trim()).filter(Boolean)
      const providers=configured.map(x=>x.toLowerCase().includes('meta')?'Meta Ads':x.toLowerCase().includes('google')?'Google Ads':null).filter(Boolean)
      if(!providers.length) return send(req,res,400,{error:'audience destination must include Meta Ads or Google Ads'})
      const queued=[]
      for(const provider of [...new Set(providers)]){
        const key=provider==='Meta Ads'?'meta':'google'
        await updateAudienceSyncState(workspaceId,bundle.audience.id,key,{status:'queued',error:null})
        const run=await createActivationRun(workspaceId,{kind:'audience_sync',entityId:bundle.audience.id,provider,requestSummary:{audience:bundle.audience.name,members:bundle.members.length,mode:bundle.audience.mode}})
        const job=await handleSubmitJob({workspaceId,kind:'audience_sync',idempotencyKey:'audience:'+bundle.audience.id+':'+key+':'+Date.now(),payload:{audienceId:bundle.audience.id,provider,activationRunId:run.id}})
        queued.push({provider,runId:run.id,jobId:job?.id||null})
      }
      return send(req,res,202,{id:bundle.audience.id,status:'syncing',queued})
    }
    if (req.method === 'GET' && url.pathname === '/api/audience-schedules') {
      return send(req,res,200,{items:await listAudienceSchedules(workspaceId),runs:await listAudienceRefreshRuns(workspaceId,null,50)})
    }
    if (req.method === 'POST' && url.pathname === '/api/audience-schedules') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      try{
        const item=await saveAudienceSchedule(workspaceId,String(body.id),body)
        return item?send(req,res,200,item):send(req,res,404,{error:'audience not found'})
      }catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'invalid audience schedule'})}
    }
    if (req.method === 'GET' && url.pathname === '/api/activation-runs') {
      return send(req,res,200,{items:await listActivationRuns(workspaceId,100)})
    }
    if (req.method === 'GET' && url.pathname === '/api/audiences') {
      const [items,schedules,stats]=await Promise.all([listLeadAudiences(workspaceId),listAudienceSchedules(workspaceId),audienceOpsStats(workspaceId)])
      const scheduleById=Object.fromEntries(schedules.map(x=>[x.audience_id,x]))
      return send(req,res,200,{items:items.map(x=>{const s=scheduleById[x.id];return {id:x.id,name:x.name,size:x.matched_size,estimatedSize:x.estimated_size,mode:x.mode,destination:x.destination,identityMode:x.identity_mode,status:x.status,cadence:s?.cadenceLabel||'Manual',schedule:s||null,definition:x.definition,providerState:x.provider_state,lastSyncError:x.last_sync_error,lastSyncedAt:x.last_synced_at,lastMaterializedAt:x.last_materialized_at}}),stats})
    }
    if (req.method === 'GET' && url.pathname === '/api/alerts') return send(req,res,200,{items:await listLiveAlerts(workspaceId)})
    if (req.method === 'POST' && url.pathname === '/api/alerts/resolve') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const item=await resolveLiveAlert(workspaceId,String(body.id))
      return item?send(req,res,200,item):send(req,res,404,{error:'alert not found'})
    }
    if (req.method === 'GET' && url.pathname === '/api/chatgpt-ads') {
      const state=await getState()
      const deliveries=(state.signalDeliveries||[]).filter(x=>/chatgpt|openai/i.test(String(x.destination||'')))
      const recent=(state.recentEvents||[]).slice(0,500)
      const withOppref=recent.filter(x=>Boolean(x.oppref||x.openaiClickRef)).length
      const terminal=deliveries.filter(x=>['delivered','succeeded','failed','dead_letter'].includes(String(x.status||'').toLowerCase()))
      const delivered=terminal.filter(x=>['delivered','succeeded'].includes(String(x.status||'').toLowerCase())).length
      return send(req,res,200,{
        configured:Boolean(process.env.OPENAI_CONVERSIONS_API_KEY&&process.env.OPENAI_ADS_PIXEL_ID),
        pixelConfigured:Boolean(process.env.OPENAI_ADS_PIXEL_ID),
        conversionsKeyConfigured:Boolean(process.env.OPENAI_CONVERSIONS_API_KEY),
        supportedEventTypes:['appointment_scheduled','checkout_started','contents_viewed','custom','items_added','lead_created','order_created','page_viewed','registration_completed','subscription_created','trial_started','app_installed','app_opened'],
        deliveries:{total:deliveries.length,delivered,failed:terminal.length-delivered,queued:deliveries.filter(x=>['queued','retrying'].includes(String(x.status||'').toLowerCase())).length,deliveryRate:terminal.length?Number((delivered/terminal.length*100).toFixed(1)):null,recent:deliveries.slice(0,25)},
        matching:{recentEvents:recent.length,opprefEvents:withOppref,opprefCoverage:recent.length?Number((withOppref/recent.length*100).toFixed(1)):0},
        requiredEnvironment:['OPENAI_CONVERSIONS_API_KEY','OPENAI_ADS_PIXEL_ID'],
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/chatgpt-ads/validate') {
      const body=await readBody(req)
      const candidate={...body,destination:'ChatGPT Ads',event:String(body.event||'lead_created'),actionSource:body.actionSource||'web'}
      const error=validateSignalDispatch(candidate)
      if(error) return send(req,res,400,{valid:false,error})
      const allowedTypes=new Set(['appointment_scheduled','checkout_started','contents_viewed','custom','items_added','lead_created','order_created','page_viewed','registration_completed','subscription_created','trial_started','app_installed','app_opened'])
      if(body.openaiEventType&&!allowedTypes.has(String(body.openaiEventType))) return send(req,res,400,{valid:false,error:'unsupported ChatGPT Ads event type'})
      return send(req,res,200,{valid:true,configured:Boolean(process.env.OPENAI_CONVERSIONS_API_KEY&&process.env.OPENAI_ADS_PIXEL_ID),payload:buildSignalReplayPayload(candidate,{id:'validation_only',idempotencyKey:'validation_only'}),notice:'Local payload validation only; no provider request was sent.'})
    }
    if (req.method === 'POST' && url.pathname === '/api/chatgpt-ads/send') {
      const body=await readBody(req)
      if(!queueAvailable()) return send(req,res,503,{error:'signal delivery queue unavailable',required:'DATABASE_URL'})
      const candidate={...body,destination:'ChatGPT Ads'}
      const validationError=validateSignalDispatch(candidate)
      if(validationError) return send(req,res,400,{error:validationError})
      if(body.customerId||body.visitorId){
        const consent=await consentAllows(workspaceId,{subjectType:body.customerId?'customer':'visitor',subjectId:body.customerId||body.visitorId,category:'marketing'})
        if(!consent.allowed) return send(req,res,403,{error:'marketing consent required',reason:consent.reason})
      }
      const rawKey=String(body.idempotencyKey||JSON.stringify([body.event,body.customerId||'',body.externalEventId||'',body.occurredAt||'',body.oppref||'']))
      const idempotencyKey=createHash('sha256').update('chatgpt-ads:'+rawKey).digest('hex')
      const state=await getState()
      const existing=(state.signalDeliveries||[]).find(x=>x.idempotencyKey===idempotencyKey)
      if(existing) return send(req,res,200,{duplicate:true,item:existing})
      const now=new Date().toISOString()
      const item={id:'sig_'+randomUUID(),event:String(body.event),destination:'ChatGPT Ads',customerId:body.customerId?String(body.customerId):null,externalEventId:body.externalEventId?String(body.externalEventId):null,status:'queued',attempts:0,idempotencyKey,createdAt:now,updatedAt:now,nextAttemptAt:now}
      item.replayPayload=buildSignalReplayPayload(candidate,{...item,idempotencyKey})
      await mutateState(s=>{
        s.signalDeliveries=s.signalDeliveries||[]
        s.signalDeliveries.unshift(item)
        s.signalDeliveries=s.signalDeliveries.slice(0,10000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'chatgpt_ads.signal_queued',entityId:item.id,event:item.event,oppref:Boolean(body.oppref),at:now})
        s.audit=s.audit.slice(0,1000)
      })
      const job=await handleSubmitJob({workspaceId,kind:'signal_delivery',idempotencyKey:'chatgpt-ads:'+idempotencyKey,payload:item.replayPayload})
      return send(req,res,202,{duplicate:false,item,job:job?{id:job.id,status:job.status}:null})
    }
    if (req.method === 'GET' && url.pathname === '/api/signal-deliveries') {
      const state=await getState()
      const items=(state.signalDeliveries||[]).slice().sort((a,b)=>String(b.updatedAt||b.createdAt).localeCompare(String(a.updatedAt||a.createdAt)))
      const summary={
        total:items.length,
        delivered:items.filter(x=>x.status==='delivered').length,
        retrying:items.filter(x=>x.status==='retrying'||x.status==='queued').length,
        deadLetter:items.filter(x=>x.status==='dead_letter').length
      }
      return send(req,res,200,{summary,items})
    }
    if (req.method === 'POST' && url.pathname === '/api/signal-deliveries/dispatch') {
      const body=await readBody(req)
      const validationError=validateSignalDispatch(body)
      if(validationError) return send(req,res,400,{error:validationError})
      if(String(body.destination||'').toLowerCase().includes('webhook')&&body.webhookUrl){
        try{
          const validatedWebhook=await validateOutboundDestination(body.webhookUrl,{
            allowHttp:!IS_PROD&&process.env.CUSTOM_INTEGRATION_ALLOW_HTTP==='true',
            purpose:'webhook destination'
          })
          body.webhookUrl=validatedWebhook.url.toString()
        }catch(error){
          return send(req,res,400,{error:error instanceof Error?error.message:'invalid webhook URL',code:error?.code||'invalid_webhook_destination'})
        }
      }
      if(!queueAvailable()) return send(req,res,503,{error:'signal delivery queue unavailable',required:'DATABASE_URL'})
      if(body.customerId||body.visitorId){
        const consent=await consentAllows(workspaceId,{subjectType:body.customerId?'customer':'visitor',subjectId:body.customerId||body.visitorId,category:'marketing'})
        if(!consent.allowed) return send(req,res,403,{error:'marketing consent required',reason:consent.reason})
      }
      const rawKey=String(body.idempotencyKey||JSON.stringify([body.event,body.destination,body.customerId||'',body.externalEventId||'',body.occurredAt||'']))
      const idempotencyKey=createHash('sha256').update(rawKey).digest('hex')
      const state=await getState()
      const existing=(state.signalDeliveries||[]).find(x=>x.idempotencyKey===idempotencyKey)
      if(existing) return send(req,res,200,{duplicate:true,item:existing})
      const now=new Date().toISOString()
      const item={
        id:'sig_'+randomUUID(),
        event:String(body.event),
        destination:String(body.destination),
        customerId:body.customerId?String(body.customerId):null,
        externalEventId:body.externalEventId?String(body.externalEventId):null,
        status:'queued',
        attempts:0,
        idempotencyKey,
        createdAt:now,
        updatedAt:now,
        nextAttemptAt:now
      }
      item.replayPayload=buildSignalReplayPayload(body,{...item,idempotencyKey})
      await mutateState(s=>{
        s.signalDeliveries=s.signalDeliveries||[]
        s.signalDeliveries.unshift(item)
        s.signalDeliveries=s.signalDeliveries.slice(0,10000)
        s.audit.unshift({id:randomUUID(),action:'signal.queued',entityId:item.id,destination:item.destination,event:item.event,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      const job=await handleSubmitJob({
        workspaceId,
        kind:'signal_delivery',
        idempotencyKey:'signal:'+idempotencyKey,
        payload:item.replayPayload
      })
      return send(req,res,202,{duplicate:false,item,job:job?{id:job.id,status:job.status}:null})
    }
    if (req.method === 'POST' && url.pathname === '/api/signal-deliveries/retry') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      if(!queueAvailable()) return send(req,res,503,{error:'signal delivery queue unavailable',required:'DATABASE_URL'})
      let updated=null
      const now=new Date().toISOString()
      await mutateState(s=>{
        const item=(s.signalDeliveries||[]).find(x=>x.id===body.id)
        if(item){
          item.status='queued'
          item.nextAttemptAt=now
          item.updatedAt=now
          item.lastError=null
          updated={...item}
        }
        s.audit.unshift({id:randomUUID(),action:'signal.retry_queued',entityId:String(body.id),at:now})
        s.audit=s.audit.slice(0,1000)
      })
      if(updated){
        const replayPayload=updated.replayPayload||buildSignalReplayPayload(updated,updated)
        await handleSubmitJob({
          workspaceId,
          kind:'signal_delivery',
          idempotencyKey:'retry:'+updated.id+':'+Date.now(),
          payload:{...replayPayload,deliveryId:updated.id,event:updated.event,destination:updated.destination,idempotencyKey:updated.idempotencyKey}
        })
        return send(req,res,202,updated)
      }
      return send(req,res,404,{error:'delivery not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/signal-deliveries/replay-dlq') {
      if(!queueAvailable()) return send(req,res,503,{error:'signal delivery queue unavailable',required:'DATABASE_URL'})
      const now=new Date().toISOString()
      const replayItems=[]
      await mutateState(s=>{
        for(const item of (s.signalDeliveries||[])){
          if(item.status==='dead_letter'){
            item.status='queued'
            item.nextAttemptAt=now
            item.updatedAt=now
            item.lastError=null
            replayItems.push({...item})
          }
        }
        s.audit.unshift({id:randomUUID(),action:'signal.dlq_replayed',count:replayItems.length,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      const jobs=[]
      for(const item of replayItems){
        const replayPayload=item.replayPayload||buildSignalReplayPayload(item,item)
        const job=await handleSubmitJob({
          workspaceId,
          kind:'signal_delivery',
          idempotencyKey:'dlq-replay:'+item.id+':'+Date.now(),
          payload:{...replayPayload,deliveryId:item.id,event:item.event,destination:item.destination,idempotencyKey:item.idempotencyKey}
        })
        jobs.push(job?.id||null)
      }
      return send(req,res,202,{replayed:replayItems.length,jobs:jobs.filter(Boolean),queuedAt:now})
    }
    if (req.method === 'GET' && url.pathname === '/api/connector-health') {
      const state=await getState()
      const jobs=await queueStats(workspaceId)
      return send(req,res,200,{items:state.connectorHealth||[],jobs,checkedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/webhooks/deliveries') {
      const state=await getState()
      return send(req,res,200,{items:(state.webhookDeliveries||[]).slice(0,250),endpoints:(state.webhookEndpoints||[]).slice(0,100)})
    }
    if (req.method === 'GET' && url.pathname === '/api/webhooks/endpoints') {
      const state=await getState()
      return send(req,res,200,{items:(state.webhookEndpoints||[]).slice(0,100)})
    }
    if (req.method === 'POST' && url.pathname === '/api/webhooks/endpoints') {
      const body=await readBody(req)
      const event=String(body.event||'').trim()
      const target=String(body.url||'').trim()
      if(!event||!target) return send(req,res,400,{error:'event and url required'})
      let validatedTarget
      try{
        validatedTarget=await validateOutboundDestination(target,{
          allowHttp:!IS_PROD&&process.env.CUSTOM_INTEGRATION_ALLOW_HTTP==='true',
          purpose:'webhook destination'
        })
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'invalid webhook URL',code:error?.code||'invalid_webhook_destination'})
      }
      const now=new Date().toISOString()
      const item={id:'wh_'+randomUUID(),event,url:validatedTarget.url.toString(),status:'active',createdAt:now,updatedAt:now}
      await mutateState(s=>{
        s.webhookEndpoints=s.webhookEndpoints||[]
        s.webhookEndpoints.unshift(item)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'webhook.endpoint_created',entityId:item.id,event:item.event,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,item)
    }
    if (req.method === 'POST' && url.pathname === '/api/webhooks/retry') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      let item=null
      const now=new Date().toISOString()
      await mutateState(s=>{
        const delivery=(s.webhookDeliveries||[]).find(x=>x.id===body.id)
        if(delivery){
          delivery.status='queued'
          delivery.updatedAt=now
          delivery.attempts=Number(delivery.attempts||0)+1
          delivery.lastError=null
          item={...delivery}
        }
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'webhook.retry_queued',entityId:String(body.id),at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return item?send(req,res,202,item):send(req,res,404,{error:'webhook delivery not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/webhooks/secret/rotate') {
      const secret='whsec_'+randomUUID().replaceAll('-','')+randomBytes(8).toString('hex')
      const fingerprint=createHash('sha256').update(secret).digest('hex')
      const createdAt=new Date().toISOString()
      await mutateState(s=>{
        s.webhookSigningSecret={fingerprint,createdAt}
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'webhook.secret_rotated',entityId:fingerprint.slice(0,12),at:createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{secret,createdAt,notice:'Store this secret now; only its SHA-256 fingerprint is persisted.'})
    }
    if (req.method === 'GET' && url.pathname === '/api/compliance-center') {
      const [consent,consentAudit,privacyRequests,state]=await Promise.all([
        consentStats(workspaceId),
        listConsentAudit(workspaceId,100),
        listPrivacyRequests(workspaceId,100),
        getState()
      ])
      const policy=retentionPolicy()
      const total=Number(consent?.total||0)
      const pct=value=>total?Number((Number(value||0)/total*100).toFixed(1)):0
      const recentPrivacy=privacyRequests.slice(0,20)
      const deletionRequests=privacyRequests.filter(x=>x.request_type==='delete').length
      const exportRequests=privacyRequests.filter(x=>x.request_type==='export').length
      const retentionRuns=privacyRequests.filter(x=>x.request_type==='retention_purge').length
      const blockedPersonalization=(state.personalizationDecisions||[]).filter(x=>x.status==='consent_blocked').length
      const skippedActivation=(state.activationRuleRuns||[]).filter(x=>x.status==='skipped'&&String(x.detail||'').toLowerCase().includes('consent')).length
      const marketingGuarded=(state.signalDeliveries||[]).length
      const retentionConfigured=Object.values(policy).some(days=>Number(days)>0)
      const readinessChecks=[
        {key:'consent_store',label:'Consent records',ready:total>0,detail:total+' subjects recorded'},
        {key:'audit_trail',label:'Consent audit trail',ready:consentAudit.length>0,detail:consentAudit.length+' recent audit entries'},
        {key:'privacy_ops',label:'Subject request operations',ready:true,detail:'Export and delete workflows enabled for owners/admins'},
        {key:'retention',label:'Retention policy',ready:retentionConfigured,detail:retentionConfigured?'Retention windows configured':'Set PRIVACY_RETENTION_*_DAYS in production'},
        {key:'activation_guard',label:'Activation consent guard',ready:true,detail:skippedActivation+' activation actions blocked by consent'},
        {key:'personalization_guard',label:'Personalization consent guard',ready:true,detail:blockedPersonalization+' personalization decisions blocked'}
      ]
      const readiness=Math.round(readinessChecks.filter(x=>x.ready).length/readinessChecks.length*100)
      return send(req,res,200,{
        readiness,
        consent:{
          total,
          analytics:Number(consent?.analytics||0),
          marketing:Number(consent?.marketing||0),
          personalization:Number(consent?.personalization||0),
          revoked:Number(consent?.revoked||0),
          analyticsRate:pct(consent?.analytics),
          marketingRate:pct(consent?.marketing),
          personalizationRate:pct(consent?.personalization)
        },
        policy,
        privacy:{
          totalRequests:privacyRequests.length,
          exports:exportRequests,
          deletions:deletionRequests,
          retentionRuns,
          recent:recentPrivacy
        },
        guards:{
          skippedActivation,
          blockedPersonalization,
          signalDeliveries:marketingGuarded
        },
        checks:readinessChecks,
        consentAudit:consentAudit.slice(0,50),
        generatedAt:new Date().toISOString()
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/consent/stats') return send(req,res,200,{stats:await consentStats(workspaceId),audit:await listConsentAudit(workspaceId,50)})
    if (req.method === 'GET' && url.pathname === '/api/privacy/requests') {
      if(!['owner','admin'].includes(req.user?.role||'')) return send(req,res,403,{error:'owner or admin role required'})
      return send(req,res,200,{policy:retentionPolicy(),items:await listPrivacyRequests(workspaceId,100)})
    }
    if (req.method === 'POST' && url.pathname === '/api/privacy/export') {
      if(!['owner','admin'].includes(req.user?.role||'')) return send(req,res,403,{error:'owner or admin role required'})
      const body=await readBody(req)
      try{return send(req,res,200,await exportSubject(workspaceId,body,req.user?.email||req.user?.userId||null))}
      catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'privacy export failed'})}
    }
    if (req.method === 'POST' && url.pathname === '/api/privacy/delete') {
      if(!['owner','admin'].includes(req.user?.role||'')) return send(req,res,403,{error:'owner or admin role required'})
      const body=await readBody(req)
      try{return send(req,res,200,await deleteSubject(workspaceId,body,req.user?.email||req.user?.userId||null))}
      catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'privacy deletion failed'})}
    }
    if (req.method === 'POST' && url.pathname === '/api/privacy/retention/purge') {
      if(!['owner','admin'].includes(req.user?.role||'')) return send(req,res,403,{error:'owner or admin role required'})
      const body=await readBody(req)
      try{return send(req,res,200,await purgeRetention(workspaceId,{dryRun:body.dryRun!==false,requestedBy:req.user?.email||req.user?.userId||null}))}
      catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'retention purge failed'})}
    }
    if (req.method === 'GET' && url.pathname === '/api/monitoring') return send(req,res,200,await monitoringSnapshot(workspaceId))
    if (req.method === 'GET' && url.pathname === '/api/billing/usage') return send(req,res,200,await handleEvaluateEntitlement({workspaceId}))
    if (req.method === 'GET' && url.pathname === '/api/billing/subscription') {
      const summary=await handleEvaluateEntitlement({workspaceId})
      return send(req,res,200,{...summary,providerConfigured:billingConfigured(),events:await billingEventHistory(workspaceId,20),reconciliation:await billingReconciliationHistory(workspaceId,20)})
    }
    if (req.method === 'POST' && url.pathname === '/api/billing/checkout') {
      if(req.user?.role!=='owner') return send(req,res,403,{error:'owner role required'})
      const body=await readBody(req)
      if(!body.planCode) return send(req,res,400,{error:'planCode required'})
      try{return send(req,res,201,await createCheckoutSession(workspaceId,body))}
      catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'checkout creation failed'})}
    }
    if (req.method === 'POST' && url.pathname === '/api/billing/portal') {
      if(req.user?.role!=='owner') return send(req,res,403,{error:'owner role required'})
      try{return send(req,res,201,await createPortalSession(workspaceId))}
      catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'billing portal unavailable'})}
    }
    if (req.method === 'POST' && url.pathname === '/api/billing/entitlements') {
      if(req.user?.role!=='owner') return send(req,res,403,{error:'owner role required'})
      const body=await readBody(req)
      try{
        await handleChangeSubscription({workspaceId,input:body})
        return send(req,res,200,await subscriptionSummary(workspaceId))
      }catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'invalid entitlements'})}
    }
    if (req.method === 'GET' && url.pathname === '/api/signal-console') {
      const [state,jobs]=await Promise.all([getState(),queueStats(workspaceId)])
      const deliveries=(state.signalDeliveries||[]).slice()
      const aggregate=provider=>{
        const selected=deliveries.filter(x=>String(x.destination||'').toLowerCase().includes(provider))
        const grouped=new Map()
        for(const item of selected){
          const key=String(item.event||'Unknown')
          const row=grouped.get(key)||{event:key,total:0,delivered:0,retrying:0,deadLetter:0,latencyMs:[]}
          row.total+=1
          if(item.status==='delivered') row.delivered+=1
          if(item.status==='queued'||item.status==='retrying') row.retrying+=1
          if(item.status==='dead_letter') row.deadLetter+=1
          if(Number.isFinite(Number(item.latencyMs))) row.latencyMs.push(Number(item.latencyMs))
          grouped.set(key,row)
        }
        return [...grouped.values()].map(row=>({
          event:row.event,
          total:row.total,
          delivered:row.delivered,
          retrying:row.retrying,
          deadLetter:row.deadLetter,
          deliveryRate:row.total?Number((row.delivered/row.total*100).toFixed(2)):0,
          averageLatencyMs:row.latencyMs.length?Math.round(row.latencyMs.reduce((a,b)=>a+b,0)/row.latencyMs.length):null
        })).sort((a,b)=>b.total-a.total)
      }
      return send(req,res,200,{
        generatedAt:new Date().toISOString(),
        queue:jobs,
        summary:{
          total:deliveries.length,
          delivered:deliveries.filter(x=>x.status==='delivered').length,
          retrying:deliveries.filter(x=>x.status==='queued'||x.status==='retrying').length,
          deadLetter:deliveries.filter(x=>x.status==='dead_letter').length
        },
        google:aggregate('google'),
        meta:aggregate('meta'),
        webhook:aggregate('webhook'),
        recent:deliveries.sort((a,b)=>String(b.updatedAt||b.createdAt).localeCompare(String(a.updatedAt||a.createdAt))).slice(0,25)
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/resources') return send(req,res,200,{items:['Custom Events','Server-Side Activation','Attribution','CRM Enrichment','Offline Conversion Tracking','Audience Operations']})
    if (req.method === 'GET' && url.pathname === '/api/ai-action') return send(req,res,200,{steps:[
      {step:1,agent:'Lead Grading',action:'score_intent'},
      {step:2,agent:'CRM Enrichment',action:'assemble_context'},
      {step:3,agent:'Voice Lead Qualification',action:'qualify'},
      {step:4,agent:'Voice Scheduler',action:'schedule'},
      {step:5,agent:'Meeting Reminder',action:'remind'},
      {step:6,agent:'Signal Return',action:'match_and_activate'}
    ]})
    if (req.method === 'GET' && url.pathname === '/api/source-notes') return send(req,res,200,{notes:[
      {topic:'Shopify support',publicSite:'Current demo page says ecommerce Shopify is unsupported',brochure:'Shopify appears in integration list',aceMarketing:'planned_connector_with_source_conflict_label'}
    ]})
    if (req.method === 'GET' && url.pathname === '/api/case-studies') return send(req,res,200,{items:[
      {name:'Apollo Ayurvaid',sector:'Healthcare',pattern:'Call + WhatsApp attribution'},
      {name:'Jaro Education',sector:'EdTech',pattern:'High-volume OCI/ECL'},
      {name:'GemPundit',sector:'High AOV',pattern:'WhatsApp + partial payment'},
      {name:'Berger Paints',sector:'Home Services',pattern:'CAPI + CTWA quality optimization'}
    ]})
    if (req.method === 'GET' && url.pathname === '/api/event-templates') return send(req,res,200,{items:['Pricing-page Lead','High-value Purchase','Prepaid Order','Fulfilled Order','Returned Order','Partial Payment']})
    if (req.method === 'POST' && url.pathname === '/api/consent-preferences') {
      const body = await readBody(req)
      const preferences={necessary:true,analytics:Boolean(body.analytics),advertising:Boolean(body.advertising),functionality:Boolean(body.functionality)}
      const savedAt=new Date().toISOString()
      await mutateState(s=>{
        s.publicConsentPreferences=s.publicConsentPreferences||[]
        s.publicConsentPreferences.unshift({id:randomUUID(),preferences,savedAt,source:'public_cookie_banner'})
        s.publicConsentPreferences=s.publicConsentPreferences.slice(0,5000)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'public.consent_saved',entityId:'cookie_preferences',preferences,savedAt,at:savedAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,{saved:true,preferences,savedAt})
    }
    if (req.method === 'GET' && url.pathname === '/api/monitoring-rules') return send(req,res,200,{items:await listLiveMonitoringRules(workspaceId)})
    if (req.method === 'POST' && url.pathname === '/api/monitoring-rules') {
      const body=await readBody(req)
      try{return send(req,res,201,await saveMonitoringRule(workspaceId,body))}
      catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'invalid monitoring rule'})}
    }
    if (req.method === 'GET' && url.pathname === '/api/security-posture') return send(req,res,200,{controls:[
      {name:'ISO 27001',status:'roadmap'},
      {name:'SHA-256 hashing',status:'design_implemented'},
      {name:'GDPR',status:'roadmap'},
      {name:'HIPAA',status:'roadmap'},
      {name:'India DPDP',status:'roadmap'}
    ]})
    if (req.method === 'GET' && url.pathname === '/api/launchpad') {
      const state=await getState()
      const safe=async(fn,fallback)=>{try{return await fn()}catch{return fallback}}
      const [leadStats,attr,audiences,queue,eventRules,agentRuns]=await Promise.all([
        safe(()=>leadOpsStats(workspaceId),{available:false,total:0}),
        safe(()=>attributionStats(workspaceId),{available:false,matchedEvents:0,activeClickSessions:0}),
        safe(()=>audienceOpsStats(workspaceId),{available:false,audiences:{total:0}}),
        safe(()=>queueStats(workspaceId),{backend:'disabled',pending:0,retry:0,deadLetter:0}),
        safe(()=>listEventRules(workspaceId),[]),
        safe(()=>listAgentRuns(workspaceId),[])
      ])
      const settings=state.workspaceSettings||{}
      const connectors=state.connectorConnections||[]
      const connected=connectors.filter(x=>['connected','healthy','active'].includes(String(x.status||'').toLowerCase()))
      const tracked=trackedEvents.length
      const deliveries=state.signalDeliveries||[]
      const steps=[
        {key:'workspace',title:'Workspace',ready:Boolean(settings.organization||settings.primaryDomain||state.launchpad?.workspaceConfigured),detail:settings.organization||'Workspace profile not completed',tab:'Settings'},
        {key:'connect',title:'Connect data',ready:connected.length>0,detail:connected.length+' connected system(s)',tab:'Integrations'},
        {key:'funnel',title:'Map funnel',ready:Number(leadStats?.total||0)>0||Boolean(state.launchpad?.funnelConfigured),detail:Number(leadStats?.total||0)+' lead profile(s)',tab:'Funnel'},
        {key:'tracking',title:'Install tracking',ready:tracked>0||Boolean(settings.primaryDomain),detail:tracked+' tracked event(s)',tab:'Sites'},
        {key:'signal',title:'Test signal',ready:deliveries.length>0||eventRules.length>0,detail:eventRules.length+' event rule(s) · '+deliveries.length+' delivery record(s)',tab:'Delivery'},
        {key:'agents',title:'Activate agents',ready:agentRuns.length>0||Boolean((state.customAgents||[]).length),detail:agentRuns.length+' run(s) · '+(state.customAgents||[]).length+' custom agent(s)',tab:'Agents'}
      ]
      return send(req,res,200,{
        ...(state.launchpad||{}),
        readiness:Math.round(steps.filter(x=>x.ready).length/steps.length*100),
        steps,
        evidence:{
          connectedConnectors:connected.length,
          trackedEvents:tracked,
          profiles:Number(leadStats?.total||0),
          activeClickSessions:Number(attr?.activeClickSessions||0),
          matchedEvents:Number(attr?.matchedEvents||0),
          audiences:Number(audiences?.audiences?.total||0),
          eventRules:eventRules.length,
          deliveries:deliveries.length,
          queue
        }
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/launchpad') {
      const body=await readBody(req)
      const updatedAt=new Date().toISOString()
      await mutateState(s=>{
        s.launchpad={...(s.launchpad||{}),...body,updatedAt}
        s.audit.unshift({id:randomUUID(),action:'launchpad.updated',entityId:'workspace',at:updatedAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,{saved:true,updatedAt})
    }
    if (req.method === 'GET' && url.pathname === '/api/identity') {
      const [profiles,attr]=await Promise.all([listLeadProfiles(workspaceId,500),attributionStats(workspaceId).catch(()=>({available:false}))])
      const idCount=lead=>[lead.external_lead_id,lead.email_sha256,lead.phone_sha256,lead.device_id].filter(Boolean).length
      const stitched=profiles.filter(lead=>idCount(lead)>=2)
      const identifiers=[
        profiles.some(x=>x.external_lead_id)?'customer_id':null,
        profiles.some(x=>x.email_sha256)?'email_sha256':null,
        profiles.some(x=>x.phone_sha256)?'phone_sha256':null,
        profiles.some(x=>x.device_id)?'device_id':null,
        Number(attr?.clickIdCoverage?.gclid||0)>0?'gclid':null,
        Number(attr?.clickIdCoverage?.fbclid||0)>0?'fbclid':null,
        Number(attr?.clickIdCoverage?.braid||0)>0?'gbraid/wbraid':null
      ].filter(Boolean)
      const recent=profiles.slice(0,50).map(lead=>({
        id:lead.external_lead_id||lead.id,
        name:lead.name||lead.external_lead_id||'Anonymous profile',
        identifierCount:idCount(lead),
        touchpoints:Math.max(0,Number(lead.journey?.journeyDepth||0))+Number(lead.journey?.pricingPageViews||0)+(lead.journey?.whatsappEngaged?1:0)+(lead.journey?.callOutcome?1:0)+(lead.journey?.meetingStatus?1:0),
        confidence:idCount(lead)>=3?'High':idCount(lead)>=2?'Medium':'Single-key',
        identifiers:{
          customerId:Boolean(lead.external_lead_id),
          email:Boolean(lead.email_sha256),
          phone:Boolean(lead.phone_sha256),
          device:Boolean(lead.device_id)
        }
      }))
      const total=profiles.length
      const deterministicRate=total?Number((stitched.length/total*100).toFixed(1)):null
      return send(req,res,200,{
        available:true,
        profiles:total,
        stitchedProfiles:stitched.length,
        deterministicMatchRate:deterministicRate,
        clickCoverage:attr?.clickIdCoverage||{},
        identifiers,
        rules:[
          {priority:1,key:'customer_id',mode:'exact'},
          {priority:2,key:'email_sha256',mode:'exact'},
          {priority:3,key:'phone_sha256',mode:'exact'},
          {priority:4,key:'device_id',mode:'supporting'},
          {priority:5,key:'click_id + session',mode:'deterministic'}
        ],
        recent
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/metrics/catalog') {
      return send(req,res,200,metricCatalog())
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/datasets') {
      const task=String(url.searchParams.get('task')||'').trim()||null
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||50),200))
      const items=await listAiDatasets({workspaceId,task,limit}).catch(()=>[])
      return send(req,res,200,{items,task,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/datasets') {
      const body=await readBody(req)
      try{
        const item=await createAiDataset({
          workspaceId,
          task:String(body.task||''),
          rows:body.rows,
          schemaVersion:String(body.schemaVersion||'point-in-time.v1'),
          featureDefinitionVersion:String(body.featureDefinitionVersion||'features.v1'),
          labelDefinitionVersion:String(body.labelDefinitionVersion||'labels.v1'),
          labelObservationCutoff:body.labelObservationCutoff,
          sourceSnapshot:body.sourceSnapshot&&typeof body.sourceSnapshot==='object'?body.sourceSnapshot:{},
          createdBy:authenticatedUser?.userId||null
        })
        return send(req,res,201,{item})
      }catch(error){
        return send(req,res,422,{error:error instanceof Error?error.message:'dataset could not be created'})
      }
    }
    if (req.method === 'GET' && /^\/api\/ai\/datasets\/[^/]+$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/')[4]||'')
      const item=await getAiDataset({workspaceId,id,includeRows:false}).catch(()=>null)
      return item?send(req,res,200,{item}):send(req,res,404,{error:'dataset not found'})
    }
    if (req.method === 'POST' && /^\/api\/ai\/datasets\/[^/]+\/retire$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const id=decodeURIComponent(url.pathname.split('/')[4]||'')
      const item=await retireAiDataset({workspaceId,id})
      return item?send(req,res,200,{item}):send(req,res,404,{error:'dataset not found'})
    }
    if (req.method === 'POST' && /^\/api\/ai\/datasets\/[^/]+\/train$/.test(url.pathname)) {
      if(!mlServiceConfigured())return send(req,res,503,{error:'ML service is not configured'})
      const id=decodeURIComponent(url.pathname.split('/')[4]||'')
      const body=await readBody(req)
      try{
        const dataset=await getAiDataset({workspaceId,id,includeRows:false})
        if(!dataset)return send(req,res,404,{error:'dataset not found'})
        const task=String(dataset.task||'')
        const datasetAdmission=await evaluateAiTaskAdmission({workspaceId,task,requestedModel:modelRegistryItem(task)?.requestedModel||task,reservedUnits:1})
        if(!datasetAdmission.allowed)return send(req,res,429,{error:'training task is blocked by tenant policy',prerequisites:datasetAdmission.reasons,policy:datasetAdmission.policy,usage:datasetAdmission.usage})
        const request=task==='future_customer_value'
          ?await trainingRequestFromDatasetWithHorizon({
            workspaceId,id,horizon:String(body.horizon||''),randomSeed:Number(body.randomSeed||42),categoricalFeatures:body.categoricalFeatures||[]
          })
          :await trainingRequestFromDataset({
            workspaceId,id,randomSeed:Number(body.randomSeed||42),calibrationMethod:String(body.calibrationMethod||'sigmoid'),categoricalFeatures:body.categoricalFeatures||[]
          })
        const operation=task==='future_customer_value'?'regression_train':'classification_train'
        const requestKey=String(req.headers['idempotency-key']||req.requestId||randomUUID())
        const deadlineAt=new Date(Date.now()+Number(process.env.ML_JOB_DEADLINE_MS||15*60*1000)).toISOString()
        const job=await handleSubmitJob({
          workspaceId,
          kind:'ml_task',
          payload:{operation,task,request},
          idempotencyKey:'ml:dataset:'+id+':'+requestKey,
          maxAttempts:Number(process.env.ML_JOB_MAX_ATTEMPTS||2),
          deadlineAt,
          inputSnapshot:{
            schemaVersion:'ml-dataset-input.v1',
            task,operation,datasetId:id,datasetHash:dataset.content_hash,
            featureSchemaVersion:dataset.feature_definition_version,
            labelSchemaVersion:dataset.label_definition_version,
            capturedAt:new Date().toISOString(),
            actor:authenticatedUser?{userId:authenticatedUser.userId||null,role:authenticatedUser.role||null}:null
          },
          resultSchemaVersion:'ml-result.v1',
          aiUsageReservation:{task,provider:'local_ml',requestedModel:task,reservedUnits:1},
          outboxEvent:{eventType:'ai.job.accepted',schemaVersion:'ai-job-event.v1',payload:{task,operation,datasetId:id}}
        })
        if(!job)return send(req,res,503,{error:'durable queue requires DATABASE_URL'})
        return send(req,res,202,{jobId:job.id,status:job.status,task,operation,datasetId:id,deadlineAt:job.deadline_at||deadlineAt,resultSchemaVersion:'ml-result.v1'})
      }catch(error){
        return send(req,res,422,{error:error instanceof Error?error.message:'dataset training could not be submitted'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/task-policies') {
      const items=await listAiTaskPolicies(workspaceId)
      return send(req,res,200,{items,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && /^\/api\/ai\/task-policies\/[^/]+$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const task=decodeURIComponent(url.pathname.split('/')[4]||'')
      const body=await readBody(req)
      try{
        const item=await saveAiTaskPolicy({workspaceId,task,input:body,actor:authenticatedUser})
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'AI task policy could not be saved'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/activation-proposals') {
      const status=url.searchParams.get('status')
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||100),500))
      const items=await listAiActivationProposals({workspaceId,status:status||null,limit})
      return send(req,res,200,{items,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/activation-proposals') {
      const body=await readBody(req)
      try{
        const item=await createAiActivationProposal({workspaceId,input:body,actor:authenticatedUser})
        const reviewerSubmission=await handleRequestInference({
          workspaceId,
          task:'recommendation_reviewer',
          input:{
            recommendation:item.payload,
            evidence:item.evidence_snapshot,
            policy:item.policy_result
          },
          sourceSnapshot:{
            schemaVersion:'activation-review.v1',
            proposalId:item.id,
            proposalHash:item.proposal_hash,
            evidenceIds:Array.isArray(item.evidence_snapshot?.evidenceRefs)?item.evidence_snapshot.evidenceRefs:[],
            capturedAt:new Date().toISOString()
          },
          idempotencyKey:'activation-review:'+item.proposal_hash,
          actor:authenticatedUser
        })
        if(!reviewerSubmission.accepted){
          const blocked=await markActivationProposalReviewerBlocked({
            workspaceId,
            id:item.id,
            reason:[reviewerSubmission.error,...(reviewerSubmission.prerequisites||[])].filter(Boolean).join('; ')
          })
          return send(req,res,409,{
            error:'required recommendation reviewer is blocked',
            item:blocked||item,
            prerequisites:reviewerSubmission.prerequisites||[],
            note:'The proposal is preserved but cannot be approved without required reviewer evidence.'
          })
        }
        const reviewed=await attachActivationProposalReviewerJob({workspaceId,id:item.id,jobId:reviewerSubmission.job.id})
        return send(req,res,202,{
          item:reviewed||item,
          reviewerJobId:reviewerSubmission.job.id,
          reviewerStatus:'queued',
          note:'Reviewer output is evidence only and cannot authorize or execute the proposal.'
        })
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'activation proposal could not be created'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/activation-proposals\/[^/]+\/approve$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/')[4]||'')
      try{
        const item=await approveAiActivationProposal({workspaceId,id,actor:authenticatedUser})
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'activation proposal approval failed'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/activation-proposals\/[^/]+\/reject$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/')[4]||'')
      const body=await readBody(req)
      try{
        const item=await rejectAiActivationProposal({workspaceId,id,actor:authenticatedUser,reason:body.reason||null})
        return item?send(req,res,200,{item}):send(req,res,404,{error:'activation proposal not found or no longer pending'})
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'activation proposal rejection failed'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/activation-proposals\/[^/]+\/execute$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/')[4]||'')
      try{
        const execution=await handleActivateModelResult({workspaceId,proposalId:id,actor:authenticatedUser})
        return send(req,res,202,{
          item:execution.proposal,
          jobId:execution.job?.id||null,
          status:execution.job?.status||'queued',
          note:'Approved activation execution was queued for a worker. The worker rechecks proposal freshness and the execution safety gate before any provider side effect.'
        })
      }catch(error){
        const message=error instanceof Error?error.message:'activation proposal execution could not be queued'
        const blocked=/disabled|unsupported|blocked/i.test(message)
        return send(req,res,blocked?409:422,{error:message})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/transcripts') {
      const items=await listTranscripts(workspaceId)
      return send(req,res,200,{items,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/creative-assets') {
      const items=await listCreativeAssets(workspaceId)
      return send(req,res,200,{items,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && /^\/api\/ai\/creative-assets\/[^/]+\/review$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/')[4]||'')
      const body=await readBody(req)
      try{
        const item=await reviewCreativeAsset({workspaceId,id,status:String(body.status||''),actor:authenticatedUser,reason:body.reason||null})
        return item?send(req,res,200,{item}):send(req,res,404,{error:'creative asset not found or no longer reviewable'})
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'creative review failed'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/registry') {
      const staticRegistry=registrySummary()
      let tenantItems=[]
      let persistence='unavailable'
      try{
        await syncTenantRegistry(workspaceId)
        tenantItems=await getTenantRegistry(workspaceId)
        persistence='postgres'
      }catch(error){
        tenantItems=staticRegistry.items
        persistence='static_fallback'
      }
      return send(req,res,200,{...staticRegistry,tenantItems,persistence})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/monitoring') {
      const windowHours=Math.max(1,Math.min(Number(url.searchParams.get('windowHours')||24),24*90))
      try{
        return send(req,res,200,await aiMonitoringSnapshot({workspaceId,windowHours}))
      }catch(error){
        return send(req,res,503,{error:error instanceof Error?error.message:'AI monitoring unavailable'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/deployment-controls') {
      const controls=await listDeploymentControls(workspaceId)
      const items=await Promise.all(controls.map(async control=>({
        ...control,
        health:await deploymentHealth({workspaceId,task:control.task}).catch(()=>null)
      })))
      return send(req,res,200,{items,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && /^\/api\/ai\/deployment-controls\/[^/]+$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const task=decodeURIComponent(url.pathname.split('/')[4]||'')
      const body=await readBody(req)
      try{
        const item=await saveDeploymentControl({workspaceId,task,input:body,actor:authenticatedUser})
        const health=await deploymentHealth({workspaceId,task}).catch(()=>null)
        return send(req,res,200,{item,health,note:'Deployment control changes traffic policy only; they do not qualify, approve or deploy an unqualified model.'})
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'deployment control could not be saved'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/providers\/[^/]+\/verify$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const task=decodeURIComponent(url.pathname.split('/')[4]||'')
      try{
        const verification=await verifyProviderAccess(task)
        const registryEntry=await recordProviderAccessVerification({
          workspaceId,
          task,
          resolvedModel:verification.resolvedModel||null,
          verified:true
        })
        return send(req,res,200,{
          task,
          provider:verification.provider,
          requestedModel:verification.requestedModel,
          resolvedModel:verification.resolvedModel||null,
          accessVerified:true,
          usage:verification.usage||null,
          registryEntry,
          note:'Credential/model access was verified by an explicitly enabled bounded provider test. This does not qualify, approve or deploy the model.'
        })
      }catch(error){
        return send(req,res,error?.status||503,{
          error:error instanceof Error?error.message:'provider access verification failed',
          task,
          accessVerified:false
        })
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/models\/[^/]+\/deploy$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const task=decodeURIComponent(url.pathname.split('/')[4]||'')
      try{
        const item=await deployModel({workspaceId,task,actor:authenticatedUser})
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'deployment gate failed'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/models\/[^/]+\/undeploy$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const task=decodeURIComponent(url.pathname.split('/')[4]||'')
      try{
        const item=await undeployModel({workspaceId,task,actor:authenticatedUser})
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'undeploy failed'})
      }
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/live-voice/sessions') {
      try{
        await syncTenantRegistry(workspaceId)
        const registry=await getTenantRegistry(workspaceId)
        const route=registry.find(item=>item.task==='live_voice')
        const liveAdmission=await evaluateAiTaskAdmission({workspaceId,task:'live_voice',requestedModel:route?.requestedModel||'',reservedUnits:1})
        if(!liveAdmission.allowed)return send(req,res,429,{error:'live voice is blocked by tenant policy',prerequisites:liveAdmission.reasons,policy:liveAdmission.policy,usage:liveAdmission.usage})
        const missing=[]
        if(route?.documentationVerified!==true)missing.push('documentation verification')
        if(route?.accessVerified!==true)missing.push('provider access verification')
        if(route?.evaluationStatus!=='qualified')missing.push('qualified evaluation')
        if(route?.approvalStatus!=='approved')missing.push('approval')
        if(route?.deploymentStatus!=='deployed')missing.push('deployment')
        if(missing.length)return send(req,res,409,{error:'live voice is blocked by governance prerequisites',prerequisites:missing})
        const session=await createLiveVoiceSession({workspaceId,userId:authenticatedUser?.userId||null})
        return send(req,res,201,session)
      }catch(error){
        return send(req,res,503,{error:error instanceof Error?error.message:'live voice session could not be created'})
      }
    }
    if (req.method === 'GET' && /^\/api\/ai\/live-voice\/sessions\/[^/]+$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/')[5]||'')
      const item=await getLiveVoiceSession({workspaceId,id}).catch(()=>null)
      return item?send(req,res,200,{item}):send(req,res,404,{error:'live voice session not found'})
    }
    if (req.method === 'POST' && /^\/api\/ai\/live-voice\/sessions\/[^/]+\/terminate$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/')[5]||'')
      const item=await terminateLiveVoiceSession({workspaceId,id})
      return item?send(req,res,200,{item}):send(req,res,404,{error:'live voice session not found'})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/evaluations') {
      const task=String(url.searchParams.get('task')||'').trim()||null
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||100),500))
      const items=await listEvaluations({workspaceId,task,limit}).catch(()=>[])
      return send(req,res,200,{items,task,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/evaluation-policy') {
      const task=String(url.searchParams.get('task')||'').trim()
      if(!task)return send(req,res,400,{error:'task required'})
      const item=await getEvaluationPolicy({workspaceId,task})
      return send(req,res,200,{item,task})
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/evaluation-policy') {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const body=await readBody(req)
      const task=String(body.task||'').trim()
      const version=String(body.version||'').trim()
      if(!task||!version)return send(req,res,400,{error:'task and version required'})
      if(!body.thresholds||typeof body.thresholds!=='object'||Array.isArray(body.thresholds))return send(req,res,400,{error:'thresholds object required'})
      try{
        const item=await upsertEvaluationPolicy({
          workspaceId,
          task,
          version:version.slice(0,120),
          thresholds:body.thresholds,
          notes:body.notes?String(body.notes).slice(0,2000):null,
          actor:authenticatedUser
        })
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'evaluation policy could not be saved'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/evaluations\/[^/]+\/qualify$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const parts=url.pathname.split('/')
      const evaluationId=decodeURIComponent(parts[4]||'')
      try{
        const item=await qualifyEvaluation({workspaceId,evaluationId,actor:authenticatedUser})
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'evaluation qualification failed'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/models\/[^/]+\/promote$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const parts=url.pathname.split('/')
      const task=decodeURIComponent(parts[4]||'')
      const body=await readBody(req)
      const evaluationId=String(body.evaluationId||'').trim()
      if(!evaluationId)return send(req,res,400,{error:'evaluationId required'})
      try{
        const item=await promoteModel({workspaceId,task,evaluationId,actor:authenticatedUser})
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'model promotion failed'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/models\/[^/]+\/rollback$/.test(url.pathname)) {
      if(!['owner','admin'].includes(authenticatedUser?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      const parts=url.pathname.split('/')
      const task=decodeURIComponent(parts[4]||'')
      try{
        const item=await rollbackModel({workspaceId,task,actor:authenticatedUser})
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'model rollback failed'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/knowledge') {
      const items=await listKnowledgeSources({workspaceId,role:authenticatedUser?.role||'viewer'})
      return send(req,res,200,{items,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/knowledge') {
      const body=await readBody(req)
      const text=String(body.text||'')
      const name=String(body.name||'').trim()
      if(!name)return send(req,res,400,{error:'name required'})
      if(!text.trim())return send(req,res,400,{error:'text required'})
      const result=await ingestKnowledgeText({
        workspaceId,
        name,
        text,
        sourceLocation:body.sourceLocation?String(body.sourceLocation):null,
        documentVersion:String(body.documentVersion||'v1'),
        accessPolicy:body.accessPolicy&&typeof body.accessPolicy==='object'?body.accessPolicy:{},
        actor:authenticatedUser
      })
      return send(req,res,201,result)
    }
    if (req.method === 'POST' && /^\/api\/ai\/knowledge\/[^/]+\/revoke$/.test(url.pathname)) {
      const parts=url.pathname.split('/')
      const id=decodeURIComponent(parts[4]||'')
      const result=await revokeKnowledgeSource({workspaceId,id})
      return result?send(req,res,200,result):send(req,res,404,{error:'knowledge source not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/knowledge/search') {
      const body=await readBody(req)
      const query=String(body.query||'').trim()
      if(!query)return send(req,res,400,{error:'query required'})
      if(query.length>1000)return send(req,res,400,{error:'query exceeds 1000 characters'})
      const job=await handleSubmitJob({
        workspaceId,
        kind:'knowledge_search',
        payload:{query,role:authenticatedUser?.role||'viewer',limit:Math.max(1,Math.min(Number(body.limit||10),20))},
        idempotencyKey:'knowledge-search:'+String(req.headers['idempotency-key']||req.requestId||randomUUID()),
        maxAttempts:Number(process.env.AI_JOB_MAX_ATTEMPTS||2),
        deadlineAt:new Date(Date.now()+Number(process.env.KNOWLEDGE_SEARCH_DEADLINE_MS||120000)).toISOString(),
        inputSnapshot:{schemaVersion:'knowledge-search.v1',query,capturedAt:new Date().toISOString(),role:authenticatedUser?.role||'viewer'},
        resultSchemaVersion:'knowledge-search-result.v1'
      })
      if(!job)return send(req,res,503,{error:'durable queue requires DATABASE_URL'})
      return send(req,res,202,{jobId:job.id,status:job.status,resultSchemaVersion:'knowledge-search-result.v1'})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/ml/capabilities') {
      if(!mlServiceConfigured()){
        return send(req,res,200,{
          configured:false,
          items:registrySummary().items.filter(item=>item.provider==='local_ml'||item.kind==='deterministic_baseline'),
          warning:'ML service URL/authentication are not configured; training and specialist inference remain blocked.'
        })
      }
      try{
        const capabilities=await getMlCapabilities()
        return send(req,res,200,{configured:true,...capabilities})
      }catch(error){
        return send(req,res,503,{configured:true,error:error instanceof Error?error.message:'ML service unavailable'})
      }
    }
    const mlOperationByPath={
      '/api/ai/ml/train/classification':{operation:'classification_train',taskFromBody:true},
      '/api/ai/ml/train/regression':{operation:'regression_train',taskFromBody:true},
      '/api/ai/ml/score':{operation:'artifact_score',taskFromBody:true},
      '/api/ai/ml/forecast/seasonal-naive':{operation:'forecast_baseline',task:'forecast_baseline'},
      '/api/ai/ml/forecast/chronos-2':{operation:'forecast_chronos',task:'forecast_primary'},
      '/api/ai/ml/forecast/qualify':{operation:'forecast_qualification',task:'forecast_primary'},
      '/api/ai/ml/forecast/catboost-challenger':{operation:'forecast_challenger',task:'forecast_challenger'},
      '/api/ai/ml/incrementality':{operation:'incrementality',task:'incrementality'},
      '/api/ai/ml/marketing-mix':{operation:'marketing_mix',task:'marketing_mix'},
      '/api/ai/ml/anomalies':{operation:'anomaly_detection',task:'anomaly_detection'},
      '/api/ai/ml/segments':{operation:'behavioral_segments',task:'behavioral_segments'},
      '/api/ai/ml/rank':{operation:'offer_ranking',task:'offer_ranking'},
      '/api/ai/ml/rank/score':{operation:'offer_ranking_score',task:'offer_ranking'}
    }
    if(req.method==='POST'&&mlOperationByPath[url.pathname]){
      const spec=mlOperationByPath[url.pathname]
      if(!mlServiceConfigured(spec.operation)) return send(req,res,503,{error:'ML service profile for '+spec.operation+' is not configured'})
      const body=await readBody(req)
      const task=spec.taskFromBody?String(body.task||''):spec.task
      if(!task)return send(req,res,400,{error:'task required'})
      if(IS_PROD&&['classification_train','regression_train'].includes(spec.operation)&&process.env.AI_ALLOW_INLINE_TRAINING!=='true'){
        return send(req,res,409,{error:'production supervised training requires an immutable dataset snapshot; create /api/ai/datasets and submit /api/ai/datasets/:id/train'})
      }
      const allowedTasks=new Set(['lead_qualification','paid_conversion','customer_churn','future_customer_value','forecast_baseline','forecast_primary','forecast_challenger','incrementality','marketing_mix','anomaly_detection','behavioral_segments','offer_ranking'])
      if(!allowedTasks.has(task))return send(req,res,400,{error:'unsupported ML task'})
      const admission=await evaluateAiTaskAdmission({workspaceId,task,requestedModel:modelRegistryItem(task)?.requestedModel||task,reservedUnits:1})
      if(!admission.allowed)return send(req,res,429,{error:'ML task is blocked by tenant policy',prerequisites:admission.reasons,policy:admission.policy,usage:admission.usage})
      const requestKey=String(req.headers['idempotency-key']||req.requestId||randomUUID())
      const deadlineAt=new Date(Date.now()+Number(process.env.ML_JOB_DEADLINE_MS||15*60*1000)).toISOString()
      const job=await handleSubmitJob({
        workspaceId,
        kind:'ml_task',
        payload:{operation:spec.operation,task,request:body},
        idempotencyKey:'ml:'+spec.operation+':'+requestKey,
        maxAttempts:Number(process.env.ML_JOB_MAX_ATTEMPTS||2),
        deadlineAt,
        inputSnapshot:{
          schemaVersion:'ml-input.v1',
          task,
          operation:spec.operation,
          capturedAt:new Date().toISOString(),
          actor:authenticatedUser?{userId:authenticatedUser.userId||null,role:authenticatedUser.role||null}:null,
          request:body
        },
        resultSchemaVersion:'ml-result.v1',
        aiUsageReservation:{task,provider:'local_ml',requestedModel:task,reservedUnits:1},
        outboxEvent:{eventType:'ai.job.accepted',schemaVersion:'ai-job-event.v1',payload:{task,operation:spec.operation}}
      })
      if(!job)return send(req,res,503,{error:'durable queue requires DATABASE_URL'})
      return send(req,res,202,{
        jobId:job.id,
        status:job.status,
        task,
        operation:spec.operation,
        deadlineAt:job.deadline_at||deadlineAt,
        resultSchemaVersion:'ml-result.v1'
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/forecast-records') {
      const task=String(url.searchParams.get('task')||'').trim()||null
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||100),500))
      const items=await listForecastRecords({workspaceId,task,limit})
      return send(req,res,200,{items,task,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/causal-records') {
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||100),500))
      const items=await listCausalRecords({workspaceId,limit})
      return send(req,res,200,{items,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/marketing-mix-records') {
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||100),500))
      const items=await listMarketingMixRecords({workspaceId,limit})
      return send(req,res,200,{items,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/anomalies') {
      const status=String(url.searchParams.get('status')||'').trim()||null
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||200),1000))
      const items=await listAnomalyItems({workspaceId,status,limit})
      return send(req,res,200,{items,status,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && /^\/api\/ai\/anomalies\/[^/]+\/[^/]+\/review$/.test(url.pathname)) {
      const parts=url.pathname.split('/')
      const resultId=decodeURIComponent(parts[4]||'')
      const entityId=decodeURIComponent(parts[5]||'')
      const body=await readBody(req)
      try{
        const item=await reviewAnomalyItem({workspaceId,resultId,entityId,status:String(body.status||''),feedback:body.feedback||null,suppressedUntil:body.suppressedUntil||null,actor:authenticatedUser})
        return item?send(req,res,200,{item}):send(req,res,404,{error:'anomaly item not found'})
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'anomaly review failed'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/segments') {
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||50),200))
      const items=await listSegmentSnapshots({workspaceId,limit})
      return send(req,res,200,{items,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && /^\/api\/ai\/segments\/[^/]+\/members$/.test(url.pathname)) {
      const snapshotId=decodeURIComponent(url.pathname.split('/')[4]||'')
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||1000),5000))
      const items=await getSegmentMemberships({workspaceId,snapshotId,limit})
      return send(req,res,200,{items,snapshotId,limit})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/rankings') {
      const resultId=String(url.searchParams.get('resultId')||'').trim()||null
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||500),5000))
      const items=await listRankingItems({workspaceId,resultId,limit})
      return send(req,res,200,{items,resultId,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/results') {
      const task=String(url.searchParams.get('task')||'').trim()||null
      const limit=Math.max(1,Math.min(Number(url.searchParams.get('limit')||50),200))
      const items=await listAiResults({workspaceId,task,limit}).catch(()=>[])
      return send(req,res,200,{items,task,limit,generatedAt:new Date().toISOString()})
    }
    if (req.method === 'GET' && /^\/api\/ai\/jobs\/[^/]+$/.test(url.pathname)) {
      const id=decodeURIComponent(url.pathname.split('/').pop()||'')
      const job=await getJob({workspaceId,id})
      return job?send(req,res,200,{job}):send(req,res,404,{error:'AI job not found'})
    }
    if (req.method === 'GET' && /^\/api\/ai\/jobs\/[^/]+\/events$/.test(url.pathname)) {
      const parts=url.pathname.split('/')
      const id=decodeURIComponent(parts[4]||'')
      const initial=await getJob({workspaceId,id})
      if(!initial)return send(req,res,404,{error:'AI job not found'})
      res.writeHead(200,{
        'Content-Type':'text/event-stream; charset=utf-8',
        'Cache-Control':'no-cache, no-transform',
        'Connection':'keep-alive',
        'X-Accel-Buffering':'no'
      })
      let closed=false
      let lastSignature=''
      const terminal=new Set(['succeeded','completed','failed','cancelled','dead_letter','unknown'])
      const writeEvent=(event,data)=>{
        if(closed)return
        res.write('event: '+event+'\n')
        res.write('data: '+JSON.stringify(data)+'\n\n')
      }
      const emit=async()=>{
        if(closed)return
        const job=await getJob({workspaceId,id}).catch(()=>null)
        if(!job){writeEvent('error',{error:'AI job disappeared from tenant scope'});closed=true;return res.end()}
        const signature=JSON.stringify([job.status,job.updated_at,job.completed_at,job.last_error,job.cancel_requested_at])
        if(signature!==lastSignature){
          lastSignature=signature
          writeEvent('status',{jobId:job.id,status:job.status,attempts:job.attempts,updatedAt:job.updated_at,completedAt:job.completed_at||null,lastError:job.last_error||null,cancelRequestedAt:job.cancel_requested_at||null})
        }
        if(terminal.has(String(job.status||'').toLowerCase())){writeEvent('complete',{jobId:job.id,status:job.status});closed=true;return res.end()}
      }
      req.on('close',()=>{closed=true})
      writeEvent('ready',{jobId:id,status:initial.status})
      await emit()
      if(closed)return
      const interval=setInterval(()=>void emit(),1000)
      interval.unref?.()
      const timeout=setTimeout(()=>{if(!closed){writeEvent('timeout',{jobId:id});closed=true;res.end()}},Number(process.env.AI_JOB_EVENT_STREAM_MAX_MS||120000))
      timeout.unref?.()
      res.on('close',()=>{closed=true;clearInterval(interval);clearTimeout(timeout)})
      return
    }

    if (req.method === 'POST' && /^\/api\/ai\/jobs\/[^/]+\/replay$/.test(url.pathname)) {
      const parts=url.pathname.split('/')
      const id=decodeURIComponent(parts[4]||'')
      try{
        const job=await handleReplayDeadLetter({workspaceId,jobId:id})
        return send(req,res,202,{job})
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'dead-letter replay failed',code:error?.code||'dead_letter_replay_failed'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/jobs\/[^/]+\/cancel$/.test(url.pathname)) {
      const parts=url.pathname.split('/')
      const id=decodeURIComponent(parts[4]||'')
      const job=await requestJobCancellation({workspaceId,id})
      return job?send(req,res,200,{job}):send(req,res,404,{error:'cancellable AI job not found'})
    }
    if (req.method === 'GET' && url.pathname === '/api/ai/analyst/tools') {
      return send(req,res,200,{items:analystToolNames(),schemaVersion:'analyst-tool-catalog.v1'})
    }
    if (req.method === 'POST' && /^\/api\/ai\/analyst\/tools\/[^/]+$/.test(url.pathname)) {
      const tool=decodeURIComponent(url.pathname.split('/')[5]||'')
      const body=await readBody(req)
      try{
        const item=await executeAnalystTool({workspaceId,name:tool,args:body,principal:authenticatedUser})
        return send(req,res,200,{item})
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'analyst tool execution failed'})
      }
    }
    if (req.method === 'POST' && /^\/api\/ai\/tasks\/[^/]+\/shadow$/.test(url.pathname)) {
      const task=decodeURIComponent(url.pathname.split('/')[4]||'')
      if(task==='live_voice')return send(req,res,400,{error:'live_voice uses the dedicated session endpoint'})
      const body=await readBody(req)
      const validated=validateHostedTaskInput(task,body)
      if(!validated.ok)return send(req,res,400,{error:validated.error,task})
      const sourceSnapshot={
        schemaVersion:'hosted-task-shadow-input.v1',
        task,
        capturedAt:new Date().toISOString(),
        evidenceIds:Array.isArray(body.evidenceIds)?body.evidenceIds.map(String).slice(0,100):[],
        clientMetadata:body.clientMetadata&&typeof body.clientMetadata==='object'?body.clientMetadata:{},
        shadow:true
      }
      const submission=await handleRequestInference({
        workspaceId,
        task,
        input:validated.input,
        sourceSnapshot,
        idempotencyKey:String(req.headers['idempotency-key']||req.requestId||randomUUID()),
        actor:authenticatedUser,
        executionMode:'shadow'
      })
      if(!submission.accepted){
        return send(req,res,submission.status||409,{error:submission.error,task,readiness:submission.readiness||null,prerequisites:submission.prerequisites||[]})
      }
      return send(req,res,202,{
        jobId:submission.job.id,
        status:submission.job.status,
        task,
        shadow:true,
        deployment:submission.deployment,
        requestedModel:submission.route.requestedModel,
        resultSchemaVersion:'ai-result.v1'
      })
    }
    if (req.method === 'POST' && /^\/api\/ai\/tasks\/[^/]+\/submit$/.test(url.pathname)) {
      const task=decodeURIComponent(url.pathname.split('/')[4]||'')
      if(task==='live_voice')return send(req,res,400,{error:'live_voice uses the dedicated session endpoint'})
      const body=await readBody(req)
      const validated=validateHostedTaskInput(task,body)
      if(!validated.ok)return send(req,res,400,{error:validated.error,task})
      const sourceSnapshot={
        schemaVersion:'hosted-task-input.v1',
        task,
        capturedAt:new Date().toISOString(),
        evidenceIds:Array.isArray(body.evidenceIds)?body.evidenceIds.map(String).slice(0,100):[],
        clientMetadata:body.clientMetadata&&typeof body.clientMetadata==='object'?body.clientMetadata:{}
      }
      const submission=await handleRequestInference({
        workspaceId,
        task,
        input:validated.input,
        sourceSnapshot,
        idempotencyKey:String(req.headers['idempotency-key']||req.requestId||randomUUID()),
        actor:authenticatedUser
      })
      if(!submission.accepted){
        return send(req,res,submission.status||409,{error:submission.error,task,readiness:submission.readiness||null,prerequisites:submission.prerequisites||[]})
      }
      return send(req,res,202,{
        jobId:submission.job.id,
        status:submission.job.status,
        task,
        provider:submission.route.provider,
        requestedModel:submission.route.requestedModel,
        readiness:submission.route.readiness,
        deployment:submission.deployment||null,
        resultSchemaVersion:'ai-result.v1'
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/analysis') {
      const body=await readBody(req)
      const question=String(body.question||'').trim()
      if(!question)return send(req,res,400,{error:'question required'})
      if(question.length>8000)return send(req,res,400,{error:'question exceeds 8000 characters'})
      const requestedTools=Array.isArray(body.tools)
        ?body.tools.slice(0,9)
        :[
          {name:'campaign_performance',args:{limit:20}},
          {name:'funnel_comparison',args:{limit:50}},
          {name:'customer_aggregates',args:{limit:25}},
          {name:'attribution_summary',args:{}},
          {name:'forecasts',args:{limit:20}},
          {name:'prediction_explanations',args:{limit:20}},
          {name:'anomalies',args:{limit:20}},
          {name:'experiment_results',args:{limit:20}}
        ]
      let analystTools=[]
      try{
        analystTools=await executeAnalystToolSet({workspaceId,requests:requestedTools,principal:authenticatedUser})
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'invalid analyst tool request'})
      }
      const [leadStats,attr,state]=await Promise.all([
        leadOpsStats(workspaceId).catch(()=>({available:false,total:0,averageScore:0})),
        attributionStats(workspaceId).catch(()=>({available:false,matchedEvents:0,unmatchedEvents:0,assistedEvents:0})),
        getState()
      ])
      const deliveries=state.signalDeliveries||[]
      const connectors=state.connectorConnections||[]
      const evidenceIds=[
        'lead_ops:'+workspaceId,
        'attribution:'+workspaceId,
        'connector_state:'+workspaceId,
        'signal_delivery:'+workspaceId
      ]
      const sourceSnapshot={
        schemaVersion:'workspace-analytics.v1',
        capturedAt:new Date().toISOString(),
        evidenceIds,
        leadOps:{
          available:Boolean(leadStats?.available),
          total:Number(leadStats?.total||0),
          averageScore:Number(leadStats?.averageScore||0),
          aGrade:Number(leadStats?.aGrade||0),
          abQuality:Number(leadStats?.abQuality||0)
        },
        attribution:{
          available:Boolean(attr?.available),
          matchedEvents:Number(attr?.matchedEvents||0),
          unmatchedEvents:Number(attr?.unmatchedEvents||0),
          assistedEvents:Number(attr?.assistedEvents||0)
        },
        operations:{
          connectors:connectors.length,
          connectedConnectors:connectors.filter(x=>['connected','healthy','active'].includes(String(x.status||'').toLowerCase())).length,
          signalDeliveries:deliveries.length,
          deliveryFailures:deliveries.filter(x=>['failed','dead_letter'].includes(String(x.status||'').toLowerCase())).length
        },
        analystTools
      }
      const submission=await handleRequestInference({
        workspaceId,
        task:'analyst',
        input:{
          question,
          evidence:sourceSnapshot,
          instructions:'Use only the supplied immutable workspace snapshot. Every numerical statement must be traceable to an evidence ID. Distinguish observed facts from hypotheses and do not invent forecasts.'
        },
        sourceSnapshot,
        idempotencyKey:String(req.headers['idempotency-key']||req.requestId||randomUUID()),
        actor:authenticatedUser
      })
      if(!submission.accepted){
        return send(req,res,submission.status||409,{
          error:submission.error,
          readiness:submission.readiness||null,
          prerequisites:submission.prerequisites||[]
        })
      }
      return send(req,res,202,{
        jobId:submission.job.id,
        status:submission.job.status,
        task:'analyst',
        readiness:submission.route.readiness,
        requestedModel:submission.route.requestedModel,
        resultSchemaVersion:'ai-result.v1'
      })
    }
    if (req.method === 'GET' && url.pathname === '/api/models') {
      const state=await getState()
      const stats=await leadOpsStats(workspaceId).catch(()=>({available:false,total:0,averageScore:0}))
      const runs=(state.agentRuns||[]).filter(x=>x.kind==='model').slice(0,20)
      const builtIn=[
        {id:'builtin_lead_quality',name:'Lead quality scoring',version:'v2.0',status:Number(stats?.total||0)>0?'active':'ready',type:'Scoring',metric:'Average lead score',value:Number(stats?.averageScore||0),description:'Explainable scoring over persisted CRM, journey and interaction evidence.',builtIn:true},
        {id:'builtin_journey_features',name:'Journey propensity features',version:'workspace',status:Number(stats?.total||0)>0?'active':'ready',type:'Feature set',metric:'Profiles available',value:Number(stats?.total||0),description:'Uses persisted journey depth, pricing views, messaging, calls, meetings and CRM stage as model features.',builtIn:true}
      ]
      const custom=(state.customModels||[]).map(x=>({...x,builtIn:false,status:x.status||'ready',type:'Weighted scoring',metric:'Average custom score',value:x.lastAverageScore??'—'}))
      const registry=modelCatalogItems()
      return send(req,res,200,{items:[...builtIn,...custom,...registry],runs})
    }
    if (req.method === 'POST' && url.pathname === '/api/models') {
      const body=await readBody(req)
      const name=String(body.name||'').trim()
      if(!name)return send(req,res,400,{error:'name required'})
      const rawWeights=body.weights&&typeof body.weights==='object'?body.weights:{}
      const allowed=['lead_score','journey_depth','pricing_views','whatsapp_engaged','meeting_present']
      const weights={}
      for(const key of allowed){
        const value=Number(rawWeights[key]??0)
        if(Number.isFinite(value))weights[key]=Math.max(-100,Math.min(100,value))
      }
      const totalWeight=Object.values(weights).reduce((n,x)=>n+Math.abs(Number(x||0)),0)
      if(totalWeight<=0)return send(req,res,400,{error:'at least one non-zero feature weight required'})
      const now=new Date().toISOString()
      const item={id:'model_'+randomUUID(),name:name.slice(0,160),version:'workspace-1',description:String(body.description||'Workspace-defined explainable weighted scoring model.').slice(0,500),weights,status:'ready',createdAt:now,updatedAt:now}
      await mutateState(s=>{
        s.customModels=s.customModels||[]
        s.customModels.unshift(item)
        s.customModels=s.customModels.slice(0,100)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'model.created',entityId:item.id,name:item.name,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/models/run') {
      const body=await readBody(req)
      if(!body.name) return send(req,res,400,{error:'name required'})
      const registryModel=modelCatalogItems().find(x=>x.name===String(body.name)||x.id===String(body.id||''))
      if(registryModel){
        return send(req,res,409,{
          error:registryModel.blockedReason||'This registry model must use its task-specific endpoint.',
          readiness:registryModel.governance?.readiness||registryModel.status,
          task:registryModel.governance?.task||null
        })
      }
      const [profiles,state,stats]=await Promise.all([listLeadProfiles(workspaceId,500),getState(),leadOpsStats(workspaceId).catch(()=>({averageScore:0}))])
      const custom=(state.customModels||[]).find(x=>x.name===String(body.name)||x.id===String(body.id||''))
      const scoreProfile=lead=>{
        if(!custom)return Number(lead.score||0)
        const f={
          lead_score:Math.max(0,Math.min(1,Number(lead.score||0)/100)),
          journey_depth:Math.max(0,Math.min(1,Number(lead.journey?.journeyDepth||0)/10)),
          pricing_views:Math.max(0,Math.min(1,Number(lead.journey?.pricingPageViews||0)/5)),
          whatsapp_engaged:lead.journey?.whatsappEngaged?1:0,
          meeting_present:lead.journey?.meetingStatus?1:0
        }
        const entries=Object.entries(custom.weights||{})
        const denominator=entries.reduce((n,[,w])=>n+Math.abs(Number(w||0)),0)||1
        const weighted=entries.reduce((n,[key,w])=>n+Number(f[key]||0)*Number(w||0),0)
        return Number(Math.max(0,Math.min(100,weighted/denominator*100)).toFixed(1))
      }
      const scores=profiles.map(scoreProfile)
      const average=scores.length?Number((scores.reduce((n,x)=>n+x,0)/scores.length).toFixed(1)):0
      const startedAt=new Date().toISOString()
      const run={id:'modelrun_'+randomUUID(),kind:'model',name:String(body.name),modelId:custom?.id||null,status:profiles.length?'completed':'no_data',rowsScored:profiles.length,averageScore:custom?average:Number(stats?.averageScore||0),scoreMin:scores.length?Math.min(...scores):0,scoreMax:scores.length?Math.max(...scores):0,startedAt,completedAt:new Date().toISOString()}
      await mutateState(s=>{
        s.agentRuns=s.agentRuns||[]
        s.agentRuns.unshift(run)
        s.agentRuns=s.agentRuns.slice(0,500)
        if(custom){
          const model=(s.customModels||[]).find(x=>x.id===custom.id)
          if(model){model.lastRunAt=run.completedAt;model.lastAverageScore=run.averageScore;model.lastRowsScored=run.rowsScored;model.status=profiles.length?'active':'ready';model.updatedAt=run.completedAt}
        }
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'model.run',entityId:run.id,modelId:custom?.id||null,rowsScored:run.rowsScored,status:run.status,at:run.completedAt})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,202,run)
    }
    if (req.method === 'GET' && url.pathname === '/api/models/validation') {
      const name=String(url.searchParams.get('name')||'')
      const state=await getState()
      const runs=(state.agentRuns||[]).filter(x=>x.kind==='model'&&(!name||x.name===name)).slice(0,20)
      const leadStats=await leadOpsStats(workspaceId).catch(()=>({}))
      return send(req,res,200,{name:name||null,runs,leadPopulation:Number(leadStats?.total||0),averageLeadScore:Number(leadStats?.averageScore||0),generatedAt:new Date().toISOString(),notice:'Validation surface reflects persisted scoring runs and lead population; it is not a substitute for offline statistical validation.'})
    }
    if (req.method === 'GET' && url.pathname === '/api/routing') {
      const recent=await listRoutingDecisions(workspaceId,200)
      const state=await getState()
      const defaults=[
        {id:'rr_1',name:'High-intent education lead',when:'score >= 85',destination:'Senior counsellor pool',slaSeconds:60,status:'active',priority:'Priority',builtIn:true},
        {id:'rr_2',name:'Financing requested',when:'financingInterest = true',destination:'Finance-trained counsellor',slaSeconds:300,status:'active',priority:'Priority',builtIn:true},
        {id:'rr_3',name:'WhatsApp re-engagement',when:'source = whatsapp',destination:'WhatsApp nurture',slaSeconds:180,status:'active',priority:'Automated',builtIn:true},
        {id:'rr_4',name:'Low confidence review',when:'identityConfidence < 0.65',destination:'Manual review',slaSeconds:900,status:'active',priority:'Review',builtIn:true},
        {id:'rr_default',name:'Default routing',when:'fallback',destination:'General admissions queue',slaSeconds:600,status:'active',priority:'Fallback',builtIn:true}
      ]
      const rules=[...defaults,...(state.routingRules||[])]
      const today=new Date();today.setHours(0,0,0,0)
      const routedToday=recent.filter(x=>Date.parse(x.created_at||x.createdAt||0)>=today.getTime())
      const destinations={}
      for(const row of recent){
        const key=String(row.destination||'Unknown')
        destinations[key]=(destinations[key]||0)+1
      }
      return send(req,res,200,{
        rules,
        recent:recent.slice(0,50),
        stats:{
          routedToday:routedToday.length,
          totalDecisions:recent.length,
          destinations:Object.keys(destinations).length,
          matchedRules:new Set(recent.map(x=>x.rule_name).filter(Boolean)).size
        },
        destinationLoad:Object.entries(destinations).map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count)
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/routing/rules') {
      const body=await readBody(req)
      if(!body.name||!body.when||!body.destination)return send(req,res,400,{error:'name, when and destination required'})
      const item={id:'rr_'+randomUUID(),name:String(body.name).slice(0,160),when:String(body.when).slice(0,240),destination:String(body.destination).slice(0,160),slaSeconds:Math.max(0,Number(body.slaSeconds||600)),status:'active',priority:String(body.priority||'Custom').slice(0,40),builtIn:false,createdAt:new Date().toISOString()}
      await mutateState(s=>{s.routingRules=s.routingRules||[];s.routingRules.unshift(item);s.routingRules=s.routingRules.slice(0,200);s.audit=s.audit||[];s.audit.unshift({id:randomUUID(),action:'routing.rule_created',entityId:item.id,name:item.name,at:item.createdAt});s.audit=s.audit.slice(0,1000)})
      return send(req,res,201,{item})
    }
    if (req.method === 'POST' && url.pathname === '/api/routing/rules/toggle') {
      const body=await readBody(req)
      if(!body.id||typeof body.enabled!=='boolean')return send(req,res,400,{error:'id and enabled required'})
      let updated=null
      await mutateState(s=>{const item=(s.routingRules||[]).find(x=>x.id===body.id);if(item){item.status=body.enabled?'active':'paused';item.updatedAt=new Date().toISOString();updated={...item}}})
      return updated?send(req,res,200,{item:updated}):send(req,res,404,{error:'custom routing rule not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/routing/test') {
      const body=await readBody(req)
      const state=await getState()
      const custom=(state.routingRules||[]).find(x=>x.id===body.ruleId&&x.status!=='paused')
      const fallback=[
        {id:'rr_1',name:'High-intent education lead',when:'score >= 85',destination:'Senior counsellor pool',slaSeconds:60},
        {id:'rr_2',name:'Financing requested',when:'financingInterest = true',destination:'Finance-trained counsellor',slaSeconds:300},
        {id:'rr_3',name:'WhatsApp re-engagement',when:'source = whatsapp',destination:'WhatsApp nurture',slaSeconds:180},
        {id:'rr_4',name:'Low confidence review',when:'identityConfidence < 0.65',destination:'Manual review',slaSeconds:900},
        {id:'rr_default',name:'Default routing',when:'fallback',destination:'General admissions queue',slaSeconds:600}
      ].find(x=>x.id===body.ruleId)
      const selected=custom||fallback||null
      const decision=await routeLead(workspaceId,{leadRef:body.leadRef||'test_lead',score:body.score??90,source:body.source||'web',financingInterest:body.financingInterest,identityConfidence:body.identityConfidence??0.95,...(selected?{routingRule:{...selected,reason:'manual test of '+selected.when}}:{})})
      return send(req,res,200,{rule:decision.rule_name,matched:true,destination:decision.destination,reason:decision.reason,slaSeconds:decision.sla_seconds,evaluatedAt:decision.created_at})
    }
    if (req.method === 'GET' && url.pathname === '/api/lead-reactivation') {
      const dormantDays=Number(url.searchParams.get('dormantDays')||30)
      const recentDays=Number(url.searchParams.get('recentDays')||7)
      const [profiles,followUps]=await Promise.all([listLeadProfiles(workspaceId,500),listPersistedFollowUps(workspaceId)])
      const candidates=leadReactivationCandidates(profiles,trackedEvents,followUps,{dormantDays,recentDays})
      return send(req,res,200,{items:candidates,stats:{candidates:candidates.length,dormantDays,recentDays},generatedAt:new Date().toISOString()})
    }
    if (req.method === 'POST' && url.pathname === '/api/lead-reactivation/run') {
      const body=await readBody(req)
      const leadRef=String(body.leadRef||'').trim()
      if(!leadRef)return send(req,res,400,{error:'leadRef required'})
      const dormantDays=Number(body.dormantDays||30)
      const recentDays=Number(body.recentDays||7)
      const [profiles,followUps]=await Promise.all([listLeadProfiles(workspaceId,500),listPersistedFollowUps(workspaceId)])
      const candidates=leadReactivationCandidates(profiles,trackedEvents,followUps,{dormantDays,recentDays})
      const candidate=candidates.find(x=>x.leadRef===leadRef||x.name===leadRef)
      if(!candidate)return send(req,res,409,{error:'lead is not currently eligible for reactivation'})
      const item=await createFollowUp(workspaceId,{
        leadRef:candidate.leadRef,
        reason:candidate.reason+' · '+candidate.renewedEvent,
        channel:String(body.channel||'WhatsApp'),
        priority:String(body.priority||'high'),
        delayMinutes:Number(body.delayMinutes??5),
        owner:String(body.owner||'Reactivation queue')
      })
      const now=new Date().toISOString()
      await mutateState(s=>{
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'lead_reactivation.followup_created',entityId:item?.id||null,leadRef:candidate.leadRef,renewedEvent:candidate.renewedEvent,renewedAt:candidate.renewedAt,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,201,{item,candidate})
    }
    if (req.method === 'GET' && url.pathname === '/api/follow-ups') {
      const items=await listPersistedFollowUps(workspaceId)
      const now=Date.now()
      const start=new Date();start.setHours(0,0,0,0)
      const open=items.filter(x=>x.status==='open')
      const completed=items.filter(x=>x.status==='completed')
      const completedToday=completed.filter(x=>Date.parse(x.completed_at||0)>=start.getTime()).length
      const overdue=open.filter(x=>x.due_at&&Date.parse(x.due_at)<now).length
      return send(req,res,200,{items,stats:{open:open.length,completedToday,completedTotal:completed.length,overdue}})
    }
    if (req.method === 'POST' && url.pathname === '/api/follow-ups') {
      const body=await readBody(req)
      const item=await createFollowUp(workspaceId,body)
      return send(req,res,201,item)
    }
    if (req.method === 'POST' && url.pathname === '/api/follow-ups/complete') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const updated=await persistCompleteFollowUp(workspaceId,String(body.id))
      return updated?send(req,res,200,updated):send(req,res,404,{error:'follow-up not found'})
    }
    if (req.method === 'GET' && url.pathname === '/api/voice-scheduler') {
      const runs=(await listAgentRuns(workspaceId,100)).filter(x=>x.agent_type==='voice_scheduler')
      return send(req,res,200,{items:runs.map(x=>({id:x.id,lead:x.input?.lead||x.input?.leadRef||x.entity_id||'Lead',phone:x.input?.phone||x.input?.attendeePhone||'',status:x.status,preferredWindow:x.input?.preferredWindow||null,proposedStartsAt:x.input?.proposedStartsAt||null,meetingId:x.output?.meetingId||null,startsAt:x.output?.startsAt||null,meetingLink:x.output?.meetingLink||null,calendarSynced:Boolean(x.output?.calendarSynced),schedulerStatus:x.output?.schedulerStatus||null,externalId:x.external_id,lastError:x.last_error,createdAt:x.created_at}))})
    }
    if (req.method === 'POST' && url.pathname === '/api/voice-scheduler') {
      const body=await readBody(req)
      const leadRef=String(body.leadRef||body.lead||'').trim()
      const phone=String(body.phone||body.attendeePhone||'').trim()
      if(!leadRef)return send(req,res,400,{error:'leadRef or lead required'})
      if(!phone)return send(req,res,400,{error:'phone required'})
      if(body.proposedStartsAt&&Number.isNaN(Date.parse(String(body.proposedStartsAt))))return send(req,res,400,{error:'invalid proposedStartsAt'})
      const input={
        leadRef,
        lead:String(body.lead||leadRef),
        phone,
        attendeePhone:phone,
        attendeeEmail:String(body.attendeeEmail||'').trim(),
        preferredWindow:String(body.preferredWindow||'').trim(),
        proposedStartsAt:body.proposedStartsAt?new Date(body.proposedStartsAt).toISOString():null,
        durationMinutes:Math.max(15,Math.min(180,Number(body.durationMinutes||45))),
        owner:String(body.owner||'Voice Scheduler'),
        title:String(body.title||('Consultation · '+leadRef)),
        syncCalendar:body.syncCalendar!==false,
        requireCalendar:body.requireCalendar===true,
        timezone:String(body.timezone||'Asia/Kolkata')
      }
      const run=await createAgentRun(workspaceId,{agentType:'voice_scheduler',entityId:leadRef,triggerKey:String(body.trigger||'manual_voice_scheduler'),input})
      const job=await handleSubmitJob({workspaceId,kind:'agent_action',idempotencyKey:'agent:'+run.id,payload:{agentRunId:run.id,actionType:'voice_scheduler',payload:{...input,runId:run.id}}})
      return send(req,res,202,{id:run.id,status:'queued',jobId:job?.id||null,leadRef})
    }
    if (req.method === 'GET' && url.pathname === '/api/qualification-calls') {
      const runs=(await listAgentRuns(workspaceId,100)).filter(x=>x.agent_type==='voice_qualification')
      return send(req,res,200,{items:runs.map(x=>({id:x.id,lead:x.input?.lead||x.entity_id||'Lead',source:x.input?.source||'Unknown',agent:'Voice Lead Qualification',status:x.status,duration:x.output?.duration||'—',intent:x.output?.intent??x.input?.intent??0,next:x.output?.next||'Awaiting execution',attempts:x.attempts,externalId:x.external_id,lastError:x.last_error,createdAt:x.created_at}))})
    }
    if (req.method === 'POST' && url.pathname === '/api/qualification-calls/retry') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const run=await createAgentRun(workspaceId,{agentType:'voice_qualification',entityId:String(body.id),triggerKey:'manual_retry',input:{lead:body.lead||'Lead',source:body.source||'workspace',intent:body.intent||0}})
      const job=await handleSubmitJob({workspaceId,kind:'agent_action',idempotencyKey:'agent:'+run.id,payload:{agentRunId:run.id,actionType:'voice_qualification',payload:{lead:body.lead||'Lead',source:body.source||'workspace',intent:body.intent||0,runId:run.id}}})
      return send(req,res,202,{id:run.id,status:'queued',jobId:job?.id||null})
    }
    if (req.method === 'POST' && url.pathname === '/api/qualification-calls') {
      const body=await readBody(req)
      if(!body.lead) return send(req,res,400,{error:'lead required'})
      const run=await createAgentRun(workspaceId,{agentType:'voice_qualification',entityId:String(body.leadRef||body.lead),triggerKey:String(body.trigger||'lead_created'),input:body})
      const job=await handleSubmitJob({workspaceId,kind:'agent_action',idempotencyKey:'agent:'+run.id,payload:{agentRunId:run.id,actionType:'voice_qualification',payload:{...body,runId:run.id}}})
      return send(req,res,202,{id:run.id,status:'queued',jobId:job?.id||null})
    }
    if (req.method === 'GET' && url.pathname === '/api/meetings') return send(req,res,200,{items:await listPersistedMeetings(workspaceId)})
    if (req.method === 'POST' && url.pathname === '/api/meetings') {
      const body=await readBody(req)
      if(!body.leadRef&&!body.lead) return send(req,res,400,{error:'leadRef or lead required'})
      if(!body.startsAt) return send(req,res,400,{error:'startsAt required'})
      try{
        let calendar=null
        if(body.syncCalendar!==false){
          calendar=await createCalendarEvent(workspaceId,{
            ...body,
            title:body.title||('Consultation · '+String(body.leadRef||body.lead)),
            attendees:body.attendees||[]
          })
        }
        const item=await createMeeting(workspaceId,{
          ...body,
          externalCalendarId:calendar?.externalId||body.externalCalendarId||'',
          meetingLink:calendar?.meetingLink||body.meetingLink||'',
          calendarHtmlLink:calendar?.htmlLink||body.calendarHtmlLink||''
        })
        return send(req,res,201,{...item,calendar})
      }catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'meeting creation failed'})}
    }
    if (req.method === 'POST' && url.pathname === '/api/meetings/reschedule') {
      const body=await readBody(req)
      if(!body.id||!body.startsAt) return send(req,res,400,{error:'id and startsAt required'})
      const current=await getMeeting(workspaceId,String(body.id))
      if(!current) return send(req,res,404,{error:'meeting not found'})
      try{
        let calendar=null
        if(current.external_calendar_id){
          calendar=await updateCalendarEvent(workspaceId,current.external_calendar_id,{...body,startsAt:body.startsAt})
        }else if(body.syncCalendar!==false){
          calendar=await createCalendarEvent(workspaceId,{...body,leadRef:current.lead_ref,startsAt:body.startsAt,title:'Consultation · '+current.lead_ref})
        }
        const item=await rescheduleMeeting(workspaceId,String(body.id),{
          startsAt:body.startsAt,
          externalCalendarId:calendar?.externalId||null,
          meetingLink:calendar?.meetingLink||null,
          calendarHtmlLink:calendar?.htmlLink||null
        })
        return send(req,res,200,{...item,calendar})
      }catch(error){return send(req,res,400,{error:error instanceof Error?error.message:'meeting reschedule failed'})}
    }
    if (req.method === 'POST' && url.pathname === '/api/meetings/remind') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const meeting=await getMeeting(workspaceId,String(body.id))
      if(!meeting) return send(req,res,404,{error:'meeting not found'})
      if(!meeting.attendee_phone&&!meeting.attendee_email) return send(req,res,400,{error:'meeting has no attendee contact; add attendeePhone or attendeeEmail when scheduling'})
      const reminderPayload={
        meetingId:meeting.id,
        leadRef:meeting.lead_ref,
        startsAt:meeting.starts_at,
        owner:meeting.owner,
        attendeePhone:meeting.attendee_phone||null,
        attendeeEmail:meeting.attendee_email||null,
        meetingLink:meeting.meeting_link||null,
        calendarHtmlLink:meeting.calendar_html_link||null
      }
      const run=await createAgentRun(workspaceId,{agentType:'meeting_reminder',entityId:String(body.id),triggerKey:'manual_reminder',input:reminderPayload})
      const job=await handleSubmitJob({workspaceId,kind:'agent_action',idempotencyKey:'agent:'+run.id,payload:{agentRunId:run.id,actionType:'meeting_reminder',payload:{...reminderPayload,runId:run.id}}})
      return send(req,res,202,{id:body.id,runId:run.id,status:'queued',jobId:job?.id||null})
    }
    if (req.method === 'GET' && url.pathname === '/api/feedback') {
      const result=await listPersistedFeedback(workspaceId)
      const items=result.items||[]
      const themes={}
      for(const item of items){
        const key=String(item.theme||'Uncategorized')
        themes[key]=(themes[key]||0)+1
      }
      const low=items.filter(x=>x.score!=null&&Number(x.score)<=2).length
      return send(req,res,200,{
        ...result,
        stats:{responses:items.length,average:result.average,lowSatisfaction:low,themes:Object.keys(themes).length},
        themes:Object.entries(themes).map(([theme,count])=>({theme,count})).sort((a,b)=>b.count-a.count)
      })
    }
    if (req.method === 'POST' && url.pathname === '/api/feedback') {
      const body=await readBody(req)
      if(!body.lead) return send(req,res,400,{error:'lead required'})
      const item=await recordFeedback(workspaceId,body)
      return send(req,res,201,item)
    }
    if (req.method === 'POST' && url.pathname === '/api/feedback/request') {
      const body=await readBody(req)
      if(!body.lead) return send(req,res,400,{error:'lead required'})
      const run=await createAgentRun(workspaceId,{agentType:'feedback',entityId:String(body.leadRef||body.lead),triggerKey:'manual_feedback',input:body})
      const job=await handleSubmitJob({workspaceId,kind:'agent_action',idempotencyKey:'agent:'+run.id,payload:{agentRunId:run.id,actionType:'feedback',payload:{...body,runId:run.id}}})
      return send(req,res,202,{runId:run.id,status:'queued',jobId:job?.id||null})
    }
    if (req.method === 'POST' && url.pathname === '/api/feedback/route') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'feedback id required'})
      const result=await listPersistedFeedback(workspaceId)
      const item=(result.items||[]).find(x=>x.id===String(body.id))
      if(!item) return send(req,res,404,{error:'feedback not found'})
      const score=Number(item.score||0)
      const theme=String(item.theme||'Uncategorized')
      let priority='medium'
      let owner='Customer success'
      let reason='Review customer feedback · '+theme
      let channel='review'
      let delayMinutes=60
      if(score>0&&score<=2){
        priority='high';owner='Customer recovery';reason='Low-satisfaction recovery · '+theme;channel='call';delayMinutes=15
      }else if(/pricing|fee|cost|budget/i.test(theme)){
        priority='high';owner='Sales manager';reason='Pricing objection follow-up · '+theme;channel='call';delayMinutes=30
      }else if(/mismatch|program|product|fit/i.test(theme)){
        priority='medium';owner='Sales operations';reason='Disposition review · '+theme;channel='review';delayMinutes=60
      }else if(score>=4){
        priority='low';owner='Marketing';reason='Promoter / testimonial review · '+theme;channel='email';delayMinutes=240
      }
      const task=await createFollowUp(workspaceId,{leadRef:item.lead_ref,reason,channel,priority,delayMinutes,owner})
      const now=new Date().toISOString()
      await mutateState(s=>{
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'feedback.routed',entityId:item.id,leadRef:item.lead_ref,theme,score,followUpId:task?.id||null,owner,priority,at:now})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,202,{feedbackId:item.id,lead:item.lead_ref,theme,score,status:'routed',nextTab:'Follow-ups',task:task?{id:task.id,status:task.status,owner:task.owner,priority:task.priority,channel:task.channel,dueAt:task.due_at,reason:task.reason}:null})
    }
    if (req.method === 'GET' && url.pathname === '/api/agent-runs') return send(req,res,200,{items:await listAgentRuns(workspaceId,200)})
    if (req.method === 'GET' && url.pathname === '/api/approvals') {
      const state=await getState()
      return send(req,res,200,{items:state.approvals||[]})
    }
    if (req.method === 'POST' && url.pathname === '/api/approvals/decision') {
      const body=await readBody(req)
      if(!body.id || !['approved','rejected'].includes(body.decision)) return send(req,res,400,{error:'id and approved|rejected decision required'})
      let updated=null
      await mutateState(s=>{
        s.approvals=s.approvals||[]
        const item=s.approvals.find(x=>x.id===body.id)
        if(item){
          item.status=body.decision
          item.decidedAt=new Date().toISOString()
          updated={...item}
          if(item.agentId){
            const agent=(s.customAgents||[]).find(x=>x.id===item.agentId)
            if(agent) agent.status=body.decision==='approved'?'active':'rejected'
          }
        }
        s.audit.unshift({id:randomUUID(),action:'approval.'+body.decision,entityId:String(body.id),at:new Date().toISOString()})
      })
      return updated?send(req,res,200,updated):send(req,res,404,{error:'approval not found'})
    }
    if (req.method === 'POST' && url.pathname === '/api/agents/custom') {
      const body=await readBody(req)
      if(!body.name || !body.trigger || !body.action) return send(req,res,400,{error:'name, trigger and action required'})
      const createdAt=new Date().toISOString()
      const requiresApproval=body.requiresApproval!==false
      const agent={id:'agent_'+randomUUID(),name:String(body.name),trigger:String(body.trigger),action:String(body.action),description:String(body.description||''),status:requiresApproval?'pending_approval':'active',type:'custom',createdAt}
      await mutateState(s=>{
        s.customAgents=s.customAgents||[]
        s.customAgents.unshift(agent)
        if(requiresApproval){
          s.approvals=s.approvals||[]
          s.approvals.unshift({id:'ap_'+randomUUID(),kind:'custom_agent_activation',title:'Activate custom agent: '+agent.name,status:'pending',risk:String(body.risk||'medium'),agentId:agent.id,createdAt})
        }
        s.audit.unshift({id:randomUUID(),action:'agent.custom_created',entityId:agent.id,at:createdAt})
      })
      return send(req,res,201,agent)
    }
    if (req.method === 'POST' && url.pathname === '/api/agents/custom/test') {
      const body=await readBody(req)
      if(!body.id) return send(req,res,400,{error:'id required'})
      const state=await getState()
      const agent=(state.customAgents||[]).find(x=>x.id===String(body.id))
      if(!agent) return send(req,res,404,{error:'custom agent not found'})
      if(agent.status==='pending_approval') return send(req,res,409,{error:'custom agent requires approval before testing',status:agent.status,agentId:agent.id})
      if(agent.status==='rejected') return send(req,res,409,{error:'custom agent activation was rejected',status:agent.status,agentId:agent.id})
      if(agent.status!=='active') return send(req,res,409,{error:'custom agent is not active',status:agent.status,agentId:agent.id})
      const entityId=String(body.leadRef||body.entityId||'agent_test')
      const input={
        test:true,
        leadRef:body.leadRef||null,
        trigger:agent.trigger,
        action:agent.action,
        context:body.context&&typeof body.context==='object'?body.context:{}
      }
      const run=await createAgentRun(workspaceId,{agentType:'custom:'+agent.id,entityId,triggerKey:'manual_test',input})
      if(!run) return send(req,res,503,{error:'agent run store unavailable'})
      let operation=null
      if(agent.action==='Route to sales queue'){
        operation=await routeLead(workspaceId,{
          leadRef:entityId,
          score:Number(body.context?.score||85),
          source:String(body.context?.source||'Custom agent'),
          routingRule:{name:agent.name,destination:String(body.context?.destination||'Sales queue'),reason:'Custom agent test: '+agent.trigger,slaSeconds:Number(body.context?.slaSeconds||300)}
        })
      }
      const output={
        test:true,
        evaluated:true,
        trigger:agent.trigger,
        action:agent.action,
        operation:operation?{kind:'routing',id:operation.id,destination:operation.destination,status:operation.status}:null,
        note:operation?'Safe routing action executed and persisted.':'Definition validated. External mutation requires the destination-specific operational workflow and configured integration.'
      }
      const completed=await updateAgentRun(workspaceId,run.id,{status:'succeeded',output})
      await mutateState(s=>{
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'agent.custom_tested',entityId:agent.id,runId:run.id,operationId:operation?.id||null,at:new Date().toISOString()})
        s.audit=s.audit.slice(0,1000)
      })
      return send(req,res,200,{run:completed||run,output})
    }
    if (req.method === 'GET' && url.pathname === '/api/settings') {
      const state=await getState()
      return send(req,res,200,state.workspaceSettings||{})
    }
    if (req.method === 'POST' && url.pathname === '/api/settings') {
      const body=await readBody(req)
      try{
        const keys=Object.keys(body&&typeof body==='object'?body:{})
        const saved=keys.length===1&&keys[0]==='organization'
          ?await handleUpdateOrganization({workspaceId,organization:body.organization,actorId:req.user?.userId||null})
          :await handleUpdateWorkspace({workspaceId,patch:body,actorId:req.user?.userId||null})
        return send(req,res,200,saved)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'workspace settings update failed',code:error?.code||'workspace_settings_update_failed'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/workspaces') {
      const registry=await withWorkspace('ws_default',()=>getState())
      const currentState=await getState()
      const items=await listActorWorkspaces({registry,currentState,currentWorkspaceId:workspaceId,actor:req.user,loadWorkspace:id=>withWorkspace(id,()=>getState())})
      return send(req,res,200,{items})
    }
    if (req.method === 'POST' && url.pathname === '/api/workspaces') {
      const body=await readBody(req)
      const name=String(body.name||'').trim()
      if(name.length<2) return send(req,res,400,{error:'workspace name required'})
      const now=new Date().toISOString()
      let item=null
      await withWorkspace('ws_default',()=>mutateState(s=>{
        s.workspaces=s.workspaces||[]
        if(s.workspaces.some(x=>String(x.name).toLowerCase()===name.toLowerCase())) return
        item={id:'ws_'+randomUUID().replaceAll('-','').slice(0,12),name,environment:String(body.environment||'Production'),initials:String(body.initials||name.split(/\s+/).map(x=>x[0]).join('').slice(0,3)).toUpperCase(),createdAt:now,createdByUserId:req.user?.userId||null}
        s.workspaces.push(item)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'workspace.created',entityId:item.id,name:item.name,at:now})
        s.audit=s.audit.slice(0,1000)
      }))
      if(item){
        await withWorkspace(item.id,()=>mutateState(s=>{
          seedWorkspaceCreator(s,req.user)
          s.audit=s.audit||[]
          s.audit.unshift({id:randomUUID(),action:'workspace.creator_membership_seeded',entityId:req.user?.userId||'unknown',at:now})
          s.audit=s.audit.slice(0,1000)
        }))
        await appendAuditRecord({workspaceId:item.id,actorId:req.user?.userId,action:'workspace.created',entityType:'workspace',entityId:item.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{name:item.name}}).catch(()=>{})
      }
      return item?send(req,res,201,item):send(req,res,409,{error:'workspace name already exists'})
    }
    if (req.method === 'GET' && url.pathname === '/api/audit-log') {
      const durable=await handleSearchAudit({
        workspaceId,
        limit:Number(url.searchParams.get('limit')||250),
        before:url.searchParams.get('before')||null
      }).catch(()=>[])
      if(durable.length)return send(req,res,200,{items:durable,source:'durable'})
      const state=await getState()
      return send(req,res,200,{items:(state.audit||[]).slice(0,250),source:'compatibility'})
    }
    if (req.method === 'POST' && url.pathname === '/api/audit-log/export') {
      try{
        const job=await handleExportAudit({
          workspaceId,
          limit:Number(url.searchParams.get('limit')||500),
          before:url.searchParams.get('before')||null,
          actorId:req.user?.userId||null,
          requestId:req.requestId
        })
        return send(req,res,202,{jobId:job.id,status:job.status,resultSchemaVersion:'audit-export.v1'})
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'audit export failed',code:error?.code||'audit_export_failed'})
      }
    }
    if (req.method === 'GET' && url.pathname === '/api/api-keys') {
      const state=await getState()
      const items=(state.apiKeys||[]).map(x=>({
        id:x.id,
        name:x.name,
        prefix:x.prefix,
        status:x.status||'active',
        createdAt:x.createdAt,
        revokedAt:x.revokedAt||null,
        lastUsedAt:x.lastUsedAt||null
      })).sort((a,b)=>Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0))
      return send(req,res,200,{items,active:items.filter(x=>x.status==='active').length})
    }
    if (req.method === 'POST' && url.pathname === '/api/api-keys') {
      const body=await readBody(req)
      const label=String(body.name||'workspace').trim()
      if(label.length<2||label.length>80) return send(req,res,400,{error:'name must be 2-80 characters'})
      const secret='ace_'+randomBytes(24).toString('base64url')
      const fingerprint=createHash('sha256').update(secret).digest('hex')
      const createdAt=new Date().toISOString()
      const record={id:'key_'+randomUUID(),name:label,prefix:secret.slice(0,12),fingerprint,status:'active',createdAt,lastUsedAt:null,revokedAt:null}
      await mutateState(s=>{
        s.apiKeys=s.apiKeys||[]
        s.apiKeys.unshift(record)
        s.apiKeys=s.apiKeys.slice(0,200)
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'api_key.created',entityId:record.id,name:record.name,at:createdAt})
        s.audit=s.audit.slice(0,1000)
      })
      await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'api_key.created',entityType:'api_key',entityId:record.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{name:record.name,prefix:record.prefix}})
      return send(req,res,201,{id:record.id,name:record.name,prefix:record.prefix,key:secret,createdAt,notice:'Store this key now; only its SHA-256 fingerprint is persisted.'})
    }
    if (req.method === 'POST' && url.pathname === '/api/api-keys/revoke') {
      const body=await readBody(req)
      const id=String(body.id||'')
      if(!id) return send(req,res,400,{error:'id required'})
      const snapshot=await getState()
      const existing=(snapshot.apiKeys||[]).find(x=>x.id===id)
      if(!existing) return send(req,res,404,{error:'api key not found'})
      if(existing.status==='revoked') return send(req,res,200,{id,status:'revoked',revokedAt:existing.revokedAt||null})
      const revokedAt=new Date().toISOString()
      await mutateState(s=>{
        const key=(s.apiKeys||[]).find(x=>x.id===id)
        if(key){key.status='revoked';key.revokedAt=revokedAt}
        s.audit=s.audit||[]
        s.audit.unshift({id:randomUUID(),action:'api_key.revoked',entityId:id,at:revokedAt})
        s.audit=s.audit.slice(0,1000)
      })
      await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'api_key.revoked',entityType:'api_key',entityId:id,requestId:req.requestId,traceId:req.context?.traceId})
      return send(req,res,200,{id,status:'revoked',revokedAt})
    }

    if (req.method === 'GET' && url.pathname === '/api/files') {
      const limit=Number(url.searchParams.get('limit')||100)
      return send(req,res,200,{items:await listObjects({workspaceId,role:req.user?.role||'viewer',limit})})
    }
    if (req.method === 'POST' && url.pathname === '/api/files/upload-intents') {
      const body=await readBody(req)
      try{
        const intent=await handleAuthorizeUpload({
          workspaceId,
          name:body.name,
          mime:body.mime,
          size:body.size,
          sha256:body.sha256,
          accessPolicy:body.accessPolicy||{},
          actorId:req.user?.userId||null
        })
        await appendAuditRecord({
          workspaceId,
          actorId:req.user?.userId,
          action:'object.upload_intent_created',
          entityType:'object',
          entityId:intent.object.id,
          requestId:req.requestId,
          traceId:req.context?.traceId,
          metadata:{name:intent.object.original_name,size:Number(intent.object.expected_size)}
        }).catch(()=>{})
        return send(req,res,201,intent)
      }catch(error){
        return send(req,res,Number(error?.status||400),{
          error:error instanceof Error?error.message:'upload intent creation failed',
          code:error?.code||'object_upload_intent_failed'
        })
      }
    }
    const objectQuarantineMatch=url.pathname.match(/^\/api\/files\/([^/]+)\/quarantine-confirm$/)
    if(req.method==='POST'&&objectQuarantineMatch){
      if(!OBJECT_WORKER_TOKEN)return send(req,res,503,{error:'object verification worker is not configured',code:'object_worker_unavailable'})
      const supplied=String(req.headers['x-object-worker-token']||'')
      const expected=Buffer.from(OBJECT_WORKER_TOKEN)
      const actual=Buffer.from(supplied)
      if(actual.length!==expected.length||!timingSafeEqual(actual,expected)){
        return send(req,res,403,{error:'object worker authorization failed',code:'object_worker_forbidden'})
      }
      const body=await readBody(req)
      try{
        const result=await markObjectQuarantined({
          workspaceId,
          objectId:decodeURIComponent(objectQuarantineMatch[1]),
          grantToken:body.grantToken,
          actualSize:body.actualSize,
          actualSha256:body.actualSha256,
          detectedMime:body.detectedMime,
          storageProvider:body.storageProvider||'s3',
          storageVersion:body.storageVersion||null
        })
        return send(req,res,result.integrityMatched?200:422,result)
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'object quarantine confirmation failed'})
      }
    }
    const objectScanMatch=url.pathname.match(/^\/api\/files\/([^/]+)\/scan-result$/)
    if(req.method==='POST'&&objectScanMatch){
      if(!OBJECT_WORKER_TOKEN)return send(req,res,503,{error:'object scanning worker is not configured',code:'object_worker_unavailable'})
      const supplied=String(req.headers['x-object-worker-token']||'')
      const expected=Buffer.from(OBJECT_WORKER_TOKEN)
      const actual=Buffer.from(supplied)
      if(actual.length!==expected.length||!timingSafeEqual(actual,expected)){
        return send(req,res,403,{error:'object worker authorization failed',code:'object_worker_forbidden'})
      }
      const body=await readBody(req)
      try{
        const item=await handleApproveFile({
          workspaceId,
          objectId:decodeURIComponent(objectScanMatch[1]),
          result:body.result,
          evidence:body.evidence||{},
          actorId:req.user?.userId||'object-worker'
        })
        await appendAuditRecord({
          workspaceId,
          actorId:req.user?.userId||'object-worker',
          action:'object.scan_recorded',
          entityType:'object',
          entityId:item.id,
          requestId:req.requestId,
          traceId:req.context?.traceId,
          metadata:{scanStatus:item.scan_status,status:item.status}
        }).catch(()=>{})
        return send(req,res,200,item)
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'object scan recording failed'})
      }
    }
    const objectIndexMatch=url.pathname.match(/^\/api\/files\/([^/]+)\/index-extracted$/)
    if(req.method==='POST'&&objectIndexMatch){
      if(!OBJECT_WORKER_TOKEN)return send(req,res,503,{error:'document processing worker is not configured',code:'object_worker_unavailable'})
      const supplied=String(req.headers['x-object-worker-token']||'')
      const expected=Buffer.from(OBJECT_WORKER_TOKEN)
      const actual=Buffer.from(supplied)
      if(actual.length!==expected.length||!timingSafeEqual(actual,expected)){
        return send(req,res,403,{error:'object worker authorization failed',code:'object_worker_forbidden'})
      }
      const body=await readBody(req)
      const objectId=decodeURIComponent(objectIndexMatch[1])
      try{
        const item=await handleRebuildSearchIndex({
          workspaceId,
          objectId,
          text:body.text,
          evidence:body.evidence||{}
        })
        await appendAuditRecord({
          workspaceId,
          actorId:req.user?.userId||'document-worker',
          action:'object.indexed',
          entityType:'object',
          entityId:objectId,
          requestId:req.requestId,
          traceId:req.context?.traceId,
          metadata:{storageVersion:item.approved_storage_version,sha256:item.approved_sha256}
        }).catch(()=>{})
        return send(req,res,200,item)
      }catch(error){
        await markObjectProcessingFailure({
          workspaceId,
          objectId,
          stage:'index',
          error:error instanceof Error?error.message:'document indexing failed',
          evidence:body.evidence||{}
        }).catch(()=>{})
        return send(req,res,400,{error:error instanceof Error?error.message:'document indexing failed'})
      }
    }

    if(req.method==='GET'&&url.pathname==='/api/search'){
      const query=url.searchParams.get('q')||''
      const limit=Number(url.searchParams.get('limit')||20)
      const sourceType=url.searchParams.get('sourceType')||null
      try{
        const result=await handleQuerySearch({
          workspaceId,
          query,
          role:req.user?.role||'viewer',
          limit,
          sourceType
        })
        return send(req,res,200,result)
      }catch(error){
        return send(req,res,400,{error:error instanceof Error?error.message:'search failed',profile:searchCapabilityProfile()})
      }
    }

    const objectDownloadMatch=url.pathname.match(/^\/api\/files\/([^/]+)\/download-grant$/)
    if(req.method==='POST'&&objectDownloadMatch){
      try{
        const grant=await createDownloadGrant({
          workspaceId,
          objectId:decodeURIComponent(objectDownloadMatch[1]),
          role:req.user?.role||'viewer',
          actorId:req.user?.userId||null
        })
        return send(req,res,201,grant)
      }catch(error){
        const message=error instanceof Error?error.message:'download grant failed'
        const status=/denied/.test(message)?403:/not found/.test(message)?404:400
        return send(req,res,status,{error:message})
      }
    }
    const objectDeleteMatch=url.pathname.match(/^\/api\/files\/([^/]+)$/)
    if(req.method==='DELETE'&&objectDeleteMatch){
      if(!['owner','admin'].includes(req.user?.role||''))return send(req,res,403,{error:'owner or admin role required'})
      try{
        const item=await softDeleteObject({
          workspaceId,
          objectId:decodeURIComponent(objectDeleteMatch[1]),
          actorId:req.user?.userId||null
        })
        if(!item)return send(req,res,404,{error:'object not found'})
        await appendAuditRecord({
          workspaceId,
          actorId:req.user?.userId,
          action:'object.deleted',
          entityType:'object',
          entityId:item.id,
          requestId:req.requestId,
          traceId:req.context?.traceId
        }).catch(()=>{})
        return send(req,res,200,item)
      }catch(error){
        return send(req,res,409,{error:error instanceof Error?error.message:'object deletion blocked'})
      }
    }

    if (req.method === 'GET' && url.pathname === '/api/forms') {
      const limit=Number(url.searchParams.get('limit')||100)
      return send(req,res,200,{items:await listForms({workspaceId,limit})})
    }
    if (req.method === 'POST' && url.pathname === '/api/forms') {
      const body=await readBody(req)
      try{
        const form=await createForm({
          workspaceId,
          name:body.name,
          slug:body.slug,
          description:body.description,
          schema:body.schema,
          actorId:req.user?.userId||null
        })
        await appendAuditRecord({
          workspaceId,
          actorId:req.user?.userId,
          action:'form.created',
          entityType:'form',
          entityId:form.id,
          requestId:req.requestId,
          traceId:req.context?.traceId,
          metadata:{slug:form.slug}
        }).catch(()=>{})
        return send(req,res,201,form)
      }catch(error){
        const status=Number(error?.status||(/unique|duplicate/i.test(String(error?.message||''))?409:400))
        return send(req,res,status,{error:error instanceof Error?error.message:'form creation failed',code:error?.code||'form_create_failed'})
      }
    }
    const formMatch=url.pathname.match(/^\/api\/forms\/([^/]+)$/)
    if(req.method==='GET'&&formMatch){
      const form=await getForm({workspaceId,id:decodeURIComponent(formMatch[1])})
      return form?send(req,res,200,form):send(req,res,404,{error:'form not found'})
    }
    const publishMatch=url.pathname.match(/^\/api\/forms\/([^/]+)\/publish$/)
    if(req.method==='POST'&&publishMatch){
      const form=await handlePublishForm({workspaceId,id:decodeURIComponent(publishMatch[1]),actorId:req.user?.userId||null})
      if(!form)return send(req,res,404,{error:'form not found'})
      await appendAuditRecord({
        workspaceId,
        actorId:req.user?.userId,
        action:'form.published',
        entityType:'form',
        entityId:form.id,
        requestId:req.requestId,
        traceId:req.context?.traceId,
        metadata:{version:Number(form.published_version||0)}
      }).catch(()=>{})
      return send(req,res,200,form)
    }
    const submissionsMatch=url.pathname.match(/^\/api\/forms\/([^/]+)\/submissions$/)
    if(req.method==='POST'&&submissionsMatch){
      const body=await readBody(req)
      try{
        const submission=await handleSubmitForm({
          workspaceId,
          id:decodeURIComponent(submissionsMatch[1]),
          data:body.data,
          actorId:req.user?.userId||null,
          submissionId:body.submissionId||req.headers['idempotency-key']||null
        })
        if(!submission)return send(req,res,404,{error:'published form not found'})
        return send(req,res,201,submission)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'submission failed',code:error?.code||'form_submission_failed'})
      }
    }
    if(req.method==='GET'&&submissionsMatch){
      const limit=Number(url.searchParams.get('limit')||100)
      return send(req,res,200,{items:await listFormSubmissions({workspaceId,id:decodeURIComponent(submissionsMatch[1]),limit})})
    }


    if(req.method==='GET'&&url.pathname==='/api/custom-objects'){
      const limit=Number(url.searchParams.get('limit')||100)
      return send(req,res,200,{items:await listCustomObjects({workspaceId,limit})})
    }
    if(req.method==='POST'&&url.pathname==='/api/custom-objects'){
      const body=await readBody(req)
      try{
        const object=await handleDefineCustomObject({
          workspaceId,
          objectKey:body.objectKey,
          name:body.name,
          description:body.description,
          schema:body.schema,
          actorId:req.user?.userId||null
        })
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'custom_object.created',entityType:'custom_object',entityId:object.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{objectKey:object.object_key}}).catch(()=>{})
        return send(req,res,201,object)
      }catch(error){
        const status=Number(error?.status||(/unique|duplicate/i.test(String(error?.message||''))?409:400))
        return send(req,res,status,{error:error instanceof Error?error.message:'custom object creation failed',code:error?.code||'custom_object_create_failed'})
      }
    }
    const customObjectMatch=url.pathname.match(/^\/api\/custom-objects\/([^/]+)$/)
    if(req.method==='GET'&&customObjectMatch){
      const object=await getCustomObject({workspaceId,id:decodeURIComponent(customObjectMatch[1])})
      return object?send(req,res,200,object):send(req,res,404,{error:'custom object not found'})
    }
    const customObjectVersionMatch=url.pathname.match(/^\/api\/custom-objects\/([^/]+)\/versions$/)
    if(req.method==='POST'&&customObjectVersionMatch){
      const body=await readBody(req)
      try{
        const object=await createCustomObjectVersion({workspaceId,id:decodeURIComponent(customObjectVersionMatch[1]),schema:body.schema,actorId:req.user?.userId||null})
        if(!object)return send(req,res,404,{error:'custom object not found'})
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'custom_object.version_created',entityType:'custom_object',entityId:object.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{version:Number(object.version||object.latest_version||0)}}).catch(()=>{})
        return send(req,res,201,object)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'custom object version failed',code:error?.code||'custom_object_version_failed'})
      }
    }
    const customObjectPublishMatch=url.pathname.match(/^\/api\/custom-objects\/([^/]+)\/publish$/)
    if(req.method==='POST'&&customObjectPublishMatch){
      const object=await publishCustomObject({workspaceId,id:decodeURIComponent(customObjectPublishMatch[1]),actorId:req.user?.userId||null})
      if(!object)return send(req,res,404,{error:'custom object not found'})
      await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'custom_object.published',entityType:'custom_object',entityId:object.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{version:Number(object.published_version||0)}}).catch(()=>{})
      return send(req,res,200,object)
    }
    const customObjectRecordsMatch=url.pathname.match(/^\/api\/custom-objects\/([^/]+)\/records$/)
    if(req.method==='POST'&&customObjectRecordsMatch){
      const body=await readBody(req)
      try{
        const record=await createCustomObjectRecord({
          workspaceId,
          id:decodeURIComponent(customObjectRecordsMatch[1]),
          data:body.data,
          actorId:req.user?.userId||null,
          recordId:body.recordId||req.headers['idempotency-key']||null
        })
        if(!record)return send(req,res,404,{error:'published custom object not found'})
        return send(req,res,201,record)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'custom object record failed',code:error?.code||'custom_object_record_failed'})
      }
    }
    if(req.method==='GET'&&customObjectRecordsMatch){
      const limit=Number(url.searchParams.get('limit')||100)
      return send(req,res,200,{items:await listCustomObjectRecords({workspaceId,id:decodeURIComponent(customObjectRecordsMatch[1]),limit})})
    }


    if(req.method==='GET'&&url.pathname==='/api/policy-rules'){
      return send(req,res,200,{items:await listPolicyRules({workspaceId,limit:Number(url.searchParams.get('limit')||100)})})
    }
    if(req.method==='POST'&&url.pathname==='/api/policy-rules/simulate'){
      const body=await readBody(req)
      try{
        return send(req,res,200,handleSimulateRule({expression:body.expression,input:body.input||{}}))
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'policy simulation failed',code:error?.code||'policy_simulation_failed'})
      }
    }
    if(req.method==='POST'&&url.pathname==='/api/policy-rules'){
      const body=await readBody(req)
      try{
        const rule=await createPolicyRule({workspaceId,name:body.name,expression:body.expression,inputSchemaVersion:body.inputSchemaVersion,actorId:req.user?.userId||null})
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'policy_rule.created',entityType:'policy_rule',entityId:rule.id,requestId:req.requestId,traceId:req.context?.traceId}).catch(()=>{})
        return send(req,res,201,rule)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'policy rule creation failed',code:error?.code||'policy_rule_create_failed'})
      }
    }
    const policyMatch=url.pathname.match(/^\/api\/policy-rules\/([^/]+)$/)
    if(req.method==='GET'&&policyMatch){
      const rule=await getPolicyRule({workspaceId,id:decodeURIComponent(policyMatch[1])})
      return rule?send(req,res,200,rule):send(req,res,404,{error:'policy rule not found'})
    }
    const policyVersionMatch=url.pathname.match(/^\/api\/policy-rules\/([^/]+)\/versions$/)
    if(req.method==='POST'&&policyVersionMatch){
      const body=await readBody(req)
      try{
        const rule=await createPolicyRuleVersion({
          workspaceId,
          id:decodeURIComponent(policyVersionMatch[1]),
          expression:body.expression,
          inputSchemaVersion:body.inputSchemaVersion,
          actorId:req.user?.userId||null
        })
        if(!rule)return send(req,res,404,{error:'policy rule not found'})
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'policy_rule.version_created',entityType:'policy_rule',entityId:rule.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{version:Number(rule.version||rule.latest_version||0)}}).catch(()=>{})
        return send(req,res,201,rule)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'policy rule version failed',code:error?.code||'policy_rule_version_failed'})
      }
    }
    const policyPublishMatch=url.pathname.match(/^\/api\/policy-rules\/([^/]+)\/publish$/)
    if(req.method==='POST'&&policyPublishMatch){
      const rule=await handlePublishPolicy({workspaceId,id:decodeURIComponent(policyPublishMatch[1])})
      if(!rule)return send(req,res,404,{error:'policy rule not found'})
      await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'policy_rule.published',entityType:'policy_rule',entityId:rule.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{version:Number(rule.published_version||0)}}).catch(()=>{})
      return send(req,res,200,rule)
    }
    const policyArchiveMatch=url.pathname.match(/^\/api\/policy-rules\/([^/]+)\/archive$/)
    if(req.method==='POST'&&policyArchiveMatch){
      const rule=await archivePolicyRule({workspaceId,id:decodeURIComponent(policyArchiveMatch[1])})
      if(!rule)return send(req,res,404,{error:'policy rule not found'})
      await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'policy_rule.archived',entityType:'policy_rule',entityId:rule.id,requestId:req.requestId,traceId:req.context?.traceId}).catch(()=>{})
      return send(req,res,200,rule)
    }
    const policyEvaluateMatch=url.pathname.match(/^\/api\/policy-rules\/([^/]+)\/evaluate$/)
    if(req.method==='POST'&&policyEvaluateMatch){
      const body=await readBody(req)
      const decision=await evaluatePublishedPolicyRule({workspaceId,id:decodeURIComponent(policyEvaluateMatch[1]),input:body.input||{}})
      return decision?send(req,res,200,decision):send(req,res,404,{error:'published policy rule not found'})
    }

    if(req.method==='GET'&&url.pathname==='/api/boards'){
      try{
        const items=await listBoards({workspaceId,limit:Number(url.searchParams.get('limit')||100)})
        return send(req,res,200,{items})
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'board list failed',code:error?.code||'BOARD_LIST_FAILED'})
      }
    }

    if(req.method==='POST'&&url.pathname==='/api/boards'){
      const body=await readBody(req)
      try{
        const item=await createBoard({
          workspaceId,
          actorId:req.user?.userId||null,
          name:body?.name
        })
        return send(req,res,201,{item})
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'board creation failed',code:error?.code||'BOARD_CREATE_FAILED'})
      }
    }

    const boardSnapshotMatch=url.pathname.match(/^\/api\/boards\/([^/]+)$/)
    if(req.method==='GET'&&boardSnapshotMatch){
      try{
        const snapshot=await getBoardSnapshot({workspaceId,boardId:decodeURIComponent(boardSnapshotMatch[1])})
        return snapshot?send(req,res,200,snapshot):send(req,res,404,{error:'board not found',code:'BOARD_NOT_FOUND'})
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'board read failed',code:error?.code||'BOARD_READ_FAILED'})
      }
    }

    const boardMoveMatch=url.pathname.match(/^\/api\/boards\/([^/]+)\/moves$/)
    if(req.method==='POST'&&boardMoveMatch){
      const body=await readBody(req)
      const boardId=decodeURIComponent(boardMoveMatch[1])
      try{
        const result=await moveCardController({
          workspaceId,
          actorId:req.user?.userId||null,
          requestId:req.requestId,
          correlationId:req.context?.traceId||req.requestId,
          boardId,
          body,
          canMove:Boolean(req.user?hasPermission(req.user.role,'boards.move'):!AUTH_REQUIRED)
        })
        return send(req,res,200,result)
      }catch(error){
        const status=Number(error?.status||500)
        return send(req,res,status,{
          error:error instanceof Error?error.message:'board move failed',
          code:error?.code||'BOARD_MOVE_FAILED',
          operationId:body?.operationId||null,
          retryable:Boolean(error?.retryable),
          ...(error?.currentVersion?{currentVersion:error.currentVersion}:{}),
          ...(error?.currentPolicyVersion?{currentPolicyVersion:error.currentPolicyVersion}:{})
        })
      }
    }

    const boardOperationMatch=url.pathname.match(/^\/api\/boards\/([^/]+)\/operations\/([^/]+)$/)
    if(req.method==='GET'&&boardOperationMatch){
      try{
        const operation=await getBoardOperation({
          workspaceId,
          boardId:decodeURIComponent(boardOperationMatch[1]),
          operationId:decodeURIComponent(boardOperationMatch[2])
        })
        return operation?send(req,res,200,operation):send(req,res,404,{error:'board operation not found',code:'BOARD_OPERATION_NOT_FOUND'})
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'board operation lookup failed',code:error?.code||'BOARD_OPERATION_LOOKUP_FAILED'})
      }
    }

    if(req.method==='GET'&&url.pathname==='/api/workflows/actions'){
      return send(req,res,200,{version:1,items:workflowActionCatalog()})
    }
    if(req.method==='POST'&&url.pathname==='/api/workflows/simulate'){
      const body=await readBody(req)
      try{
        return send(req,res,200,simulateWorkflowDefinition(body.definition))
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'workflow simulation failed',code:error?.code||'workflow_simulation_failed'})
      }
    }
    if(req.method==='GET'&&url.pathname==='/api/workflows'){
      return send(req,res,200,{items:await listWorkflows({workspaceId,limit:Number(url.searchParams.get('limit')||100)})})
    }
    if(req.method==='POST'&&url.pathname==='/api/workflows'){
      const body=await readBody(req)
      try{
        const workflow=await createWorkflow({workspaceId,name:body.name,definition:body.definition,actorId:req.user?.userId||null})
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'workflow.created',entityType:'workflow',entityId:workflow.id,requestId:req.requestId,traceId:req.context?.traceId}).catch(()=>{})
        return send(req,res,201,workflow)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'workflow creation failed',code:error?.code||'workflow_create_failed'})
      }
    }
    if(req.method==='GET'&&url.pathname==='/api/workflows/executions'){
      return send(req,res,200,{items:await listWorkflowExecutions({workspaceId,workflowId:url.searchParams.get('workflowId')||null,limit:Number(url.searchParams.get('limit')||100)})})
    }
    if(req.method==='GET'&&url.pathname==='/api/workflows/approvals'){
      return send(req,res,200,{items:await listWorkflowApprovals({workspaceId,status:url.searchParams.get('status')||null,limit:Number(url.searchParams.get('limit')||100)})})
    }
    const workflowExecutionStepsMatch=url.pathname.match(/^\/api\/workflows\/executions\/([^/]+)\/steps$/)
    if(req.method==='GET'&&workflowExecutionStepsMatch){
      return send(req,res,200,{items:await listWorkflowExecutionSteps({workspaceId,executionId:decodeURIComponent(workflowExecutionStepsMatch[1])})})
    }
    const workflowExecutionCancelMatch=url.pathname.match(/^\/api\/workflows\/executions\/([^/]+)\/cancel$/)
    if(req.method==='POST'&&workflowExecutionCancelMatch){
      const execution=await cancelWorkflowExecution({workspaceId,executionId:decodeURIComponent(workflowExecutionCancelMatch[1]),actorId:req.user?.userId||null})
      if(!execution)return send(req,res,404,{error:'workflow execution not found'})
      await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'workflow.execution_cancelled',entityType:'workflow_execution',entityId:execution.id,requestId:req.requestId,traceId:req.context?.traceId}).catch(()=>{})
      return send(req,res,200,execution)
    }
    const workflowExecutionRetryMatch=url.pathname.match(/^\/api\/workflows\/executions\/([^/]+)\/retry$/)
    if(req.method==='POST'&&workflowExecutionRetryMatch){
      try{
        const execution=await handleRetryWorkflowExecution({workspaceId,executionId:decodeURIComponent(workflowExecutionRetryMatch[1]),actorId:req.user?.userId||null})
        if(!execution)return send(req,res,404,{error:'workflow execution not found'})
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'workflow.execution_retried',entityType:'workflow_execution',entityId:execution.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{attempts:Number(execution.attempts||0)}}).catch(()=>{})
        return send(req,res,200,execution)
      }catch(error){
        return send(req,res,Number(error?.status||409),{error:error instanceof Error?error.message:'workflow retry failed',code:error?.code||'workflow_retry_failed'})
      }
    }
    const workflowMatch=url.pathname.match(/^\/api\/workflows\/([^/]+)$/)
    if(req.method==='GET'&&workflowMatch){
      const workflow=await getWorkflow({workspaceId,id:decodeURIComponent(workflowMatch[1])})
      return workflow?send(req,res,200,workflow):send(req,res,404,{error:'workflow not found'})
    }
    const workflowVersionMatch=url.pathname.match(/^\/api\/workflows\/([^/]+)\/versions$/)
    if(req.method==='POST'&&workflowVersionMatch){
      const body=await readBody(req)
      try{
        const workflow=await createWorkflowVersion({workspaceId,id:decodeURIComponent(workflowVersionMatch[1]),definition:body.definition,actorId:req.user?.userId||null})
        if(!workflow)return send(req,res,404,{error:'workflow not found'})
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'workflow.version_created',entityType:'workflow',entityId:workflow.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{version:Number(workflow.version||workflow.latest_version||0)}}).catch(()=>{})
        return send(req,res,201,workflow)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'workflow version failed',code:error?.code||'workflow_version_failed'})
      }
    }
    const workflowArchiveMatch=url.pathname.match(/^\/api\/workflows\/([^/]+)\/archive$/)
    if(req.method==='POST'&&workflowArchiveMatch){
      try{
        const workflow=await archiveWorkflow({workspaceId,id:decodeURIComponent(workflowArchiveMatch[1]),actorId:req.user?.userId||null})
        if(!workflow)return send(req,res,404,{error:'workflow not found'})
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'workflow.archived',entityType:'workflow',entityId:workflow.id,requestId:req.requestId,traceId:req.context?.traceId}).catch(()=>{})
        return send(req,res,200,workflow)
      }catch(error){
        return send(req,res,Number(error?.status||409),{error:error instanceof Error?error.message:'workflow archive failed',code:error?.code||'workflow_archive_failed'})
      }
    }
    const workflowPublishMatch=url.pathname.match(/^\/api\/workflows\/([^/]+)\/publish$/)
    if(req.method==='POST'&&workflowPublishMatch){
      const workflow=await handlePublishWorkflow({workspaceId,id:decodeURIComponent(workflowPublishMatch[1])})
      if(!workflow)return send(req,res,404,{error:'workflow not found'})
      await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'workflow.published',entityType:'workflow',entityId:workflow.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{version:Number(workflow.published_version||0)}}).catch(()=>{})
      return send(req,res,200,workflow)
    }
    const workflowStartMatch=url.pathname.match(/^\/api\/workflows\/([^/]+)\/executions$/)
    if(req.method==='POST'&&workflowStartMatch){
      const body=await readBody(req)
      const execution=await startWorkflowExecution({
        workspaceId,
        id:decodeURIComponent(workflowStartMatch[1]),
        actorId:req.user?.userId||null,
        triggerType:body.triggerType||'manual',
        triggerRef:body.triggerRef||null,
        correlationId:req.context?.requestId||null,
        causationId:body.causationId||null,
        deadlineAt:body.deadlineAt||null
      })
      return execution?send(req,res,202,execution):send(req,res,404,{error:'published workflow not found'})
    }
    const approvalCreateMatch=url.pathname.match(/^\/api\/workflows\/executions\/([^/]+)\/approvals$/)
    if(req.method==='POST'&&approvalCreateMatch){
      const body=await readBody(req)
      const approval=await createWorkflowApproval({
        workspaceId,
        executionId:decodeURIComponent(approvalCreateMatch[1]),
        nodeId:String(body.nodeId||''),
        requestedBy:req.user?.userId||null,
        approverScope:body.approverScope||null,
        policyVersion:body.policyVersion||null
      })
      return approval?send(req,res,201,approval):send(req,res,404,{error:'workflow execution not found'})
    }
    const approvalDecisionMatch=url.pathname.match(/^\/api\/workflows\/approvals\/([^/]+)\/decision$/)
    if(req.method==='POST'&&approvalDecisionMatch){
      const body=await readBody(req)
      try{
        const approval=await handleDecideApproval({
          workspaceId,
          approvalId:decodeURIComponent(approvalDecisionMatch[1]),
          actorId:req.user?.userId||null,
          decision:body.decision,
          comment:body.comment||''
        })
        if(!approval)return send(req,res,404,{error:'workflow approval not found'})
        await appendAuditRecord({workspaceId,actorId:req.user?.userId,action:'workflow.approval_decided',entityType:'workflow_approval',entityId:approval.id,requestId:req.requestId,traceId:req.context?.traceId,metadata:{decision:approval.status}}).catch(()=>{})
        return send(req,res,200,approval)
      }catch(error){
        return send(req,res,Number(error?.status||400),{error:error instanceof Error?error.message:'workflow approval failed',code:error?.code||'workflow_approval_failed'})
      }
    }

    return send(req,res,404,{error:'not found'})
  } catch (error) {
    return send(req,res,500,{error:error instanceof Error?error.message:'internal error'})
  }
  })
})

installLiveVoiceWebSocket(server)
server.keepAliveTimeout=65_000
server.headersTimeout=66_000
server.requestTimeout=30_000
server.listen(PORT,()=>{markStartupComplete();console.log(`AceMarketing API listening on http://localhost:${PORT}`)})
const shutdown=signal=>{beginProcessDrain();console.log(`${signal} received; draining before shutdown`);server.close(async err=>{await Promise.allSettled([closeStore(),closeAttributionStore(),closeLeadOps(),closeAgentOrchestrator(),closeCustomIntegrations(),closeObservability(),closeEntitlements(),closeBillingProvider(),closeConsentStore(),closePrivacyOps(),closeAudienceScheduler(),closeCohortAnalytics(),closeEventRules(),closeAiRuntime(),closeKnowledge(),closeAiDatasets(),closeLiveVoice()]);process.exit(err?1:0)});setTimeout(()=>process.exit(1),10_000).unref()}
process.on('SIGTERM',()=>shutdown('SIGTERM'))
process.on('SIGINT',()=>shutdown('SIGINT'))
