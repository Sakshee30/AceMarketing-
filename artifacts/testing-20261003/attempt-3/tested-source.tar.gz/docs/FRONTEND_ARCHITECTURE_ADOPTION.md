# AceMarketing Frontend Architecture Adoption

This document records the incremental adoption of the uploaded **Unified SaaS Platform Architecture Standard v2.0** for the existing AceMarketing frontend.

## Non-destructive migration rule

AceMarketing keeps the current product pipeline and all existing product features. Architecture improvements are introduced incrementally around working behavior. We do not create a second active frontend tree for the same feature, and we do not perform a one-shot folder rewrite simply to resemble the target diagram.

## Current adoption

### Application and route failure containment
- Global application render boundary wraps the React product.
- Existing workspace-section boundary remains in place for feature containment.
- A failed workspace feature cannot remove sidebar navigation or the rest of the customer shell.
- Recovery UI provides retry and full-application reload paths without claiming backend data was changed.
- The pre-JavaScript HTML now contains a useful startup state so bundle/bootstrap failure does not leave a blank page.

### Public runtime configuration safety
- The browser validates public runtime configuration before mounting the customer application.
- Only same-origin relative API base paths are accepted by the public configuration helper.
- Release ID and environment are exposed as public root metadata for support/telemetry correlation.
- Request timeout values are bounded to prevent accidental zero/unbounded browser deadlines.

### Accessible navigation
- Workspace exposes a keyboard-accessible skip link.
- Workspace tab changes update the document title.
- Active-page changes are announced through an ARIA live region.
- Focus moves to the active page heading after intentional section navigation.
- Page headings accept programmatic focus and retain visible focus styling.

### Reusable customer-state primitives
- Shared loading, empty, error, forbidden, degraded and stale states now exist as owned frontend primitives.
- State primitives preserve honest language and expose a consistent accessible action affordance.
- Feature teams can adopt these incrementally without replacing existing feature behavior.

### Mutation lifecycle contract
- A reusable lifecycle helper now models IDLE, VALIDATING, SUBMITTING, CONFIRMED_SUCCESS, CONFIRMED_REJECTION, CONFLICT and OUTCOME_UNKNOWN.
- Operation IDs are generated independently from button state so feature mutations can reconcile lost acknowledgements without treating a timeout as confirmed failure.
- Existing critical mutations remain unchanged until each feature is migrated and verified.

### Workspace scope isolation
- Workspace switching now uses confirm-before-commit behavior.
- The target workspace ID is verified through the backend before its label becomes active.
- Previous workspace content is hidden during verification instead of being relabeled as the target workspace.
- Failed verification restores the prior workspace identity and provides explicit retry/stay actions.
- A successful workspace switch increments a scope generation and remounts the active feature so old feature state cannot be reused under the new workspace.
- Dashboard summary polling is generation-scoped and restarts after confirmed workspace changes.

### Shared transport and request budgets
- The shared browser transport now owns a bounded request deadline.
- Every request has a client correlation ID and an internal AbortController.
- Transport cancellation produces a normalized aborted state; deadline expiry produces a distinct timeout/unknown-confirmation state.
- Workspace switching cancels in-flight old-scope browser requests before resolving the new scope.
- Existing endpoint semantics are unchanged; the transport tightening is additive.

### Lightweight workspace feature manifest
- A canonical lightweight manifest now inventories every existing workspace surface without moving or deleting feature implementations.
- Stable feature IDs and route IDs are separated from labels so later route extraction can happen incrementally.
- The manifest marks long-form surfaces that require dirty-work protection before navigation behavior is migrated.
- Existing `AcePlatform.tsx` composition remains authoritative until each feature slice is extracted and verified.

### First critical mutation migration
- Human Approvals is the first critical write surface migrated to the explicit frontend mutation lifecycle.
- Confirmed backend decisions are distinct from rejection, conflict and outcome-unknown states.
- Network loss or request timeout no longer gets presented as a confirmed failure; the UI instructs the operator to refresh authoritative state before repeating the decision.
- Existing approval endpoint semantics remain unchanged; end-to-end idempotency will require the later backend contract phase and is not claimed as complete yet.

### Route contract and direct-link hardening
- Workspace features now declare stable route IDs, canonical hashes, titles, breadcrumbs, telemetry IDs, workspace/auth requirements, error-boundary policy and unsaved-work policy.
- Direct links such as `#/workspace?tab=Settings` now resolve the requested workspace feature instead of relying only on browser-local active-tab state.
- Workspace navigation writes canonical route state so links are shareable and browser history can reconcile feature selection.
- The manifest remains lightweight and does not eagerly import the monolithic feature implementation.

### Dirty-work and draft-loss protection
- A shared dirty-work registry now protects route changes, workspace switches and browser/tab closure.
- Workspace Settings tracks server-confirmed values separately from current edits and warns only when confirmed values differ from unsaved edits.
- The media Planner marks changed scenario budgets as unsaved until the scenario is confirmed by the backend.
- The custom model builder registers an in-progress draft while its creation surface is open.
- The protection is additive: existing forms, endpoints and feature behavior remain in place.

### Accessible dialog and builder protection
- A shared focus-managed dialog primitive now owns dialog semantics, initial focus, Escape handling, backdrop dismissal, focus trapping and focus restoration.
- Data Flow creation, Audience Builder, custom-model creation/validation and workspace creation now use the shared dialog primitive without removing their existing workflows.
- Data Flow and Audience Builder surfaces now register in-progress drafts with the shared dirty-work guard, so workspace/route changes cannot silently discard work.
- Playwright coverage verifies Audience Builder dialog semantics, initial focus, explicit discard protection and focus restoration after Escape.

### Frontend dependency boundary enforcement
- CI now scans frontend source for backend/server imports, Node-only modules, PostgreSQL imports and server-secret patterns.
- The current monolithic `AcePlatform.tsx` has a temporary migration ceiling so new work cannot grow the legacy composition indefinitely.
- The check warns above the current 500 KB extraction threshold and fails if the temporary 600 KB ceiling is crossed.
- This is a migration control, not a claim that feature extraction is complete.

### Runtime transport integration
- The shared browser transport now consumes the already-validated runtime API base path and bounded read/write deadlines.
- Existing endpoint semantics and request cancellation behavior are preserved.

### New frontend verification
- Playwright now verifies a direct workspace feature URL and confirms that unsaved Settings edits block accidental navigation until the operator explicitly accepts discard.
- `npm run frontend:architecture` provides a fast dependency-boundary check.
- `npm run frontend:verify` composes architecture, TypeScript, production build and bundle-budget evidence.

### Passive connectivity truth
- The shared transport now publishes health transitions from real application requests instead of adding a dedicated polling loop.
- Browser offline state is shown explicitly while preserving the current page and unsaved work.
- Network failure or timeout is shown as degraded connectivity rather than falsely claiming confirmed backend failure.
- A later successful application request clears the degraded state; HTTP validation/auth/conflict responses still prove the transport itself is reachable.
- Playwright coverage verifies that going offline surfaces the warning without destroying the active workspace view.

### Startup and polling pressure reduction
- The optional dashboard navigator is now a lazy-loaded chunk rather than mandatory startup JavaScript.
- Its failure is contained in a widget-level boundary, so a chunk/widget problem does not remove the application shell.
- Dashboard readiness polling now pauses while the browser tab is hidden and resumes on visibility return.
- The ~30-second refresh cadence is staggered with jitter to reduce synchronized browser refresh spikes.
- Overlapping dashboard-summary refreshes are prevented inside the navigator.
- This keeps the existing navigator feature and backend endpoint intact while reducing startup and background request pressure.

### Chunk and release recovery
- AceMarketing now listens for Vite preload/chunk failures and surfaces a bounded recovery notice instead of automatically reloading.
- The recovery path explicitly preserves dirty-work protection; reload occurs only after the operator accepts leaving unsaved work.
- There is no automatic reload loop.
- CI now verifies that every Vite manifest asset exists and that emitted JavaScript/CSS assets use content-hashed names.
- Nginx now serves the entry document with no-store/revalidation semantics while Vite's hashed /assets/ files receive a one-year immutable cache policy and missing asset requests return 404 rather than application HTML.
- Old-asset retention across deployments still depends on deployment strategy and is not claimed complete until release infrastructure preserves the declared open-tab compatibility window.

### First feature extraction from the legacy composition
- Human Approvals is now the first complete workspace feature moved out of `AcePlatform.tsx` into an owned feature directory.
- The feature has its own manifest, public entry point, page implementation, browser data adapter and ownership README.
- `AcePlatform.tsx` no longer contains a second Approvals implementation; it lazy-loads the feature through its public entry point.
- Existing route identity, CSS classes, backend endpoints, approval semantics and customer-visible recovery behavior remain unchanged.
- Workspace route metadata now reports Approvals as a `feature-chunk` while all not-yet-extracted surfaces remain explicitly marked `current-composition`.
- CI now fails if the legacy Approvals function is reintroduced into the monolith and verifies the extracted files exist.
- Playwright verifies `#/workspace?tab=Approvals` still resolves to the extracted feature.

### Second feature extraction: Monitoring
- Monitoring is now the second workspace surface moved out of `AcePlatform.tsx` into a feature-owned lazy chunk.
- It has its own manifest, public entry point, page implementation, browser data adapter and ownership README.
- The existing monitoring summary/rules endpoints, CSS classes, usage meters and Alert Center navigation behavior are unchanged.
- The extraction is intentionally read-only first, which keeps operational observation separate from later write-control hardening.
- CI rejects reintroduction of a legacy `Monitoring` function in the monolith and verifies the extracted feature structure.
- Playwright verifies the existing direct route `#/workspace?tab=Monitoring` resolves to the extracted feature.

### Third feature extraction: Alerts
- Alert Center is now the third workspace surface extracted from `AcePlatform.tsx` into a feature-owned lazy chunk.
- It owns its manifest, public entry point, page implementation, browser data adapter and ownership README.
- Existing alert list/resolve endpoints, CSS classes and investigation navigation are preserved.
- Alert resolution now uses the shared mutation lifecycle so network loss or timeout becomes an explicit unknown outcome instead of a false confirmed failure.
- Conflict responses remain distinct from rejection, and the operator is instructed to refresh authoritative state before repeating an uncertain resolution.
- CI rejects reintroduction of the legacy `Alerts` function and Playwright verifies the existing direct route.

### Fourth feature extraction: Reports
- Reports is now the fourth workspace feature extracted from `AcePlatform.tsx` into a feature-owned lazy chunk.
- It owns its manifest, public entry point, page implementation, browser data adapter and ownership README.
- Existing cohort analytics, schedule creation, delivery history, source-quality presentation, CSS classes and direct route are preserved.
- "Send now" now uses the shared mutation lifecycle so timeout/network loss produces an explicit unknown outcome instead of claiming that durable delivery definitely failed.
- Schedule creation also distinguishes an uncertain network outcome from a confirmed rejection and instructs the operator to refresh before resubmitting.
- CI rejects reintroduction of the legacy `Reports` function and Playwright verifies the existing direct route.

### Fifth feature extraction: Executive Briefs
- Executive Briefs is now the fifth workspace feature extracted from `AcePlatform.tsx` into a feature-owned lazy chunk.
- It owns its manifest, public entry point, page implementation, browser data adapter and ownership README.
- Existing cohort/report endpoints, metric definitions, preview behavior, schedule history, email transport status and direct route are preserved.
- The executive schedule form now registers unsaved work with the shared dirty-work registry, so route/workspace changes and browser unload cannot silently discard an edited brief.
- Schedule creation and send-now delivery distinguish timeout/network uncertainty from confirmed rejection; an uncertain outcome requires authoritative refresh before repeat submission.
- CI rejects reintroduction of the legacy `ExecutiveBriefs` function and Playwright verifies the existing direct route.

### Sixth feature extraction: Integrations
- Integrations is now the sixth workspace feature extracted from `AcePlatform.tsx` into a feature-owned lazy chunk.
- It owns its manifest, public entry point, page implementation, browser data adapter and ownership README.
- Existing connector catalog behavior, OAuth redirects, server-secret setup, custom integration builder, WhatsApp operations, connector requests, CSS classes and direct route are preserved.
- Open connector configuration, server-secret setup and connector-request workflows now register with the shared dirty-work registry so navigation/workspace changes cannot silently discard in-progress setup.
- The browser data adapter is feature-owned while the shared transport remains the only browser network boundary.
- CI rejects reintroduction of the legacy `Integrations` function and Playwright verifies the existing direct route.

### Seventh and eighth feature extractions: Data Flows and Audiences
- Data Flows and Audiences are now feature-owned lazy chunks rather than inline implementations inside `AcePlatform.tsx`.
- Each owns a manifest, public entry point, page implementation, browser data adapter and ownership README.
- Existing endpoints, CSS classes, direct routes, builder behavior, readiness checks, audience preview/materialization, provider sync, scheduling and CSV export are preserved.
- Both builders continue using the shared dirty-work registry so navigation and workspace changes cannot silently discard in-progress configuration.
- CI rejects reintroduction of the legacy `DataFlows` and `Audiences` functions and verifies the extracted structures.
- Playwright verifies the existing direct routes for both features.

### Ninth and tenth feature extractions: Planner and Models
- Planner and Models are now feature-owned lazy chunks rather than inline implementations inside `AcePlatform.tsx`.
- Each owns a manifest, public entry point, page implementation, browser data adapter and ownership README.
- Existing planner evidence, budget allocation, saved scenarios, model catalog, custom model definitions, validation evidence and scoring-run behavior are preserved.
- Planner scenario saves now use the shared mutation lifecycle so timeout/network loss becomes an explicit unknown outcome requiring reconciliation before repeat submission.
- Model creation and scoring runs use the same confirmed/rejected/conflict/unknown outcome vocabulary.
- The custom model builder now uses the shared accessible dialog primitive while retaining its current fields and model semantics.
- Planner and Models remain registered with dirty-work protection.
- CI rejects reintroduction of the legacy `Planner` and `Models` functions and Playwright verifies both direct routes.

### Eleventh feature extraction: Settings
- Settings is now a feature-owned lazy chunk rather than an inline implementation inside `AcePlatform.tsx`.
- It owns a manifest, public entry point, page implementation, feature-local UI primitives, browser data adapter, member/role settings, governance/privacy settings, billing/usage settings and ownership README.
- Existing workspace, tracking, governance, API-key, approval-policy, notification, membership and billing behavior remains available through the same backend endpoints and CSS classes.
- Unsaved workspace edits continue to use the shared dirty-work registry.
- Settings saves and API-key creation now explicitly warn when timeout/network loss leaves the authoritative outcome unknown instead of implying a confirmed failure.
- CI rejects reintroduction of legacy Settings/member/governance/billing settings functions into `AcePlatform.tsx`, and Playwright verifies the direct Settings route.

### Twelfth feature extraction: Compliance
- Compliance is now a feature-owned lazy chunk rather than depending on the legacy `AcePlatform.tsx` composition.
- It owns its manifest, public entry point, page implementation, browser data adapter and ownership README.
- Existing consent coverage, privacy export/deletion, retention preview/application, operational readiness checks, audit history, CSS classes and direct route are preserved.
- Destructive subject deletion and retention purge now surface timeout/network ambiguity as an explicit reconciliation state; the UI instructs operators to refresh authoritative compliance history before repeating the action.
- The customer-facing Compliance feature remains tenant-scoped and does not introduce privileged platform-control responsibilities.
- CI rejects reintroduction of the legacy `Compliance` function and Playwright verifies the existing direct route.

### Thirteenth and fourteenth feature extractions: Developers and Delivery
- Developers and Delivery are now feature-owned lazy chunks rather than inline implementations inside `AcePlatform.tsx`.
- Developers owns API-key management, signed webhooks, endpoint setup, delivery inspection and server-to-server quick starts through a feature-owned browser data adapter.
- Delivery owns durable signal-delivery visibility, connector health, retry admission, dead-letter replay and test-signal admission through its own data adapter.
- Open developer credential/endpoint builders register with the shared dirty-work registry.
- API-key creation/revocation, webhook secret rotation and endpoint creation now warn on timeout/network ambiguity rather than encouraging duplicate irreversible actions.
- Delivery retry, dead-letter replay and test-signal admission use an explicit reconciliation state when backend acceptance cannot be confirmed.
- CI rejects reintroduction of the legacy `Developers` and `DeliveryCenter` functions and Playwright verifies both direct routes.

### Fifteenth through seventeenth feature extractions
- Real-Time Activation, Personalization and Exclusions are now feature-owned lazy chunks rather than inline implementations inside `AcePlatform.tsx`.
- Existing rule catalogs, consent-aware decisioning, dry-run behavior, suppression materialization, provider synchronization, CSS classes and direct routes are preserved.
- Activation and Personalization builders now use the shared accessible dialog primitive and register with the dirty-work registry.
- Rule creation/toggle, personalization feedback, exclusion creation and exclusion sync surface timeout/network ambiguity as an explicit reconciliation state before repeat submission.
- CI rejects reintroduction of the three legacy implementations and Playwright verifies their direct workspace routes.
- The malformed conversion-adjustment dialog closing tag that caused the local Vite JSX parser failure was corrected before continuing the extraction sequence.

### Eighteenth and nineteenth feature extractions
- Adjustments and Diagnostics are now feature-owned lazy chunks rather than inline implementations inside `AcePlatform.tsx`.
- Existing adjustment creation/preview/application, diagnostics issue inspection, replay, scan behavior, CSS classes and direct routes are preserved.
- Adjustment creation remains draft-protected and create/apply operations now surface timeout/network ambiguity as an explicit reconciliation state.
- Diagnostic replay and full-scan commands also require authoritative refresh before repeat submission after an uncertain outcome.
- Diagnostic configuration guidance now uses the shared accessible dialog primitive.
- CI rejects reintroduction of the legacy `Adjustments` and `Diagnostics` functions and Playwright verifies both direct routes.

### Twentieth through twenty-second feature extractions
- Match Quality, Reconciliation and Fraud are now feature-owned lazy chunks rather than inline implementations inside `AcePlatform.tsx`.
- Match Quality preserves the existing first-party identity-coverage evidence and provider-score boundary while moving its reads behind a feature-owned data adapter.
- Reconciliation repair commands now use the shared mutation lifecycle with confirmed, rejected, conflict and unknown-outcome handling.
- Fraud review/block commands use the same authoritative lifecycle and continue to require explicit human action; no silent auto-blocking was introduced.
- Existing routes, CSS classes, endpoint contracts and customer-visible workflow semantics are preserved.
- CI rejects reintroduction of the three legacy functions and Playwright verifies all three direct workspace routes.

### Bundle-budget evidence
- Vite now emits a build manifest.
- CI calculates gzip size for each entry and all of its static dependencies.
- The architecture targets are recorded as <=250 KiB gzip initial JavaScript, 350 KiB review gate and <=60 KiB initial CSS.
- During the non-destructive migration the CI job is evidence/report mode so existing oversized composition is surfaced without blocking unrelated fixes.
- The gate will move to strict mode after high-value feature splitting/lazy loading reduces the startup graph below the review threshold.

## Frontend completion sequence before backend architecture changes

1. Continue extracting feature-owned page/data/form boundaries from the monolithic composition without moving or deleting working behavior.
2. Adopt shared state primitives across the remaining high-traffic workspace surfaces.
3. Migrate the remaining critical writes to the explicit mutation lifecycle one feature at a time.
4. Extend dirty-work protection from Settings/Planner/model drafts to Data Flows, Audiences, Launchpad and other long-form builders.
5. Split expensive sections behind lazy feature loaders according to measured bundle evidence.
6. Add broader automated accessibility coverage for dialogs, keyboard alternatives, focus recovery, zoom/reflow and mobile navigation.
7. Add long-session memory/listener/subscription evidence and convert bundle-budget CI from report to strict review-gate mode.
8. Separate the public website into its own deployable composition without duplicating product behavior, preserving current URLs through compatibility routing during migration.
9. Only after the frontend acceptance evidence is green begin the backend architecture tightening phase.

## Completion rule

A frontend feature is not considered complete because the screen renders. Completion requires the happy path, validation/denied path, failure path, recovery path, compatibility/migration behavior and release evidence appropriate to that feature.


### Launchpad feature extraction
- Launchpad is now a feature-owned lazy chunk instead of an inline implementation inside `AcePlatform.tsx`.
- It owns a manifest, public entry point, page implementation, browser data adapter and ownership README.
- Existing launchpad evidence, readiness steps, test-event flow, CSS classes, direct route and cross-feature navigation are preserved.
- Backend loading and test-event failures are now explicit and retryable; failed tests are not rendered with success styling.
- CI rejects reintroduction of the legacy Launchpad function and verifies the extracted feature files exist.
- This is an additive migration on `main`; no existing feature or backend route was removed.


### Overview command-center feature extraction
- Overview is now a feature-owned lazy chunk instead of an inline implementation inside `AcePlatform.tsx`.
- It owns its page, browser data adapter, manifest, public entry point and ownership README.
- Existing dashboard-summary, live-sync and funnel endpoints, visual classes, direct route and cross-feature navigation are preserved.
- Overview refresh failures are now explicit and retryable while previously loaded evidence remains visible.
- Background refresh pauses while the browser tab is hidden and resumes when visible, reducing unnecessary polling pressure.
- The embedded funnel surface now exposes loading and degraded states rather than silently appearing empty on backend failure.
- CI rejects reintroduction of the legacy Overview/FunnelPanel implementation into the workspace monolith.


### AdSync feature extraction and mutation-safety hardening
- AdSync is now a feature-owned lazy chunk rather than an inline implementation inside `AcePlatform.tsx`.
- It owns its page, browser data adapter, manifest, public entry point and ownership README.
- Existing event-rule, tracking and signal-delivery APIs, quick-agent workflows, visual classes and cross-feature navigation are preserved.
- Pipeline creation, enable/pause and test-event actions now separate confirmed success from timeout/network uncertainty; uncertain outcomes require an authoritative refresh before repetition.
- The pipeline builder now uses the shared accessible dialog and participates in the dirty-work registry so route/workspace changes cannot silently discard an open builder.
- Load failures preserve previously visible AdSync evidence and expose a retryable error state.
- CI rejects reintroduction of the legacy AdSync implementation into the workspace monolith.


### ChatGPT Ads feature extraction and customer-work protection
- ChatGPT Ads is now a feature-owned lazy chunk instead of an inline workspace implementation.
- It owns its page, browser data adapter, manifest, public entry point and ownership README.
- Existing status, validation and conversion-submission APIs, CSS classes, delivery evidence and Delivery Center navigation are preserved.
- Edited conversion payloads now participate in the shared dirty-work registry so workspace/route changes cannot silently discard customer input.
- Live submission distinguishes confirmed backend acceptance from timeout/network uncertainty; uncertain outcomes direct the customer to refresh authoritative delivery state before retrying.
- Load failures preserve already-visible provider and delivery evidence and expose an explicit retry path.
- CI rejects reintroduction of the legacy ChatGPT Ads implementation into `AcePlatform.tsx`.


### Funnel feature extraction and request-order hardening
- Funnel is now a feature-owned lazy chunk instead of an inline workspace implementation.
- It owns its page, browser data adapter, manifest, public entry point and ownership README.
- Existing funnel endpoint behavior, filters, stage metrics, campaign drill-down, CSV export, route and visual classes are preserved.
- Funnel reads are sequence-guarded so a slower response from an older filter selection cannot overwrite a newer selection.
- Refresh failures preserve already-loaded campaign evidence and expose an explicit retry path rather than silently presenting an empty funnel.
- CSV object URLs are explicitly released after export.
- CI rejects reintroduction of the legacy Funnel implementation into `AcePlatform.tsx`.


### Live Sync feature extraction and visibility-aware refresh
- Live Sync is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing live-sync metrics, recent activity, destination throughput, alert creation, CSS classes and backend endpoints are preserved.
- The 15-second refresh cadence remains while the tab is visible, but polling pauses while hidden and resumes on visibility return, reducing unnecessary background request pressure without removing live behavior.
- Alert creation now uses the shared accessible dialog and dirty-work protection.
- Timeout/network loss during alert creation is shown as an unknown outcome that requires authoritative reconciliation before retry.
- Recent activity rendering is bounded to the most recent 100 rows in the UI while canonical backend history remains unchanged.
- CI rejects reintroduction of the legacy Live Sync implementation into `AcePlatform.tsx`.


### Data Hub feature extraction and canonical-state hardening
- Data Hub is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing source registry, canonical data model, schema-health, identity, attribution, lineage, recent source activity, Integrations navigation and canonical rebuild behavior are preserved.
- Data reads expose explicit loading and retry states while retaining previously visible source evidence during transient failures.
- Canonical rebuild distinguishes confirmed backend success from timeout/network uncertainty; unknown outcomes require authoritative refresh before another rebuild is attempted.
- Recent source activity rendering is bounded to 100 rows in the browser without changing backend retention.
- CI rejects reintroduction of the legacy Data Hub implementation into `AcePlatform.tsx`.


### Frontend feature-chunk budget gate
- The existing startup budget remains 250 KiB gzip target / 350 KiB review gate for mandatory JavaScript and 60 KiB gzip for initial CSS.
- The production Vite manifest is now also inspected for non-entry JavaScript chunks with a default 180 KiB gzip feature review threshold.
- Report mode warns without blocking local work; strict mode fails when either the startup review gate or feature-chunk review threshold is exceeded.
- This keeps feature extraction measurable instead of simply moving bytes out of the entry bundle.


### Customer 360 and Offline Attribution hardening
- Customer 360 now sequence-guards profile reads so slower responses from an earlier profile selection cannot overwrite the currently selected customer.
- Previously visible Customer 360 evidence is preserved on transient read failures, and timeline rendering is bounded to the newest 150 records for long-lived profiles.
- Offline Attribution now exposes an explicit loading state and separates confirmed success, confirmed error and timeout/network unknown outcomes for rule creation, enable/pause and reconciliation tests.
- The Offline Attribution builder now uses the shared accessible dialog, participates in dirty-work protection, and template application uses React state rather than post-render DOM mutation.
- Architecture checks protect these safety properties while both features remain in the current composition during the incremental migration.


### Matchback feature extraction and reconciliation hardening
- Matchback is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing rule reads, rule creation, enable/pause, reconciliation, suggested templates, live identity coverage and unmatched-record review are preserved.
- Rule creation, rule-status changes and reconciliation now distinguish confirmed success from timeout/network uncertainty; uncertain outcomes require authoritative refresh before repetition.
- The rule builder and unmatched-record review use shared accessible dialogs; the builder participates in dirty-work protection.
- Suggested templates hydrate controlled React state instead of mutating DOM form elements after render.
- Unmatched-record rendering is bounded to the newest 100 records in the browser while backend data remains authoritative.
- CI rejects reintroduction of the legacy Matchback implementation into `AcePlatform.tsx`.


### POS & Stores feature extraction and import hardening
- POS & Stores is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing location summaries, offline revenue, identity match coverage, CSV template download, transaction import and import-history behavior are preserved.
- The import builder uses the shared accessible dialog and participates in dirty-work protection.
- CSV parsing validates required columns, numeric revenue and timestamps before submission.
- Import writes distinguish confirmed backend success from timeout/network uncertainty; uncertain outcomes require authoritative refresh before retrying the same batch.
- Recent import rendering is bounded to the newest 100 batches in the browser without changing backend retention.
- CI rejects reintroduction of the legacy POS & Stores implementation into `AcePlatform.tsx`.


### Journeys feature extraction and chronology hardening
- Journeys is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing source/stage filters, search, lead selection, metadata and stitched chronology are preserved.
- Journey reads use request sequencing so a slower prior refresh cannot replace newer data.
- Transient failures preserve previously loaded journey evidence and expose an explicit retry path.
- Chronology rendering is bounded to the newest 150 records in the browser while backend history remains authoritative.
- CI rejects reintroduction of the legacy Journeys implementation into `AcePlatform.tsx`.


### Identity feature extraction and graph hardening
- Identity is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing identity metrics, stitched profile graph, deterministic match rules, review-queue export and Fingerprinting navigation are preserved.
- Identity reads expose explicit loading and retry states while retaining previously visible evidence during transient failures.
- Recent resolved-identity rendering is bounded to the newest 100 records in the browser without changing backend history.
- Identity graph identifier nodes are bounded in the UI to avoid pathological browser layout expansion from unusually wide profiles.
- CSV export releases its object URL immediately after download.
- CI rejects reintroduction of the legacy Identity implementation into `AcePlatform.tsx`.


### Attribution feature extraction and evidence hardening
- Attribution is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing period switching, channel/campaign/outcome/match-evidence views, Journeys navigation and Matchback navigation are preserved.
- Attribution reads use request sequencing so slower prior period responses cannot replace newer evidence.
- Transient failures preserve previously loaded attribution evidence and expose an explicit retry path.
- Large channel, campaign, outcome, method and recent-evidence collections are bounded in browser rendering while backend history remains authoritative.
- CI rejects reintroduction of the legacy Attribution implementation into `AcePlatform.tsx`.


### Grouped Performance feature extraction and cost-basis hardening
- Grouped Performance is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing dimension switching, grouped conversion evidence, conversion-event contract, operator-entered cost basis and contribution/margin calculations are preserved.
- Dimension reads use request sequencing so stale responses cannot replace newer selections.
- Dirty cost drafts participate in customer-work protection until authoritative values are reloaded after a confirmed save.
- Cost saves distinguish confirmed success from timeout/network uncertainty; uncertain outcomes require authoritative refresh before repeating the same write.
- Group rendering is bounded to 150 rows in the browser while backend data remains authoritative.
- CI rejects reintroduction of the legacy Grouped Performance implementation into `AcePlatform.tsx`.


### Enrich feature extraction and CRM writeback hardening
- Enrich is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing enriched lead search, lead selection, score evidence, journey/call/WhatsApp context, grade distribution, CRM writeback actions and persisted writeback evidence are preserved.
- Reads expose explicit loading and retry states while retaining previously visible evidence during transient failures.
- CRM writeback mutations distinguish confirmed success from timeout/network uncertainty; uncertain outcomes require authoritative refresh before repeating the same writeback.
- Lead-list and writeback rendering are bounded in the browser for long-running/high-cardinality workspaces while backend data remains authoritative.
- CI rejects reintroduction of the legacy Enrich implementation into `AcePlatform.tsx`.


### Lead Grading feature extraction and mutation hardening
- Lead Grading is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing lead selection, explainable score evidence, manual grade override, grade distribution and downstream activation behavior are preserved.
- Reads expose explicit loading and retry states while retaining previously visible evidence during transient failures.
- Manual overrides and activation mutations distinguish confirmed success from timeout/network uncertainty; uncertain outcomes require authoritative refresh before repeating the same operation.
- Duplicate override/activation submissions are blocked while a mutation is running.
- Lead and score-driver rendering are bounded in the browser for large grading populations while backend data remains authoritative.
- CI rejects reintroduction of the legacy Lead Grading implementation into `AcePlatform.tsx`.


### Behavior feature extraction and evidence hardening
- Behavior is now a feature-owned lazy chunk instead of an inline workspace implementation.
- Existing event/source/campaign/device analysis, signal selection, related activity and latest first-party sequence are preserved.
- Reads expose explicit loading and retry states while retaining previously visible evidence during transient failures.
- Signal collections are bounded to 150 rows, matching activity to 20 rows, and the latest sequence to 20 records in the browser while backend data remains authoritative.
- Refresh interaction is disabled while loading so duplicate foreground reads are not emitted.
- CI rejects reintroduction of the legacy Behavior implementation into `AcePlatform.tsx`.


### Models feature state and evidence hardening
- Models continues to use the existing `/models`, `/models/run` and `/models/validation` pipeline; no alternate AI/model frontend or duplicate runtime was introduced.
- Model catalog and validation reads are now cancellable and request-sequence guarded so stale responses cannot overwrite newer workspace state.
- The feature owns typed catalog, run and validation contracts instead of passing backend payloads through the page as unbounded `any`.
- Initial loading, empty, retryable read failure, conflict and outcome-unknown states are explicit while confirmed backend evidence remains visible.
- Successful runtime scoring is no longer presented as statistical model qualification. Runtime readiness and evaluation evidence are separate UI concepts.
- Optional provider/model governance metadata is displayed only when returned by the backend; the frontend does not invent provider access, model availability or evaluation status.
- Existing custom weighted scoring creation, dirty-work protection, validation dialog and scoring-run behavior are preserved.


### Ask Ace evidence-boundary hardening
- Ask Ace continues to use the existing `/ask-ace` route and current grounded workspace-analysis behavior; no parallel hosted-model frontend was introduced.
- The feature now owns typed answer, insight, journey, evidence, warning and engine contracts instead of accepting unbounded assistant payloads.
- In-flight analysis is cancellable when the feature unmounts, preserving route/workspace lifecycle hygiene.
- Conversation and journey rendering remain bounded for long-running sessions.
- Evidence IDs, evidence-kind labels and limitations are rendered only when returned by the backend.
- Analysis failures remain explicit and do not substitute sample or fabricated metrics.
- The UI labels the current implementation as the grounded deterministic/workspace baseline and will not present hosted analyst/reviewer routes as active until backend registry, access, evaluation and policy evidence exists.
